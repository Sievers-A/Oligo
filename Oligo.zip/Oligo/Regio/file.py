from .Region import Region


def read(input_filename, read_type=None):
    if read_type is None:
        read_type = input_filename.split('.')[-1]
    if read_type == 'search':
        return read_search_results(input_filename)
    else:
        print('Warning: Unknown File Type. Could not auto-identify "',read_type,' for ',input_filename,'". Check the file type and consider specifiing a read_type.')
    return []
    
def read_search_results(input_filename):
    pass
