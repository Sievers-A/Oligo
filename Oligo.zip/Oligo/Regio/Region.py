class Region:

    def __init__(self, start, stop=None, length=None):
        self.start = start
        if stop is not None:
            if stop < start:
                start,stop = stop,start
        if length is not None:
            self.length = length
        else:
            self.length = stop-start
    
    def stop(self):
        return self.start+self.length
        
    