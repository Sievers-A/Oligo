from Bio import motifs
from .Matrices import Matrix
from Oligo import Prot

def read_jaspar(input_filename, verbose=1):
    Prot.write('Reading Matrix from %s.' % input_filename)
    data = []
    row_names = ['A','C','G','T']
    col_names = []
    with open(input_filename) as handle:
        for m in motifs.parse(handle, "Jaspar"):
            col_names = list(range(1,len(m.pwm['A'])+1))
            data.append([x for x in m.pwm['A']])
            data.append([x for x in m.pwm['C']])
            data.append([x for x in m.pwm['G']])
            data.append([x for x in m.pwm['T']])
    matrix = Matrix(data=data, row_names=row_names, col_names=col_names)
    if verbose:
        Prot.write('Read %s x %s Matrix.' % (matrix.len_rows(), matrix.len_cols()))
    return matrix
