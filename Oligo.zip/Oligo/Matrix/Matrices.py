import numpy as np
import datetime
import pandas
import Oligo

class Matrix(object):

    def __init__(self, data, row_names=None, col_names=None, dtype=None, copy=True):
        self.matrix = np.matrix(data, dtype, copy)
        if row_names is None:
            row_names = [str(i) for i in range(len(data))]
        if col_names is None:
            col_names = [str(i) for i in range(len(data[0]))]
        self.row_names = row_names
        self.col_names = col_names
        self.refresh()
    
    def __len__(self):
        return self.len_rows()
    
    def len_rows(self):
        return len(self.row_names)
    
    def len_cols(self):
        return len(self.col_names)
    
    def refresh(self):
        self.row_index = {name:i for i,name in enumerate(self.row_names)}
        self.col_index = {name:i for i,name in enumerate(self.col_names)}
        #print self.col_index
        
    def col(self, name=None, ix=None):
        if not self.len_rows():
            return []
        if ix is None:
            try:
                ix = self.col_index[name]
            except:
                Oligo.Prot.write('Column Name %s not found in Matrix Columns.' % name)
                raise
        return [x.item(0) for x in self.matrix[0:,ix:ix+1]]

    def row(self, name=None, ix=None):
        if ix is None:
            try:
                ix = self.row_index[name]
            except:
                Oligo.Prot.write('Row Name %s not found in Matrix Rows.' % name)
                raise
        a = []
        for i,x in enumerate(self.matrix[ix:ix+1,0:]):
            for j,col in enumerate(self.col_names):
                a.append(x.item(0,j))
        return a
    
    def get_value(self, row_ix=None, col_ix=None, row_name=None, col_name=None):
        if row_ix is None:
            try:
                row_ix = self.row_index[row_name]
            except:
                Oligo.Prot.write('Row Name %s not found in Matrix Rows.' % row_name)
                raise
        if col_ix is None:
            try:
                col_ix = self.col_index[col_name]
            except:
                Oligo.Prot.write('Column Name %s not found in Matrix Columns.' % col_name)
                raise
        try:
            v = self.matrix[row_ix, col_ix]
        except:
            return None
        return v
    
    def save(self, output_filename, header=None, verbose=1):
        if verbose:
            Oligo.Prot.write('Saving %s x %s Matrix to %s.' % (self.len_rows(), self.len_cols(), output_filename))
        f = open(output_filename,'w')
        f.write('#date:\t'+str(datetime.datetime.now())+'\n')
        if header:
            for key in header:
                f.write('#'+str(key)+':\t'+str(header[key])+'\n')
        f.write('Row Name\t'+'\t'.join(self.col_names)+'\n')
        for i,row_name in enumerate(self.row_names):
            f.write(row_name+'\t'+'\t'.join([str(v) for v in self.row(ix=i)])+'\n')
        f.close()
    
    @classmethod    
    def read(cls, input_filename, verbose=1):
        if verbose:
            Oligo.Prot.write('Reading Matrix Data from '+str(input_filename))
        head_data, head_rows = Oligo.File.read_head(input_filename)
        raw_data = pandas.read_csv(input_filename, sep='\t', skiprows=head_rows, na_values=['-'], keep_default_na=False)
        data = []
        row_names = []
        col_names = list(raw_data.columns[1:])
        for i,row in raw_data.iterrows():
            data.append(list(row[1:]))
            row_names.append(row[0])
            if len(data[-1]) != len(col_names):
                Oligo.Prot.warn('Size of row in %s line %s does not fit number of column names %s.' % (input_filename, i, len(col_names)),'read')
        data = np.matrix(data)
        m = Matrix(data, row_names=row_names, col_names=col_names, copy=False)
        if verbose:
            Oligo.Prot.write('Read %s x %s Matrix.' % (m.len_rows(), m.len_cols()))
        return m
        
    @classmethod
    def read_old_heatmap(cls, input_filename, verbose=1):
        if verbose:
            Oligo.Prot.write('Reading Matrix Data from '+str(input_filename))
        # Old Code
        values = []
        row_names = []
        col_names = []
        file = open(input_filename,'r')
        line_n = 0
        for line in file:
            if line_n == 0:
                # if at first lane, extract col_names 
                col_names = line.rstrip("\n").split(" ")[1:]
            else:
                # if not first line...
                words = line.rstrip("\n").split(" ")	# ...split line in words
                row_names.append(words[0])
                row_data = []
                for i in range(1,len(words)):
                    if words[i] != 'nan':
                        row_data.append(float(words[i]))
                    else:	
                        row_data.append(0.0)
                values.append(row_data)
            line_n += 1
        file.close()
        #hm = {"rows":row_names, "cols":col_names, "values":values}
        # ----
        m = Matrix(values, row_names=row_names, col_names=col_names, copy=False)        
        if verbose:
            Oligo.Prot.write('Read %s x %s Matrix.' % (m.len_rows(), m.len_cols()))
        return m    
     
    def show(self, max_rows=10):
        Oligo.Prot.write('\t'+'\t'.join([str(name) for name in self.col_names]))
        for i,row_name in enumerate(self.row_names):
            Oligo.Prot.write(str(row_name)+'\t'+'\t'.join([str(v) for v in self.row(ix=i)]))
            if max_rows is not None and i > max_rows:
                break
    
    def transpose(self, copy=True):
        if not copy:
            self.matrix = self.matrix.transpose()
            self.row_names, self.col_names = self.col_names, self.row_names
            self.refresh()
            return self
        else:
            return Matrix(self.matrix.transpose(), self.col_names, self.row_names)
            
    def __repr__(self):
        return '<Matrix:%sx%s>' % (self.len_rows(), self.len_cols())
     
    def norm_rows(self):
        self.matrix = np.linalg.norm(self.matrix, axis=1)
     
    def get_bins(self, row_name=None, col_name=None, row_index=None, col_index=None):
        if row_index is not None:
            data = self.row(name=row_name, ix=row_index)
            names = self.col_names
        else:
            data = self.col(name=col_name, ix=col_index)
            names = self.row_names
        bins = []
        for i,d in enumerate(data):
            bin = Oligo.Loci.Bin(d, i-.5, i+.5, name=names[i])
            bins.append(bin)
        return bins
        
    def get_all_values(self):
        vals = []
        for i,row_name in enumerate(self.row_names):
            for j,col_name in enumerate(self.col_names):
                vals.append(self.get_value(i,j))
        return vals
        
    def add_row(self, ix, row_name, row_data):
        self.row_names.insert(ix, row_name)
        self.matrix = np.insert(self.matrix, ix, row_data, 0)
        self.refresh()
        
    def add_col(self, ix, col_name, col_data):
        self.col_names.insert(ix, col_name)
        self.matrix = np.insert(self.matrix, ix, col_data, 1)
        self.refresh()
        
    def add_row_after(self, row_name, added_row_name, row_data):
        ix = self.row_index[row_name]+1
        self.add_row(ix, added_row_name, row_data)
        
    def add_col_after(self, col_name, added_col_name, col_data):
        ix = self.col_index[col_name]+1
        self.add_col(ix, added_col_name, col_data)
        
    def modify(self, func, func_args=()):
        for i,row_name in enumerate(self.row_names):
            for j,col_name in enumerate(self.col_names):
                x = func(self,i,j,self.row(ix=i)[j],*func_args)
                self.matrix.itemset((i,j),x)
                
#m = Matrix([[1,2],[3,4]], ['x','y'], ['x','y'])
#print m.col('x')
#print m.col(ix=1)

#print m.row(ix=0)
#print m.row(ix=1)
#print m[0:1]
#print m[:1]
