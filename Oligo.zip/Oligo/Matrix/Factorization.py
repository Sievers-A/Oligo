import Oligo
from sklearn.decomposition import PCA

def pca(matrix, n_components=2, verbose=1):
    '''
        ==================================
            Princiap Component Analysis
        ==================================
        Performs a PCA that will reduce the dimension
        of each row (not column) of the provided data.
        Input:
            matrix : 2D data structure (e.g. array or list or Olig.Matrix.Matrix)
            n_components : number of components for the output
        Output:
            List with dimension of n_components.
            Every list entry is a list with one value per original row.
            Note: Every column in the result was a row in the input!
    
    '''
    Oligo.Prot.write('Dervice PCA (n=%s)' % n_components)
    if isinstance(matrix, (Oligo.Matrix.Matrix)):
        matrix = matrix.matrix
    pca_model = PCA(n_components=n_components)
    x = pca_model.fit_transform(matrix)
    r = []
    for i in range(n_components):
        r.append(list(x[:, i]))
    return r
    #print(x[:, 0], x[:, 1], x[:, 2])
    #return(x[:, 0], x[:, 1])
    #return list(x.explained_variance_ratio_), list(x.singular_values_)