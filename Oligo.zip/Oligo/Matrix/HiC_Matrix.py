import numpy as np
import scipy
import Oligo
from Oligo import Prot
from Oligo.Loci.bins import create_bins

class HiCMatrix(object):

    def __init__(self, name, resolution, data, n, target=None):
        self.name = name
        self.resolution = resolution
        self.target = target
        self.data = data
        self.n = n
        self.default_value = 0.

    @classmethod
    def read(cls, input_filename, resolution, name=None, target=None, verbose=1):
        if verbose:
            Prot.write('Reading Hi-C Data from %s. (resolution:%s)' % (input_filename, resolution))
        linear_data = {}
        i = 0
        n_zero = 0
        f = open(input_filename,'r')
        for line in f:
            v = line.rstrip()
            if v[0] == '0':
                i += int(v)
                n_zero += int(v)
            else:
                linear_data[i] = float(v)
                i += 1
        f.close()
        n = int(round(-0.5+np.sqrt(0.25+2.*i)))
        if verbose:
            Prot.write('Found %s data points (%s) zero entries. --> %s x %s matrix (sequence size = ~%sbp)' % (i, n_zero, n, n, n*resolution))
        data = {}
        i = 0
        for row_index in range(n):
            for j in range(n-row_index):
                try:
                    linear_data[i]
                except:
                    pass
                else:
                    try:
                        data[row_index]
                    except:
                        data[row_index] = {}
                    col_index = row_index+j
                    data[row_index][col_index] = linear_data[i]
                i += 1
        m = HiCMatrix(name, resolution, data, n, target)
        return m

    def __len__(self):
        return self.n

    def distance_norm(self, verbose=1):
        if verbose:
            Prot.write('Calculating Distance Norm for Hi-C Matrix: %s' % self.name)
        index_distance_values = {}
        for i in range(len(self)):
            for j in range(len(self)):
                di = abs(i-j)
                try:
                    index_distance_values[di]
                except:
                    index_distance_values[di] = []
                else:
                    index_distance_values[di].append(self.get_value_from_index(i,j))
        distance_norm = {}
        for dist in index_distance_values:
            distance_norm[dist] = np.mean(index_distance_values[dist])
        return distance_norm
        
    def distance_norm2(self, verbose=1):
        if verbose:
            Prot.write('Calculating Distance Norm for Hi-C Matrix: %s' % self.name)
        index_distance_values = {}
        for i in range(len(self)):
            for j in range(len(self)):
                di = abs(i-j)
                try:
                    index_distance_values[di]
                except:
                    index_distance_values[di] = []
                else:
                    index_distance_values[di].append(self.get_value_from_index(i,j))
        distance_norm = {}
        for dist in index_distance_values:
            d = np.percentile(index_distance_values[dist], [30,50,70])
            distance_norm[dist] = (abs(d[0]-d[1]), d[1], abs(d[1]-d[2]))
        return distance_norm
    
    def norm(self, norm_data=None, verbose=1):
        if verbose:
            Prot.write('Normalize Hi-C Matrix: %s' % self.name)
        if norm_data is None:
            norm_data = self.distance_norm(verbose=verbose)
        data = {}
        for i in self.data:
            for j in self.data[i]:
                linear_distance = abs(i-j)
                self.data[i][j] = self.data[i][j]-norm_data[linear_distance]
        return self
        
    def norm2(self, verbose=1):
        if verbose:
            Prot.write('Normalize Hi-C Matrix: %s' % self.name)
        norm_data = self.distance_norm2(verbose=verbose)
        data = {}
        for i in self.data:
            for j in self.data[i]:
                linear_distance = abs(i-j)
                if self.data[i][j] > norm_data[linear_distance][1]:
                    s = norm_data[linear_distance][2]
                else:
                    s = norm_data[linear_distance][0]
                if s == 0:
                    self.data[i][j] = 0.
                else:
                    self.data[i][j] = float(self.data[i][j]-norm_data[linear_distance][1])/s
        return self
    
    def values_for_linear_distances(self):
        distance_values = {}
        for i in self.data:
            for j in self.data[i]:
                linear_distance = abs(i-j)*self.resolution
                d = self.data[i][j]
                if d is not None:
                    try:
                        distance_values[linear_distance]
                    except:
                        distance_values[linear_distance] = [d]
                    else:
                        distance_values[linear_distance].append(d)
        return distance_values
    
    def distances(self, z=4930., a=0.3062):
        data = {}
        for i in self.data:
            data[i] = {}
            for j in self.data[i]:
                v = self.get_direct_value_from_index(i, j)
                if v != 0:
                    #print v, 1000*(v/z)**(3*a)
                    data[i][j] = 1000*(z/v)**(1./(3*a))
        m = Distance3DMatrix(self.name, self.resolution, data, self.n, self.target)
        return m

    def get_direct_value_from_index(self, xi, yi):
        try:
            self.data[xi][yi]
        except:
            return None
        return self.data[xi][yi]

    def get_value_from_index(self, xi, yi):
        v = self.get_direct_value_from_index(xi,yi)
        if v is None:
            v = self.get_direct_value_from_index(yi,xi)
            if v is None:
                return self.default_value
        return v

    def get_value_from_location(self, x, y):
        ix = int(x/self.resolution)
        iy = int(y/self.resolution)
        return self.get_value_from_index(ix, iy)

    def get_bins(self, bin_width=1, min_dist=0, max_dist=None):
        values = []
        for i in self.data:
            for j in self.data[i]:
                dist = abs(i-j)*self.resolution
                if dist >= min_dist and (max_dist is None or dist <= max_dist):
                    v = self.get_direct_value_from_index(i, j)
                    if v is not None:
                        values.append(v)
        return create_bins(values, bin_width=bin_width, bin_start=int(min(values)-1))
    
    def generate_loci(self, loci_func, loci_func_args=(), verbose=1):
        if verbose:
            Prot.write('Generate Loci from Hi-C data.')
        loci = []
        for i in self.data:
            loci +=  loci_func(self, i,self.data[i],*loci_func_args)
        if verbose:
            Prot.write('Generated %s Loci.' % len(loci))    
        return loci
        
    def generate_enriched_3D_contact_loci(self, th, res, min_dist=0, verbose=1):
        loci_index = {}
        return self.generate_loci(enriched_3D_contact_loci_generator,(th, loci_index, res, min_dist),verbose)
    
    def generate_enrichded_3D_partner_loci(self, loci, th, res, min_dist=0, verbose=1):
        results_loci_index = {}
        partner_loci_index = []
        for locus in loci:
            ix = int(locus.start/self.resolution)
            partner_loci_index.append(ix)
        return self.generate_loci(get_enriched_partner_loci_generator, (th, results_loci_index, partner_loci_index, res, min_dist), verbose)
    
    def sub_matrix(self, start, end):
        data = {}
        for i in range(start, end):
            data[i-start] = {}
            for j in range(start, end):
                v = self.get_direct_value_from_index(i, j)
                if v is not None:
                    data[i-start][j-start] = v
        return HiCMatrix(self.name, self.resolution, data, end-start, target=self.target)

    @classmethod
    def density_profile(cls, map1, map2, distance_matrix, target_name=None, resolution=None, min_linear_dist=0, verbose=1):
        if verbose:
            Prot.write('Generating 3D Density Profile for %s Map in %s Map using %s Distance Matrix.' % (map1.name, map2.name, distance_matrix.name))
        if resolution is None:
            resolution = map1.get_resolution()
        data = {} # {Distance : Density}
        for row in range(distance_matrix.n):
            for col in range(distance_matrix.n):
                # Itearation trough Distance Matrix
                # A filter for non-linear contact would be possible here - calculating difference between dist and linear distance by index
                linear_dist = abs((row-col)*distance_matrix.resolution)
                if linear_dist >= min_linear_dist:
                    dist = distance_matrix.get_value_from_index(row, col)
                    if dist is not None:
                        dist = int(dist/resolution)*resolution
                        # Get respective Map values
                        v1 = map1.get_value_at(target_name, distance_matrix.resolution*row)
                        v2 = map2.get_value_at(target_name, distance_matrix.resolution*col)
                        if v1 is None:
                            v1 = 0
                        if v2 is None:
                            v2 = 0
                        try:
                            data[dist]
                        except:
                            data[dist] = []
                        # Add values to collected data
                        data[dist] += [v2]*int(round(v1))
        if verbose:
            Prot.write('Found values for %s distances.' % len(data.keys()))
        ret = {'distance':[],'mean density':[], 'std density':[], 'n':[], 'err':[], 'model density':[], 'model err':[], 'map density':[], 'map std':[]}
        for key in sorted(data.keys()):
            if len(data[key]) == 0:
                v = 0.0
                err = 0.0
                std = 0.0
                n = 0
            else:
                v = np.mean(data[key])
                std = np.std(data[key])
                n = len(data[key])
                err = std/np.sqrt(n)
            ret['distance'].append(key)
            ret['mean density'].append(v)
            ret['std density'].append(std)
            ret['n'].append(n)
            ret['err'].append(err)
            ret['model density'].append(sum([bin.count for bin in map2[target_name]])/len(map2[target_name]))
            ret['model err'].append(np.sqrt(ret['model density'][-1]*(1.-1./len(map2))))
            ret['map density'].append(sum([bin.count for bin in map2[target_name]])/len(map2[target_name]))
            ret['map std'].append(np.std([bin.count for bin in map2[target_name]]))
        if verbose:
            Prot.write('Generated Density Profile with %s values.' % len(ret['distance']))
        return ret
        
    def complete_matrix(self, none_filler=None):
        m = []
        if none_filler is None:
            none_filler = self.default_value
        for i in range(self.n):
            m.append([])
            for j in range(self.n):
                v = self.get_value_from_index(i, j)
                if v is None:
                    v = none_filler
                m[-1].append(v)
        return m
        
    def reduce(self, factor):
        pass
        #data = {}
        #self.get_direct_value_from_index(xi, yi)

def enriched_3D_contact_loci_generator(matrix, i, row, th, loci_index, res, min_dist=0):
    loci = []
    for j in row:
        v = matrix.get_direct_value_from_index(i, j)
        dist = abs(i-j)*res
        if v >= th and dist >= min_dist:
            try:
                loci_index[i]
            except:
                loci.append(Oligo.Locus(start=i*res, length=res))
                loci_index[i] = True
            try:
                loci_index[j]
            except:
                loci.append(Oligo.Locus(start=j*res, length=res))
                loci_index[j] = True
    return loci
    

    
def get_enriched_partner_loci_generator(matrix, i, row, th, results_loci_index, partner_loci_index, res, min_dist=0):
    loci = []
    for locus_index in partner_loci_index:
        j = locus_index
        v = matrix.get_direct_value_from_index(i, j)
        dist = abs(i-j)*res
        if v is not None and v >= th and dist >= min_dist:
            #print(i,j,v)
            try:
                results_loci_index[i]
            except:
                loci.append(Oligo.Locus(start=i*res, length=res))
                results_loci_index[i] = True
    return loci
    


class Distance3DMatrix(HiCMatrix):

    def get_value_from_index(self, xi, yi):
        v = self.get_direct_value_from_index(xi,yi)
        if v is None:
            v = self.get_direct_value_from_index(yi,xi)
            if v is None:
                if xi == yi:
                    return 0
                return None
        return v

    def square_distance(self, positions, distance_limit=1e5):
        d = 0.0
        for row in range(self.n):
            for col in range(self.n):
                dp = np.sqrt(np.sum((positions[row*2:(row+1)*2]-positions[col*2:(col+1)*2])**2))
                v = self.get_value_from_index(row, col)
                #print 'posi:',row,col,positions[row*3:(row+1)*3],positions[col*3:(col+1)*3]
                #WEprint 'eval:',row,col,dp,v,(dp-v)**2
                if v is not None:
                    d += (dp-v)**2
                elif dp < distance_limit:
                    d += (dp-distance_limit)**2
        d = np.sqrt(d)
        #print d
        return d

    def sub_matrix(self, start, end):
        data = {}
        for i in range(start, end):
            data[i-start] = {}
            for j in range(start, end):
                v = self.get_direct_value_from_index(i, j)
                if v is not None:
                    data[i-start][j-start] = v
        return Distance3DMatrix(self.name, self.resolution, data, end-start, target=self.target)

    

    def reconstruct(self, positions=None, dim=3):
        # Set initial positions
        if positions is None:
            positions = []
            for i in range(self.n):
                p = [0.0]*dim
                p[0] = i*self.resolution
                positions += p
        positions = np.array(positions)
        Oligo.Prot.write('Initial:',positions,self.square_distance(positions),self.square_distance(positions)/self.n**2)
        opt_result =  scipy.optimize.minimize(self.square_distance, x0=positions, method='Powell')
        Oligo.Prot.write('Final:',opt_result['x'],opt_result['fun'],opt_result['fun']/self.n**2)
        return opt_result['x']
