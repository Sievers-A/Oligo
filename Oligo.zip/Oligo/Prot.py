from . import Data
import datetime



def write(text):
    if Data.prot_print:
        print(text)	
    if Data.prot_file:
        append_to_prot_file(text)

def append_to_prot_file(text, filename=None):
    if filename is None:
        filename = Data.prot_file
    f = open(filename,'a')
    f.write(str(datetime.datetime.now())+'\t'+text+'\n')
    f.close()
    
def warn(text, type=None):
    write('WARNING: '+text)
    
def error(text, type):
    write('ERROR: '+text)
