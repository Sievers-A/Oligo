import Oligo
import numpy as np

class SeqModel(object):
    pass
    
class ZeroOrderSeqModel(SeqModel):
    
    def __init__(self, letters=['A','C','G','T']):
        self.letters = letters
        self.order = 0
    
    def next_letter(self):
        return np.random.choice(self.letters)
    
    def random_sequence(self, length=10, seed=None):
        np.random.seed(seed)
        seq = ''
        for i in range(length):
            seq += self.next_letter()
        return seq
        
    def random_kmer_spectrum(self, length=1000, k=1, seed=None, name=None):
        np.random.seed(seed)
        if k > length:
            return Oligo.Kmer.KmerSpectrum(kmers=[],values=[],name=name)
        current_seq = ''
        while len(current_seq) < k:
            current_seq += self.next_letter()
        kmer_data = {}
        l = len(current_seq)
        while l <= length:
            current_seq += self.next_letter()
            current_seq = current_seq[1:]
            try:
                kmer_data[current_seq]
            except:
                kmer_data[current_seq] = 1
            else:
                kmer_data[current_seq] += 1
            l += 1
        kmers = sorted(kmer_data.keys())
        return Oligo.Kmer.KmerSpectrum(kmers=kmers, values=[kmer_data[kmer] for kmer in kmers],name=name)
        
class FirstOrderSeqModel(ZeroOrderSeqModel):

    def __init__(self, p=None, letters=['A','C','G','T']):
        if p is None:
            p = 1./len(letters)
            self.order = 0
        else:
            self.order = 1
        self.p = p
        self.letters = letters
        
    def next_letter(self):
        return np.random.choice(self.letters, p=self.p)
        
    
        