class Genome:

    def __init__(self, orga, chromos):
        self.orga = orga
        self.chromos = chromos
        
    def __getitem__(self, i):
        return self.chromos[i]
        
    def __setitem__(self, i, value):
        self.chromos[i] = value
        
    def __iter__(self):
        return iter(self.chromos)