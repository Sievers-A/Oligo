from Sequence import Sequence

class Chromo(Sequence):

    def __init__(self, seq, orga, index, type='c', topo='linear', length=None, regions=[]):
        self.index = index
        self.orga = orga
        self.type = type
        self.topo = topo
        self.regions = regions
        if length is None:
            self.length = len(seq)
            
    def __new__(cls, value, *args, **kwargs):
        return super(Chromo, cls).__new__(cls, value)    
            
    def __str__(self):
        return '<Chromo:'+str(self.orga)+' '+str(self.type)+' '+str(self.index)+' '+str(self.length)+'bp>'