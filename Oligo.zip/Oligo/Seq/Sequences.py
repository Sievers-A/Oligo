from Oligo import Prot
import Bio.Seq

class Sequence(Bio.Seq.Seq):
    pass
    
    
def save(seq, output_filename, seq_name=None, verbose=1):
    if verbose:
        Prot.write('Saving Sequence (%s) to %s' % (len(seq), output_filename))
    f = open(output_filename, 'w')
    if seq_name is None:
        seq_name = seq[0:100]
    f.write('>%s\n' % seq_name)
    posi = 0
    while posi < len(seq):
        f.write(seq[posi:posi+70])
        posi += 70
    f.close()
    
