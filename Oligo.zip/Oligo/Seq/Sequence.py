class Sequence(str):
    
    def __init__(self, id, seq, name=None):
        self.id = id
        if name is None:
            name = str(id)
        self.name = name
        value = str(seq)
        str.__init__(self, value)