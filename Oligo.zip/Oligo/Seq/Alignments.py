import Oligo
from Oligo import Prot
from Bio import pairwise2

class Alignment(Oligo.Loci.Locus):

    def __init__(self, seq1=None, seq2=None, start=0, length=0, score=None, target=None, target_name=None, query_name=None, cigar='*'):
        super(Alignment, self).__init__(start=start, length=length, strand='+', target=target)
        if target is not None:
            self.target_name = target.name
        else:
            self.target_name = target_name
        self.query_name = query_name
        self.cigar = cigar
        self.score = score
        self.seq1 = seq1
        self.seq2 = seq2

    @classmethod
    def read(cls, input_filename, verbose=1):
        if verbose:
            Prot.write('Reading Alignments from %s.' % input_filename)
        alignments = []
        f = open(input_filename, 'r')
        for line in f:
            if line[0] not in ['@','#']:
                words = line.rstrip().split('\t')
                query_name = words[0]
                target_name = words[2]
                start = int(words[3])
                score = float(words[4])
                cigar = words[5]
                length = len(cigar)
                if len(words) > 11:
                    seq1 = words[11]
                seq2 = words[9]
                alignments.append(Alignment(seq1=seq1, seq2=seq2, length=length, score=score, query_name=query_name, target_name=target_name, cigar=cigar))
        f.close()
        if verbose:
            'Found %s alignments.' % len(alignments)
        return alignments
        
    @classmethod
    def read_blast(cls, input_filename, verbose=1):
        if verbose:
            Prot.write('Reading BLAST Alignments from %s.' % input_filename)
        alignments = []
        #for line in f:
        #    print line
        if verbose:
            'Found %s alignments.' % len(alignments)
        return alignments

    def gaps(self):
        n = 0
        for s in self.cigar:
            if s == 'I':
                n += 1
        return n

    def missmatches(self):
        n = 0
        for s in self.cigar:
            if s == 'M':
                n += 1
        return n

    def identity(self):
        n = 0
        for s in self.cigar:
            if s == '=':
                n += 1
        return float(n)/len(self)

    def identity2(self):
        d = abs(len(self.seq1)-len(self.seq2))
        n = 0
        for s in self.cigar:
            if s == '=':
                n += 1
        #print '!',d, n, len(self)
        return float(n)/len(self.seq2)

    def format(self):
        line1 = ''
        line2 = ''
        line3 = ''
        i1 = 0
        i2 = 0
        for s in self.cigar:
            if s == '=':
                line1 += self.seq1[i2]
                line2 += '|'
                line3 += self.seq2[i1]
                i1 += 1
                i2 += 1
            elif s == 'I':
                line1 += self.seq1[i2]
                line2 += ' '
                line3 += '-'
                i2 += 1
            else:
                line1 += self.seq1[i2]
                line2 += ' '
                line3 += self.seq2[i1]
                i1 += 1
                i2 += 1
        Prot.write(line1+'\n'+line2+'\n'+line3)

    @classmethod
    def save(cls, output_filename, alignments, verbose=1):
        if verbose:
            Prot.write('Saving %s alignments to %s.' % (len(alignments), output_filename))
        f = open(output_filename, 'w')
        for alignment in alignments:
            qname = str(alignment.query_name)
            flags = '2'
            rname = str(alignment.target_name)
            pos = str(alignment.start)
            mapq = str(alignment.score)
            cigar = alignment.cigar
            rnext = '*'
            pnext = '*'
            tlen = str(len(alignment))
            seq2 = alignment.seq2
            qual = '0'
            seq1 = alignment.seq1
            f.write(qname+'\t'+flags+'\t'+rname+'\t'+pos+'\t'+mapq+'\t'+cigar+'\t'+rnext+'\t'+pnext+'\t'+tlen+'\t'+seq2+'\t'+qual+'\t'+seq1+'\n')
        f.close()

#@HD VN:1.6 SO:coordinate
#@SQ SN:ref LN:45
#r001   99 ref  7 30 8M2I4M1D3M = 37  39 TTAGATAAAGGATACTG *
#r002    0 ref  9 30 3S6M1P1I4M *  0   0 AAAAGATAAGGATA    *
#r003    0 ref  9 30 5S6M       *  0   0 GCCTAAGCTAA       * SA:Z:ref,29,-,6H5M,17,0;
#r004    0 ref 16 30 6M14N5M    *  0   0 ATAGCTTCAGC       *
#r003 2064 ref 29 17 6H5M       *  0   0 TAGGC             * SA:Z:ref,9,+,5S6M,30,1;
#r001  147 ref 37 30 9M         =  7 -39 CAGCGGCAT         * NM:i:1

def generate_cigar_from_bio_alignment(alignment):
    cigar = ''
    for n1, n2 in zip(alignment[0], alignment[1]):
        if n1 == n2:
            cigar += '='
        elif n2 == '-':
            cigar += 'I'
        elif n1 != n2:
            cigar += 'X'
        else:
            cigar += '?'
    return cigar

def global_alignments(seq1, seq2, match_score=2, missmatch_score=-3, existence_gap_costs=-5, extension_gap_cost=-2, target_name=None, query_name=None, verbose=1):
    if verbose:
        Prot.write('Global Aligning Sequences (length1=%s, length1=%s).' % (len(seq1), len(seq2)))
    bio_alignments = pairwise2.align.globalms(seq1, seq2, match_score, missmatch_score, existence_gap_costs, extension_gap_cost)
    if target_name is None:
        target_name = seq1[0:100]
    if query_name is None:
        query_name = seq2[0:100]
    alignments = []
    for a in bio_alignments:
        length = max(len(a[0]),len(a[1]))
        score = a[2]
        cigar = generate_cigar_from_bio_alignment(a)
        alignments.append(Alignment(seq1=seq1, seq2=seq2, length=length, score=score, query_name=query_name, target_name=target_name, cigar=cigar))
    if verbose:
        Prot.write('Found %s Alignments.' % len(alignments))
    return alignments

def save(output_filename, alignments):
    Alignment.save(output_filename, alignments)

def read(input_filename):
    return Alignment.read(input_filename)
