from Oligo import Prot
import matplotlib.pyplot as plt
from .Drawers import Drawer

class TextDrawer(Drawer):

    def __init__(self, text, x, y, fontsize=12):
        self.text = text
        self.x = x
        self.y = y
        self.fontsize = fontsize

    def draw(self, ax):
        plt.text(self.x, self.y, self.text, fontsize=self.fontsize)

class BoxDrawer(Drawer):

    def __init__(self, x, y, w, h, color='red', fill_color=None, linewidth=1., alpha=1., label='Box'):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.color = color
        self.fill_color = fill_color
        self.linewidth = linewidth
        self.alpha = alpha
        self.label = label

    def draw(self, ax):
        if self.fill_color is None:
            fill_color = 'none'
        rect = patches.Rectangle((self.x,self.y),self.w,self.h,linewidth=self.linewidth,edgecolor=self.color,facecolor=fill_color,alpha=self.alpha,label=self.label, clip_on=False)
        ax.add_patch(rect)

def color_func_white_red(value):
    return (1.,1.-value,1.-value)

def color_func_white_blue(value):
    return (1.-value,1.-value,1.)

def color_func_white_green(value):
    return (1.-value,0.75+0.25*(1.-value),1.-value)

class ColorScaleDrawer(Drawer):

    def __init__(self, x, y, name, scale_start, scale_end, tick_step, color_func, w=40, h=200, color_steps=1000, fontsize=24, precision=2):
        self.name = name
        self.scale_start = scale_start
        self.scale_end = scale_end
        self.color_func = color_func
        self.tick_step = tick_step
        self.color_steps = color_steps
        self.fontsize = fontsize
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.precision = precision

    def draw(self, ax):
        # Calculate Coordinates and Sizes
        x = self.x
        y = self.y
        px = self.get_px(ax)
        w = self.w/px[0]
        h = self.h/px[1]
        print x,y,w,h
        # Draw Color Gradient
        draw_step = float(h)/self.color_steps
        color_step = 1./self.color_steps
        for i in range(self.color_steps):
            color = self.color_func(1.-i*color_step)
            rect = patches.Rectangle((x,y+h-i*draw_step),w,draw_step,edgecolor='none',facecolor=color, clip_on=False)
            ax.add_patch(rect)
        # Draw Box
        box_drawer = BoxDrawer(x,y,w,h,'black',label=None)
        box_drawer.draw(ax)
        # Draw Ticks
        plt.plot([x+w, x+1.25*w], [y, y], color = 'black', clip_on=False, zorder=100, linewidth=1)
        ax.text(x+w*1.1, y, str(round(self.scale_start,self.precision)), style='normal', size=self.fontsize, name='Times New Roman')

        step = float(h)*self.tick_step/(self.scale_end-self.scale_start)
        dy = step
        i = 1
        while dy < h:
            plt.plot([x+w, x+.75*w], [y+dy, y+dy], color = 'black', clip_on=False, zorder=100, linewidth=1)
            ax.text(x+w*1.1, y+dy, str(round(self.scale_start+i*self.tick_step,self.precision)), style='normal', size=self.fontsize*0.75, name='Times New Roman')
            dy += step
            i += 1
        plt.plot([x+w, x+1.25*w], [y+h, y+h], color = 'black', clip_on=False, zorder=100, linewidth=1)
        ax.text(x+w*1.1, y+dy, str(round(self.scale_end,self.precision)), style='normal', size=self.fontsize, name='Times New Roman')
        # Draw Name
        ax.text(x-25/px[0], y+h*0.8, self.name, style='normal', rotation='vertical', size=self.fontsize*2, name='Times New Roman')

class ChromoDrawer(Drawer):

    def __init__(self, x, y, w, h, name, bins, color_funcs, draw_name=True, fontsize=12, order=None):
        self.name = name
        self.bins = bins
        self.color_funcs = color_funcs
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.box_drawer = BoxDrawer(x,y,w,h,'black',label=None)
        self.draw_name = draw_name
        self.name_drawer = TextDrawer(self.name, self.x, self.y-0.1, fontsize)
        self.order = order

    def draw(self, ax):
        n_maps = len(self.bins.keys())
        h_map = float(self.h)/n_maps
        for i,map_name in enumerate(self.order):
            for bin in self.bins[map_name]:
               #print bin.count
               color = self.color_funcs[map_name](bin.count)
               #print (self.x+bin.start,self.y+i*h_map),len(bin),h_map, color
               rect = patches.Rectangle((self.x+bin.start,self.y+i*h_map),len(bin),h_map,edgecolor='none',facecolor=color)
               ax.add_patch(rect)
        self.box_drawer.draw(ax)
        if self.draw_name:
            self.name_drawer.draw(ax)



class MapDrawer(Drawer):

    COLOR_FUNCS = [color_func_white_red, color_func_white_blue, color_func_white_green]

    def __init__(self, maps, x=0, y=0, h=1., dh=.2, label='Map', scale_ranges=None, color_funcs=None, scale_x=None, scale_y=None, target_selection=None):
        self.x = x
        self.y = y
        self.h = h
        self.dh = dh
        self.scale_x = scale_x
        self.scale_y = scale_y
        self.scale_spacing = 120
        if scale_ranges is None:
            scale_ranges = [(min(map.list()),max(map.list())) for map in maps]
        if color_funcs is None:
            color_funcs = [MapDrawer.COLOR_FUNCS[i%len(MapDrawer.COLOR_FUNCS)] for i in range(len(maps))]
        self.order = [map.name for map in maps]
        self.target_selection = target_selection
        self.chromo_drawers = {}
        self.color_scale_drawers = {}
        for map_ix, (map, scale_range, color_func) in enumerate(zip(maps, scale_ranges, color_funcs)):
            if scale_range[0] == scale_range[1]:
                scale_range[0] = 0
            self.scale_range = scale_range
            for i,target_name in enumerate(map.keys()):
                bins = []
                for bin in map[target_name]:
                    bin = bin.copy()
                    #print map.name,max(map.list()),bin.count,self.scale_range,(bin.count-self.scale_range[0])/(self.scale_range[1]-self.scale_range[0])
                    bin.count = (bin.count-self.scale_range[0])/(self.scale_range[1]-self.scale_range[0])
                    if bin.count < 0:
                        bin.count = 0.0
                    if bin.count > 1:
                        bin.count = 1.0
                    bins.append(bin)
                try:
                    self.chromo_drawers[target_name]
                except:
                    self.chromo_drawers[target_name] = ChromoDrawer(self.x, self.y+i*(self.h+self.dh), map.target_lengths[target_name], self.h, target_name, {map.name:bins}, color_funcs={map.name:color_func}, order=self.order)
                else:
                    self.chromo_drawers[target_name].bins[map.name] = bins
                    self.chromo_drawers[target_name].color_funcs[map.name] = color_func
            self.label = label
            self.color_scale_drawers[map.name] = ColorScaleDrawer(0, 0, map.name, self.scale_range[0], self.scale_range[1], (self.scale_range[1]-self.scale_range[0])/10., color_func)

    def draw(self, ax):
        if self.target_selection is None:
            target_names = self.chromo_drawers.keys()
        else:
            target_names = self.target_selection
        for target_name in target_names:
            self.chromo_drawers[target_name].draw(ax)
        px = self.get_px(ax)
        for i,map_name in enumerate(self.order):
            self.color_scale_drawers[map_name].x = self.abs_x(1.,ax)+self.scale_spacing/2./px[0]+i*self.scale_spacing/px[0]
            self.color_scale_drawers[map_name].y = self.y
            self.color_scale_drawers[map_name].draw(ax)
