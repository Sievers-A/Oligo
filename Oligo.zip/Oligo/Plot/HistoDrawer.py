from Oligo import Prot
import matplotlib.pyplot as plt
from .Drawers import Drawer

class HistoDrawer(Drawer):

    def __init__(self, x=None, y=None, w=None, err=None, color='red', alpha=1., label='Histogram', relative=True, err_color=None, err_capsize=4, show_percentages=False, bins=None):
        if x is not None:
            self.x = x
            self.y = y
            self.w = w
            self.err = err
        elif bins is not None:
            self.x = [b.start for b in bins]
            self.y = [b.count for b in bins]
            self.w = [b.end-b.start for b in bins]
            if len([1 for b in bins if b.std is not None]):
                self.err = [b.std if b.std is not None else 0. for b in bins]
            else:
                self.err = None
            #print self.err
        self.relative = relative
        self.color = color
        self.alpha = alpha
        self.label = label
        self.err_color = err_color
        self.err_capsize = err_capsize
        self.show_percentages = show_percentages
    
    def check_errors_tuples(self, errs):
        for err in errs:
            if self.check_error_tuple(err):
                return True
        return False
        
    def check_error_tuple(self, err):
        try:
            err[0]
        except:
            return False
        else:
            return True
    
    def draw(self, ax):
        s = sum(self.y)
        if self.relative:
            y = [float(yi)/s for yi in self.y]
        else:
            y = self.y[:]
        x = [self.x[i]+self.w[i]/2. for i in range(len(self.x))]
        #print s,y
        plt.bar(x, y, self.w, color=self.color, alpha=self.alpha, label=self.label)
        if self.err:
            if self.err_color is None:
                err_color = self.color
            else:
                err_color = self.err_color
            if self.relative:
                err = [float(erri)/s for erri in self.err]
            else:
                err = self.err[:]
            if self.check_errors_tuples(err):
                temp_err = err
                err = [[], []]
                for e in temp_err:
                    if self.check_error_tuple(e):
                        err[0].append(e[0])
                        err[1].append(e[1])
                    else:
                        err[0].append(e)
                        err[1].append(e)
            plt.errorbar(x, y, color=err_color, yerr=err, capsize=self.err_capsize, fmt='none')
        if self.show_percentages:
            for xi, yi in zip(self.x, y):
                if (ax.xlim is None or xi > ax.xlim[0]) and (ax.xlim is None or xi < ax.xlim[1]) and (ax.ylim is None or yi > ax.ylim[0]) and (ax.ylim is None or yi < ax.ylim[1]):
                    plt.text(xi, yi, str(100.*round(float(y)/s,3))+'%')
