from Oligo import Prot
import matplotlib.pyplot as plt
from .Drawers import Drawer, Drawer3D

class TextDrawer(Drawer):

    def __init__(self, x=None, y=None, texts=None, fontsize=12, rotates=None, props=None):
        if x is None:
            x = list(range(len(y)))
        if y is None:
            y = list(range(len(x)))
        if texts is None:
            texts = ['' for i in range(len(x))]
        if rotates is None:
            rotates = [0]*len(x)
        if props is None:
            props = [None]*len(x)
        self.x = x
        self.y = y
        self.texts = texts
        self.fontsize = fontsize
        self.rotates = rotates
        self.props = props

    def draw(self, ax):
        for x,y,text,rotate,props in zip(self.x, self.y, self.texts, self.rotates, self.props):
            ax.text(x=x, y=y, s=text, fontsize=self.fontsize, rotation=rotate, fontdict=props)
