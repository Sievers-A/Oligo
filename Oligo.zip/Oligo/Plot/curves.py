
def add_function(ax, func, func_args=(), color='r', style='-', limits=[0,100], density=10000):
    l = limits[1]-limits[0]
    xs = [limits[0]+i*l/float(density) for i in range(density)]
    ys = [func(x, *func_args) for x in xs]
    plt.plot(xs, ys, style, color=color)