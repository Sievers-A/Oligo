import matplotlib.pyplot as plt

class FigureCreator(object):

    def __init__(self, drawers, title=None, xlabel=None, ylabel=None, xlim=None, ylim=None, xlog=False, ylog=False, output_filename=None, show_legend=True, figsize=None, dpi=None, adjust_left=0.1, adjust_right=0.9, adjust_top=0.9, adjust_bottom=0.1, xticklabels=None, xticks=None, xticklabels_rotation=None, yticklabels=None, yticks=None, yticklabels_rotation=None, xtick_size=None, ytick_size=None, legend_title=None, legend_bbox_to_anchor=None, legend_loc=None, xticklabels_position=0, grid_para=None):
        self.drawers = drawers
        self.figsize = figsize
        self.dpi = dpi
        self.output_filename = output_filename
        self.title = title
        self.show_legend = show_legend
        self.xlabel = xlabel
        self.ylabel = ylabel
        self.xlim = xlim
        self.ylim = ylim
        self.xlog = xlog
        self.ylog = ylog
        self.adjust_left = adjust_left
        self.adjust_right = adjust_right
        self.adjust_top = adjust_top
        self.adjust_bottom = adjust_bottom
        self.xticklabels = xticklabels
        self.xticks = xticks
        self.xticklabels_rotation = xticklabels_rotation
        self.yticklabels = yticklabels
        self.yticks = yticks
        self.yticklabels_rotation = yticklabels_rotation
        self.xtick_size = xtick_size
        self.ytick_size = ytick_size
        self.legend_title = legend_title
        self.legend_bbox_to_anchor = legend_bbox_to_anchor
        self.legend_loc = legend_loc
        self.xticklabels_position = xticklabels_position
        self.grid_para = grid_para

    def plot(self):
        fig = plt.figure(figsize=self.figsize, dpi=self.dpi)
        ax = plt.subplot(1, 1, 1)
        #fig, ax2 = plt.subplots()
        fig.subplots_adjust(left=self.adjust_left, right=self.adjust_right, bottom=self.adjust_bottom, top=self.adjust_top)
        
        #ax.tick_params(axis='both', which='major')
        #plt.ticklabel_format(style='sci', axis='x', scilimits=(0,3), useMathText=True, labelsize=28)
        plt.ticklabel_format(style='sci', axis='x', scilimits=(0,3), useMathText=True)
        
        if self.xticklabels is not None:
            ax.set_xticklabels(self.xticklabels)
        if self.xticks is not None:
            ax.set_xticks(self.xticks)
        if self.xtick_size is not None:
            for tick in ax.xaxis.get_major_ticks():
                tick.label.set_fontsize(self.xtick_size)
        if self.xticklabels_rotation is not None:
            ax.tick_params(axis='x', rotation=self.xticklabels_rotation)
        if self.yticklabels is not None:
            ax.set_yticklabels(self.yticklabels)
        if self.yticks is not None:
            ax.set_yticks(self.yticks)
        if self.ytick_size is not None:
            for tick in ax.yaxis.get_major_ticks():
                tick.label.set_fontsize(self.ytick_size)
        if self.yticklabels_rotation is not None:
            ax.tick_params(axis='y', rotation=self.yticklabels_rotation)
        if self.xticklabels_position:
            ax.xaxis.tick_top()
        
        
        
        if self.xlog:
            ax.set_xscale('log')
        if self.ylog:
            ax.set_yscale('log')
        if self.title is not None:
            plt.title(self.title)
        if self.xlabel is not None:
            plt.xlabel(self.xlabel)
        if self.ylabel is not None:
            plt.ylabel(self.ylabel)
        if self.xlim is not None:
            plt.xlim(*self.xlim)
            #if self.xlim[0] is not None:
            #    ax.set_xlim(xmin=self.xlim[0])
            #if self.xlim[1] is not None:
            #    ax.set_xlim(xmax=self.xlim[1])
        if self.ylim is not None:
            plt.ylim(*self.ylim)
            #if self.ylim[0] is not None:
            #    ax.set_ylim(ymin=self.ylim[0])
            #if self.ylim[1] is not None:
            #    ax.set_ylim(xmax=self.ylim[1])
            
        
        #print ax.get_xlim(),ax.get_xbound()    
            
        for drawer in self.drawers:
            drawer.draw(ax)
        
        if self.grid_para is not None:
            plt.grid(*self.grid_para, zorder=-10)
        
        if self.show_legend:
            plt.legend(title=self.legend_title, bbox_to_anchor=self.legend_bbox_to_anchor, loc=self.legend_loc)
            
        #print ax.get_xlim(),ax.get_xbound()
        
        if self.output_filename is None:
            plt.show()
        else:
            plt.savefig(self.output_filename)

class RowFigureCreator(FigureCreator):

    def __init__(self, drawers, cols=1, titles=None, xlabels=None, ylabels=None, xlims=None, ylims=None, xlogs=False, ylogs=False, output_filename=None, show_legend=None, figsize=None, dpi=None, adjust_left=0.1, adjust_right=0.9, adjust_top=0.9, adjust_bottom=0.1, xticklabels=None, xticks=None, xticklabels_rotations=None, yticklabels=None, yticks=None, yticklabels_rotations=None, xtick_sizes=None, ytick_sizes=None, padding=3.0):
        self.drawers = drawers
        self.figsize = figsize
        self.dpi = dpi
        self.output_filename = output_filename
        self.titles = titles
        self.show_legend = show_legend
        self.xlabels = xlabels
        self.ylabels = ylabels
        self.xlims = xlims
        self.ylims = ylims
        self.xlogs = xlogs
        self.ylogs = ylogs
        self.adjust_left = adjust_left
        self.adjust_right = adjust_right
        self.adjust_top = adjust_top
        self.adjust_bottom = adjust_bottom
        self.xticklabels = xticklabels
        self.xticks = xticks
        self.xticklabels_rotations = xticklabels_rotations
        self.yticklabels = yticklabels
        self.yticks = yticks
        self.yticklabels_rotations = yticklabels_rotations
        self.xtick_sizes = xtick_sizes
        self.ytick_sizes = ytick_sizes
        self.cols = cols
        self.padding = padding
    
    def plot(self):
        fig = plt.figure(figsize=self.figsize, dpi=self.dpi)
        n = len(self.drawers)
        fig.subplots_adjust(left=self.adjust_left, right=self.adjust_right, bottom=self.adjust_bottom, top=self.adjust_top)
        #plt.ticklabel_format(style='sci', axis='x', scilimits=(0,3), useMathText=True, labelsize=28)
        plt.ticklabel_format(style='sci', axis='x', scilimits=(0,3), useMathText=True)
        
        
        for i in range(n):
            ax = plt.subplot(int(n/self.cols), int(self.cols), i+1)
           
            if self.xticklabels is not None:
                ax.set_xticklabels(self.xticklabels[i])
            if self.xticks is not None and self.xticks[i] is not None:
                #print self.xticks[i]
                ax.set_xticks(self.xticks[i])
            if self.xtick_sizes is not None and self.xtick_sizes[i] is not None :
                for tick in ax.xaxis.get_major_ticks():
                    tick.label.set_fontsize(self.xtick_sizes[i])
            if self.xticklabels_rotations is not None and self.xticklabels_rotations[i] is not None:
                ax.tick_params(axis='x', rotation=self.xticklabels_rotations[i])
            if self.yticklabels is not None and self.yticklabels[i] is not None:
                ax.set_yticklabels(self.yticklabels[i])
            if self.yticks is not None and self.yticks[i] is not None:
                ax.set_yticks(self.yticks[i])
            if self.ytick_sizes is not None and self.ytick_sizes[i] is not None:
                for tick in ax.yaxis.get_major_ticks():
                    tick.label.set_fontsize(self.ytick_sizes[i])
            if self.yticklabels_rotations is not None and self.yticklabels_rotations[i] is not None:
                ax.tick_params(axis='y', rotation=self.yticklabels_rotations[i])
            
            
            
            if self.xlogs and self.xlogs[i]:
                ax.set_xscale('log')
            if self.ylogs and self.ylogs[i]:
                ax.set_yscale('log')
            if self.titles is not None and self.titles[i] is not None:
                plt.title(self.titles[i])
            if self.xlabels is not None and self.xlabels[i] is not None:
                plt.xlabel(self.xlabels[i])
            if self.ylabels is not None and self.ylabels[i] is not None:
                plt.ylabel(self.ylabels[i])
            if self.xlims is not None and self.xlims[i] is not None:
                plt.xlim(self.xlims[i])
            if self.ylims is not None and self.ylims[i] is not None:
                plt.ylim(self.ylims[i])
                
                
            for drawer in self.drawers[i]:
                drawer.draw(ax)
        
        fig.tight_layout(pad=3., h_pad=self.padding)
        
        if self.show_legend:
            plt.legend()
        if self.output_filename is None:
            plt.show()
        else:
            plt.savefig(self.output_filename)

class FigureCreator3D(FigureCreator):

    def __init__(self, drawers, title=None, xlabel=None, ylabel=None, zlabel=None, xlim=None, ylim=None, zlim=None, xlog=False, ylog=False, zlog=None, output_filename=None, show_legend=True, figsize=None, dpi=None, adjust_left=0.1, adjust_right=0.9, adjust_top=0.9, adjust_bottom=0.1):
        self.drawers = drawers
        self.figsize = figsize
        self.dpi = dpi
        self.output_filename = output_filename
        self.title = title
        self.show_legend = show_legend
        self.xlabel = xlabel
        self.ylabel = ylabel
        self.zlabel = zlabel
        self.xlim = xlim
        self.ylim = ylim
        self.zlim = zlim
        self.xlog = xlog
        self.ylog = ylog
        self.zlog = zlog
        self.adjust_left = adjust_left
        self.adjust_right = adjust_right
        self.adjust_top = adjust_top
        self.adjust_bottom = adjust_bottom

    def plot(self):
        fig = plt.figure(figsize=self.figsize, dpi=self.dpi)
        ax = plt.subplot(1, 1, 1, projection='3d')
        #fig, ax2 = plt.subplots()
        fig.subplots_adjust(left=self.adjust_left, right=self.adjust_right, bottom=self.adjust_bottom, top=self.adjust_top)

        if self.xlog:
            ax.set_xscale('log')
        if self.ylog:
            ax.set_yscale('log')
        if self.zlog:
            ax.set_zscale('log')
        if self.title is not None:
            plt.title(self.title)
        if self.xlabel is not None:
            plt.xlabel(self.xlabel)
        if self.ylabel is not None:
            plt.ylabel(self.ylabel)
        if self.zlabel is not None:
            plt.zlabel(self.zlabel)
        if self.xlim is not None:
            plt.xlim(self.xlim)
        if self.ylim is not None:
            plt.ylim(self.ylim)
        if self.zlim is not None:
            plt.ylim(self.zlim)
        for drawer in self.drawers:
            drawer.draw(ax)
        if self.show_legend:
            plt.legend()
        if self.output_filename is None:
            plt.show()
        else:
            plt.savefig(self.output_filename)
