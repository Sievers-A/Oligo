from Oligo import Prot
import matplotlib.pyplot as plt
from .Drawers import Drawer

try:
    from matplotlib_venn import venn2, venn3, venn2_circles, venn3_circles
    venn_installed = True
except:
    venn_installed = False

class VennDrawer(Drawer):

    def __init__(self, set1=None, set2=None, set3=None, n1=None, n2=None, n3=None, n12=None, n23=None, n13=None, n123=None, set_labels=None, draw_borders=False, linestyle='-', linewidth=1, linecolor='black', linestyles=None, linewidths=None, linecolors=None):
        if not venn_installed:
            Prot.warn('matplotlib_venn is not installed. You will not be able to draw Venn-Diagrams.','Module Missing')
        if n1 is None:
            n1 = len(set1)
        if n2 is None:
            n2 = len(set2)
        if n3 is None and set3 is not None:
            n3 = len(set3)
        if n12 is None:
            n12 = len(set(set1).intersection(set(set2)))
            n1 -= n12
            n2 -= n12
        if n13 is None and set3 is not None:
            n13 = len(set(set1).intersection(set(set3)))
            n1 -= n13
            n3 -= n13
        if n23 is None and set3 is not None:
            n23 = len(set(set2).intersection(set(set3)))
            n2 -= n23
            n3 -= n23
        if n123 is None and set3 is not None:
            n123 = len(set(set2).intersection(set(set3)).intersection(set(set1)))
            n12 -= n123
            n23 -= n123
            n1 += n123
            n2 += n123
            n3 += n123
        self.n1 = n1
        self.n2 = n2
        self.n3 = n3
        self.n12 = n12
        self.n13 = n13
        self.n23 = n23
        self.n123 = n123
        self.set_labels = set_labels
        self.draw_borders = draw_borders
        self.linestyle = linestyle
        self.linewidth = linewidth
        self.linecolor = linecolor
        self.linestyles = linestyles
        self.linewidths = linewidths
        self.linecolors = linecolors
        
    
    def n_sets(self):
        if self.n3 is not None:
            return 3
        else:
            return 2
    
    def draw(self, ax):
        if self.n_sets() == 2:
            venn2(subsets=(self.n1, self.n2, self.n12), set_labels=self.set_labels)
            if self.draw_borders:
                c = venn2_circles(subsets=(self.n1, self.n2, self.n12), linestyle=self.linestyle, linewidth=self.linewidth, color=self.linecolor)
        else:
            venn3(subsets=(self.n1, self.n2, self.n12, self.n3, self.n13, self.n23, self.n123), set_labels=self.set_labels)
            if self.draw_borders:
                c = venn3_circles(subsets=(self.n1, self.n2, self.n12, self.n3, self.n13, self.n23, self.n123), linestyle=self.linestyle, linewidth=self.linewidth, color=self.linecolor)
        if self.draw_borders:
            for i in range(len(c)):
                if self.linestyles is not None and self.linestyles[i] is not None:
                    c[i].set_ls(self.linestyles[i])
                if self.linewidths is not None and self.linewidths[i] is not None:
                    c[i].set_lw(self.linewidths[i])
                if self.linecolors is not None and self.linecolors[i] is not None:
                    c[i].set_color(self.linecolors[i])
