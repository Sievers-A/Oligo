from Oligo import Prot
import matplotlib.pyplot as plt
from .FigureCreators import FigureCreator, RowFigureCreator

class Drawer(object):

    def draw(self):
        pass

    def plot(self, output_filename=None, title='', xlim=None, ylim=None, xlog=False, ylog=False, xlabel='', ylabel='', dpi=None, figsize=None, adjust_left=0.1, adjust_right=0.9, adjust_top=0.9, adjust_bottom=0.1, xticklabels=None, xticks=None, xticklabels_rotation=None, yticklabels=None, yticks=None, yticklabels_rotation=None, xtick_size=None, ytick_size=None, legend_title=None, legend_bbox_to_anchor=None, legend_loc=None, xticklabels_position=0, show_legend=True, grid_para=None, verbose=1):
        if output_filename is not None and verbose:
            Prot.write('Saving image to %s.' % output_filename)
        creator = FigureCreator([self], output_filename=output_filename, title=title, xlim=xlim, ylim=ylim, xlog=xlog, ylog=ylog, xlabel=xlabel, ylabel=ylabel, dpi=dpi, figsize=figsize, adjust_left=adjust_left, adjust_right=adjust_right, adjust_top=adjust_top, adjust_bottom=adjust_bottom, xticklabels=xticklabels, xticks=xticks, xticklabels_rotation=xticklabels_rotation, yticklabels=yticklabels, yticks=yticks, yticklabels_rotation=yticklabels_rotation, xtick_size=xtick_size, ytick_size=ytick_size, legend_title=legend_title, legend_bbox_to_anchor=legend_bbox_to_anchor, legend_loc=legend_loc, xticklabels_position=xticklabels_position, show_legend=show_legend, grid_para=grid_para)
        creator.plot()
    
    def plot_rows():
        if output_filename is not None and verbose:
            Prot.write('Saving image to %s.' % output_filename)
        creator = RowFigureCreator([self], output_filename=output_filename, title=title, xlim=xlim, ylim=ylim, xlog=xlog, ylog=ylog, xlabel=xlabel, ylabel=ylabel, dpi=dpi, figsize=figsize, adjust_left=adjust_left, adjust_right=adjust_right, adjust_top=adjust_top, adjust_bottom=adjust_bottom, xticklabels=xticklabels, xticks=xticks, xticklabels_rotation=xticklabels_rotation, yticklabels=yticklabels, yticks=yticks, yticklabels_rotation=yticklabels_rotation, xtick_size=xtick_size, ytick_size=ytick_size)
        creator.plot()
    
    def abs_x(self, rel_x, ax):
        xlim = ax.get_xlim()
        x_size = xlim[1]-xlim[0]
        #print xlim, x_size
        return rel_x*(x_size)+xlim[0]

    def abs_y(self, rel_y, ax):
        ylim = ax.get_ylim()
        y_size = ylim[1]-ylim[0]
        return rel_y*(y_size)+ylim[0]

    #def axis_to_pixel(self, axis_x, axis_y, ax):
    #    px = self.get_px()
    #    xlim = ax.get_xlim()
    #    ylim = ax.get_ylim()
    #    print ax.get_dpi()
    #    print px, xlim, ylim
    
    def get_image_dimensions(self):
        fig = plt.gcf()
        px_x_size = fig.get_size_inches()[0]*fig.dpi
        px_y_size = fig.get_size_inches()[1]*fig.dpi
        return px_x_size, px_y_size
        
    def get_axis_dimensions(self, ax):
        img_px_x_size, img_px_y_size = self.get_image_dimensions()
        posi = ax.get_position()
        x_start = posi.x0 * img_px_x_size
        y_start = posi.y0 * img_px_y_size
        x_end = posi.x1 * img_px_x_size
        y_end = posi.y1 * img_px_y_size
        return x_start, y_start, x_end, y_end
    
    def px_x_to_axis_x(self, px_x, ax):
        ax_px_x_start, ax_px_y_start, ax_px_x_end, ax_px_y_end = self.get_axis_dimensions(ax)
        ax_px_x_size = abs(ax_px_x_end-ax_px_x_start)
        xlim = ax.get_xlim()
        ax_x_size = abs(xlim[1]-xlim[0])
        axis_x = px_x * ax_x_size/ax_px_x_size + xlim[0]
        return axis_x
    
    def axis_y_size_to_pixel(self, axis_size, ax):
        axis_start_x, axis_start_y, axis_end_x, axis_end_y = self.get_axis_dimensions(ax)
        axis_length = abs(axis_end_y - axis_start_y)
        ylim = ax.get_ylim()
        #print axis_size, abs(ylim[1]-ylim[0]), axis_length, float(axis_size)/abs(ylim[1]-ylim[0]) * axis_length
        return float(axis_size)/abs(ylim[1]-ylim[0]) * axis_length 
    
    def axis_y_size_to_dpi(self, axis_size, ax):
        fig = plt.gcf()
        #print self.axis_y_size_to_pixel(axis_size, ax)/fig.dpi
        return self.axis_y_size_to_pixel(axis_size, ax)/fig.dpi
    
    def dpi_x_size_to_axis(self, dpi_size, ax):
        fig = plt.gcf()
        px_size = dpi_size * fig.dpi
        return self.px_x_size_to_axis(px_size, ax)
    
    def dpi_y_size_to_axis(self, dpi_size, ax):
        fig = plt.gcf()
        px_size = dpi_size * fig.dpi
        return self.px_y_size_to_axis(px_size, ax)
    
    def px_x_size_to_axis(self, px_size, ax):
        axis_start_x, axis_start_y, axis_end_x, axis_end_y = self.get_axis_dimensions(ax)
        axis_length = abs(axis_end_x - axis_start_x)
        xlim = ax.get_xlim()
        return float(px_size)/axis_length * abs(xlim[1]-xlim[0])
    
    def px_y_size_to_axis(self, px_size, ax):
        axis_start_x, axis_start_y, axis_end_x, axis_end_y = self.get_axis_dimensions(ax)
        axis_length = abs(axis_end_y - axis_start_y)
        ylim = ax.get_ylim()
        return float(px_size)/axis_length * abs(ylim[1]-ylim[0])
    
    def get_px(self, ax):
        return ax.transData.transform((1, 1))-ax.transData.transform((0, 0))

    #def px_x_size_to_axis(px_x_size, ax):
        
        

class Drawer3D(Drawer):

    def plot(self, output_filename=None, title='', xlim=None, ylim=None, xlog=False, ylog=False, xlabel='', ylabel='', dpi=None, figsize=None, adjust_left=0.1, adjust_right=0.9, adjust_top=0.9, adjust_bottom=0.1, verbose=1):
        if output_filename is not None and verbose:
            Prot.write('Saving image to %s.' % output_filename)
        creator = FigureCreator3D([self], output_filename=output_filename, title=title, xlim=xlim, ylim=ylim, xlog=xlog, ylog=ylog, xlabel=xlabel, ylabel=ylabel, dpi=dpi, figsize=figsize, adjust_left=adjust_left, adjust_right=adjust_right, adjust_top=adjust_top, adjust_bottom=adjust_bottom)
        creator.plot()

from .CurveDrawer import CurveDrawer
from .TextDrawer import TextDrawer
from .HistoDrawer import HistoDrawer
from .HeatmapDrawer import HeatmapDrawer
from . import MapDrawers
from .MapDrawers import MapDrawer, color_func_blue_white_red
from .VennDrawer import VennDrawer
from .LineDrawer import LineDrawer

class MultiDrawer(Drawer):

    def __init__(self, drawers):
        self.drawers = drawers

    def draw(self, ax):
        for drawer in self.drawers:
            drawer.draw(ax)
