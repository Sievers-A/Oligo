from math import log10, floor

def significant_digits(number, n_digits, ref_number=None):
    if ref_number is None:
        ref_number = number
    try:
        d = n_digits-1-int(floor(log10(abs(ref_number))))
    except:
        return number
    number = round(number, d)
    if d < 0:
        number = int(number)
    return number
    
def significant_bp_unit(number, n_digits):
    unit = 'bp'
    if number > 1000:
        number = number/1000.
        unit = 'kbp'
    if number > 1000:
        number = number/1000.
        unit = 'Mbp'
    return str(significant_digits(number, n_digits))+' '+unit
    
sd = significant_digits
sbp = significant_bp_unit