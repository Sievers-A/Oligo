import numpy as np
import matplotlib.pyplot as plt
from Oligo import Prot

def add_histo(ax, bins, width=0.9, color='b', relative=False, show_percetages=False, label='Histo', n_limits=None):
    x = [i for i in range(len(bins))]
    s = sum([bin.count for bin in bins])
    if not relative:
        h = [bin.count for bin in bins]
    else:
        h = [float(bin.count)/s for bin in bins]
    w = width
    err = []
    show_err = False
    for bin in bins:
        if bin.std:
            show_err = True
            if not relative:
                err.append(bin.std)
            else:
                err.append(float(bin.std)/s)
        else:
            err.append(0.)
    plt.bar(x, h, w, color=color, alpha=0.5, label=label)
    if show_err:
        plt.errorbar(x, h, color=color, yerr=err, capsize=5, fmt='none')
    if show_percetages:
        for i, bin in enumerate(bins):
            if (n_limits is None or i > n_limits[0]) and (n_limits is None or i < n_limits[1]):
                plt.text(i, h[i], str(100.*round(float(bin.count)/s,3))+'%')
    
def draw_histo(ax, bins, width=0.9, color='b', relative=False, show_percetages=False, custom_ticks=None, xlabel=None, title='', n_limits=None):
    add_histo(ax, bins, width, color, relative, show_percetages, n_limits=n_limits)
    if custom_ticks is not None:
        plt.xticks(*custom_ticks)
    plt.title(title)
    plt.xlabel(xlabel)
    if n_limits:
        plt.xlim(*n_limits)
    else:
        plt.xlim(-.5,None)

def plot_histo(bins, width=0.9, color='b', relative=False, show_percetages=False, output_filename=None, xlabel=None, title='', figsize=(10,6), dpi=40, custom_ticks=None, n_limits=None):
    plt.figure(figsize=figsize, dpi=dpi)
    ax = plt.subplot(1, 1, 1)
    draw_histo(ax, bins, width, color, relative, custom_ticks=custom_ticks, xlabel=xlabel, title=title, n_limits=n_limits, show_percetages=show_percetages)
    if output_filename is None:
        plt.show()
    else:
        plt.savefig(output_filename)
        
def plot_histos(bins_list, width=0.9, color='b', relative=False, show_percetages=False, xlabel=None, titles=[], output_filename=None, figsize=None, dpi=400, cols=4, custom_ticks=None, n_limits=None, verbose=1):
    if verbose:
        Prot.write('Plotting %s Histograms.' % len(bins_list))
    if figsize is None:
        figsize = (10*cols,6*np.ceil(float(len(bins_list))/cols))
    plt.figure(figsize=figsize, dpi=dpi)
    rows = np.ceil(float(len(bins_list))/cols)
    for i, bins in enumerate(bins_list):
        ax = plt.subplot(rows, cols, i+1)
        draw_histo(ax, bins, width, color, relative, show_percetages, custom_ticks, xlabel, titles[i], n_limits)
    if output_filename is None:
        plt.show()
    else:
        plt.savefig(output_filename)