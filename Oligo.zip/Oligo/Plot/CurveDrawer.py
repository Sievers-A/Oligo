from Oligo import Prot
import matplotlib.pyplot as plt
from .Drawers import Drawer, Drawer3D

class CurveDrawer(Drawer):

    def __init__(self, x=None, y=None, x_err=None, y_err=None, color='red', linestyle='-', linewidth=1., alpha=1., label='Curve', err_color=None, err_capsize=4, markersize=1):
        if x is None:
            x = list(range(len(y)))
        if y is None:
            y = list(range(len(x)))
        self.x = x
        self.y = y
        self.x_err = x_err
        self.y_err = y_err
        self.color = color
        self.linestyle = linestyle
        self.linewidth = linewidth
        self.alpha = alpha
        self.label = label
        self.err_color = err_color
        self.err_capsize = err_capsize
        self.markersize = markersize

    def draw(self, ax):
        plt.plot(self.x, self.y, self.linestyle, linewidth=self.linewidth, color=self.color, label=self.label, alpha=self.alpha, markersize=self.markersize)
        if self.x_err is not None or self.y_err is not None:
            plt.errorbar(self.x, self.y, color=self.err_color, yerr=self.y_err, xerr=self.x_err, capsize=self.err_capsize, fmt='none')

class CurveDrawer3D(Drawer3D):

    def __init__(self, x=None, y=None, z=None, x_err=None, y_err=None, z_err=None, color='red', linestyle='-', linewidth=1., alpha=1., label='Curve', err_color=None, err_capsize=4):
        if x is None:
            x = list(range(len(y)))
        if y is None:
            y = list(range(len(x)))
        if z is None:
            z = list(range(len(x)))
        self.x = x
        self.y = y
        self.z = z
        self.x_err = x_err
        self.y_err = y_err
        self.z_err = z_err
        self.color = color
        self.linestyle = linestyle
        self.linewidth = linewidth
        self.alpha = alpha
        self.label = label
        self.err_color = err_color
        self.err_capsize = err_capsize

    def draw(self, ax):
        plt.plot(self.x, self.y, self.z, self.linestyle, linewidth=self.linewidth, color=self.color, label=self.label, alpha=self.alpha)
        if self.x_err is not None or self.y_err is not None or self-z_err is not None:
            plt.errorbar(self.x, self.y, self.z, color=self.err_color, yerr=self.y_err, xerr=self.x_err, zerr=self.z_err, capsize=self.err_capsize, fmt='none')
