from Oligo import Prot
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from .Drawers import Drawer

class RectDrawer(Drawer):

    def __init__(self, x, y, width, height, color='red', linewidth=1, facecolor=None, edgecolor=None, label=None):
        # colors can be given as (R,G,B,A) values for opacities
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        if facecolor is None:
            self.facecolor = color
        if edgecolor is None:
            self.edgecolor = color
        self.linewidth = linewidth
        self.label = label
        

    def draw(self, ax):
        rect = patches.Rectangle((self.x, self.y), self.width, self.height, linewidth=self.linewidth, edgecolor=self.edgecolor, facecolor=self.facecolor)
        ax.add_patch(rect)
