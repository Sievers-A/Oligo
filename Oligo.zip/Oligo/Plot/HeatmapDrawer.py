from Oligo import Prot
import matplotlib.pyplot as plt
from .Drawers import Drawer
import seaborn as sns

class HeatmapDrawer(Drawer):

    def __init__(self, data, cmap='hot', xticklabels=False, yticklabels=False, vmin=None, vmax=None, linewidth=0.0, show_values=False, labels_at_top=False, annot=None, xticks_rotation=90, yticks_rotation=0):
        self.data = data
        self.cmap = cmap
        self.vmin = vmin
        self.vmax = vmax
        self.linewidth = linewidth
        self.xticklabels = xticklabels
        self.yticklabels = yticklabels
        self.show_values = show_values
        self.labels_at_top = labels_at_top
        self.annot = annot
        self.xticks_rotation = xticks_rotation
        self.yticks_rotation = yticks_rotation

    def draw(self, ax):
        ax = sns.heatmap(self.data, linewidths=self.linewidth, cmap=self.cmap, vmin=self.vmin, vmax=self.vmax, xticklabels=self.xticklabels, yticklabels=self.yticklabels, annot=self.show_values, fmt='')
        
        if self.labels_at_top:
            ax.xaxis.tick_top()
            ax.xaxis.set_label_position('top')
        plt.yticks(rotation=self.yticks_rotation)
        plt.xticks(rotation=self.xticks_rotation)