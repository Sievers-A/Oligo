from Oligo import Prot
import matplotlib.pyplot as plt
from .Drawers import Drawer
import seaborn as sns

class HeatmapDrawer(Drawer):

    def __init__(self, data, cmap='hot', xticklabels=False, yticklabels=False, vmin=None, vmax=None, linewidth=0.0, show_values=False, labels_at_top=False):
        self.data = data
        self.cmap = cmap
        self.vmin = vmin
        self.vmax = vmax
        self.linewidth = linewidth
        self.xticklabels = xticklabels
        self.yticklabels = yticklabels
        self.show_values = show_values
        self.labels_at_top = labels_at_top

    def draw(self, ax):
        ax = sns.heatmap(self.data, linewidths=self.linewidth, cmap=self.cmap, vmin=self.vmin, vmax=self.vmax, xticklabels=self.xticklabels, yticklabels=self.yticklabels, annot=self.show_values)
            