import matplotlib.pyplot as plt
from histos import add_histo
from curves import add_function
    

def draw_distance_histo(ax, dist_bins, ref_dist_bins, width=0.9, color='b', relative=False, show_percetages=False, custom_ticks=None, title='', n_limits=None):
    add_histo(ax, dist_bins, width, 'green', relative, show_percetages, n_limits=n_limits, label='Data')
    add_histo(ax, ref_dist_bins, width, 'red', relative, show_percetages, n_limits=n_limits, label='Simulation')
    #add_function() # theory curve
    if custom_ticks is not None:
        plt.xticks(*custom_ticks)
    plt.title(title)
    plt.xlabel('Relative Frequency')
    plt.ylabel('Distance [bp]')
    
    if n_limits:
        plt.xlim(*n_limits)
    else:
        plt.xlim(-.5,None)
    
def plot_distance_histo(dist_bins, ref_dist_bins, width=0.9, color='b', relative=False, show_percetages=False, output_filename=None, xlabel=None, title='', figsize=(10,6), dpi=100, custom_ticks=None, n_limits=None):
    plt.figure(figsize=figsize, dpi=dpi)
    ax = plt.subplot(1, 1, 1)
    draw_distance_histo(ax, dist_bins, ref_dist_bins, width, color, relative, custom_ticks=custom_ticks, title=title, n_limits=n_limits, show_percetages=show_percetages)
    plt.legend()
    if output_filename is None:
        plt.show()
    else:
        plt.savefig(output_filename)
    
def draw_distance_resuduals():
    pass