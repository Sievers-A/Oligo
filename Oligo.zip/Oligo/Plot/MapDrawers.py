from Oligo import Prot
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from .Drawers import Drawer
import numpy as np

class TextDrawer(Drawer):

    def __init__(self, text, x, y, fontsize=12, relative_fontsize=True):
        self.text = text
        self.x = x
        self.y = y
        self.fontsize = fontsize
        self.relative_fontsize = relative_fontsize

    def draw(self, ax):
        if self.relative_fontsize:
            #print self.fontsize,self.fontsize/24.,self.axis_y_size_to_dpi(self.fontsize/24., ax)
            fontsize = round(60*self.axis_y_size_to_dpi(self.fontsize/24., ax))
        else:
            fontsize = self.fontsize
        #print self.text,fontsize
        ax.text(self.x, self.y, self.text, fontsize=fontsize, clip_on=True)

class BoxDrawer(Drawer):

    def __init__(self, x, y, w, h, color='red', fill_color=None, linewidth=1., alpha=1., label='Box', clip_on=True):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.color = color
        self.fill_color = fill_color
        self.linewidth = linewidth
        self.alpha = alpha
        self.label = label
        self.clip_on = clip_on

    def draw(self, ax):
        if self.fill_color is None:
            fill_color = 'none'
        rect = patches.Rectangle((self.x,self.y),self.w,self.h,linewidth=self.linewidth,edgecolor=self.color,facecolor=fill_color,alpha=self.alpha,label=self.label, clip_on=self.clip_on)
        ax.add_patch(rect)

def color_func_white_red(value):
    return (1.,1.-value,1.-value)

def color_func_white_blue(value):
    return (1.-value,1.-value,1.)

def color_func_white_green(value):
    return (1.-value,0.75+0.25*(1.-value),1.-value)

def color_func_blue_white_red(value):
    if value < 0.5:
        return color_func_white_blue(1.-2*value)
    else:
        return color_func_white_red(2*value-1.)

class ColorScaleDrawer(Drawer):

    def __init__(self, x, y, name, scale_start, scale_end, tick_step, color_func, w=1.5, h=12, color_steps=1000, fontsize=24, precision=2):
        self.name = name
        self.scale_start = scale_start
        self.scale_end = scale_end
        self.color_func = color_func
        self.tick_step = tick_step
        self.color_steps = color_steps
        self.fontsize = fontsize
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.precision = precision

    def draw(self, ax):
        # Calculate Coordinates and Sizes
        x = self.x
        y = self.y
        px = self.get_px(ax)
        w = self.dpi_x_size_to_axis(self.w, ax)#self.w/px[0]
        h = self.dpi_y_size_to_axis(self.h, ax)#self.h/px[1]
        # Draw Color Gradient
        draw_step = float(h)/self.color_steps
        color_step = 1./self.color_steps
        for i in range(self.color_steps):
            color = self.color_func(1.-i*color_step)
            rect = patches.Rectangle((x,y+h-i*draw_step),w,draw_step,edgecolor='none',facecolor=color, clip_on=False)
            ax.add_patch(rect)
        # Draw Box
        box_drawer = BoxDrawer(x,y,w,h,'black',label=None, clip_on=False)
        box_drawer.draw(ax)
        # Draw Ticks
        plt.plot([x+w, x+1.25*w], [y, y], color = 'black', clip_on=False, zorder=100, linewidth=1)
        ax.text(x+w*1.1, y, str(round(self.scale_start,self.precision)), style='normal', size=self.fontsize, name='Times New Roman')

        step = float(h)*self.tick_step/(self.scale_end-self.scale_start)
        dy = step
        i = 1
        while dy < h:
            plt.plot([x+w, x+.75*w], [y+dy, y+dy], color = 'black', clip_on=False, zorder=100, linewidth=1)
            ax.text(x+w*1.1, y+dy, str(round(self.scale_start+i*self.tick_step,self.precision)), style='normal', size=self.fontsize, name='Times New Roman')
            dy += step
            i += 1
        plt.plot([x+w, x+1.25*w], [y+h, y+h], color = 'black', clip_on=False, zorder=100, linewidth=1)
        #ax.text(x+w*1.1, y+dy, str(round(self.scale_end,self.precision)), style='normal', size=self.fontsize, name='Times New Roman')
        # Draw Name
        #ax.text(x-25/px[0], y+h*0.8, self.name, style='normal', rotation='vertical', size=self.fontsize*1.5, name='Times New Roman')
        ax.text(x-self.dpi_x_size_to_axis(0.5, ax), y+h*0.9, self.name, style='normal', rotation='vertical', size=self.fontsize*1.5, name='Times New Roman')

class ChromoDrawer(Drawer):

    def __init__(self, x, y, w, h, name, bins, color_funcs, draw_name=True, fontsize=12, order=None):
        self.name = name
        self.bins = bins
        self.color_funcs = color_funcs
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.box_drawer = BoxDrawer(x,y,w,h,'black',label=None)
        self.draw_name = draw_name
        #self.name_drawer = TextDrawer(self.name, self.x, self.y+1.1*h, fontsize*h)
        self.name_drawer = TextDrawer(self.name, self.x, self.y+1.1*h, fontsize*h)
        self.order = order

    def draw(self, ax):
        n_maps = len(self.order)
        h_map = float(self.h)/n_maps
        for i,map_name in enumerate(self.order):
            if map_name in self.bins.keys():
                for bin in self.bins[map_name]:
                   #print bin.count
                   color = self.color_funcs[map_name](bin.count)
                   #print (self.x+bin.start,self.y+i*h_map),len(bin),h_map, color
                   rect = patches.Rectangle((self.x+bin.start,self.y+i*h_map),bin.size(),h_map,edgecolor='none',facecolor=color)
                   ax.add_patch(rect)
        self.box_drawer.draw(ax)
        if self.draw_name:
            self.name_drawer.draw(ax)



class MapDrawer(Drawer):

    COLOR_FUNCS = [color_func_white_red, color_func_white_blue, color_func_white_green]

    def __init__(self, maps, x=0, y=0, h=1., dh=.5, label='Map', scale_ranges=None, color_funcs=None, scale_x=None, scale_y=None, fontsize=12, scale_steps=None, selected_targets=None, color_scale_mask=None, positions=None):
        self.x = x
        self.y = y
        self.h = h
        self.dh = dh
        self.scale_x = scale_x
        self.scale_y = scale_y
        self.scale_spacing = 4
        self.selected_targets = selected_targets
        self.color_scale_mask = color_scale_mask
        if scale_ranges is None:
            scale_ranges = [(min(map.list()),max(map.list())) for map in maps]
        else:
            for i,scale_range in enumerate(scale_ranges):
                if scale_range is None:
                    scale_ranges[i] = (min(maps[i].list()),max(maps[i].list()))
        if color_funcs is None:
            color_funcs = [MapDrawer.COLOR_FUNCS[i%len(MapDrawer.COLOR_FUNCS)] for i in range(len(maps))]
        self.order = [map.name for map in maps]
        self.chromo_drawers = {}
        self.color_scale_drawers = {}
        for map_ix, (map, scale_range, color_func) in enumerate(zip(maps, scale_ranges, color_funcs)):
            if scale_range is None or scale_range[0] == scale_range[1]:
                if scale_range is None:
                    scale_range = [0,0]
                scale_range[0] = 0
            self.scale_range = scale_range
            if selected_targets is None:
                target_names = map.keys()
            else:
                target_names = selected_targets
            for i,target_name in enumerate(target_names):
                bins = []
                if target_name in map.keys():
                    for bin in map[target_name]:
                        bin = bin.copy()
                        bin.count = (bin.count-self.scale_range[0])/(self.scale_range[1]-self.scale_range[0])
                        if bin.count < 0:
                            bin.count = 0.0
                        if bin.count > 1:
                            bin.count = 1.0
                        bins.append(bin)
                    try:
                        self.chromo_drawers[target_name]
                    except:
                        self.chromo_drawers[target_name] = ChromoDrawer(self.x, self.y+i*(self.h+self.dh), np.ceil(float(map.target_lengths[target_name])/map.resolution)*map.resolution, self.h, target_name, {map.name:bins}, color_funcs={map.name:color_func}, order=self.order, fontsize=fontsize)
                    else:
                        self.chromo_drawers[target_name].bins[map.name] = bins
                        self.chromo_drawers[target_name].color_funcs[map.name] = color_func
            self.label = label
            if scale_steps is None or scale_steps[map_ix] is None:
                scale_step = (self.scale_range[1]-self.scale_range[0])/10.
            else:
                scale_step = scale_steps[map_ix]
            self.color_scale_drawers[map.name] = ColorScaleDrawer(0, 0, map.name, self.scale_range[0], self.scale_range[1], scale_step, color_func)

    def draw(self, ax):
        for target_name in self.chromo_drawers.keys():
            self.chromo_drawers[target_name].draw(ax)
        ylim = ax.get_ylim()
        y_size = ylim[1]-ylim[0]
        ax_px_x_start, ax_px_y_start, ax_px_x_end, ax_px_y_end = self.get_axis_dimensions(ax)
        j = 0
        for i,map_name in enumerate(self.order):
            if self.color_scale_mask is None or self.color_scale_mask[i]:
                self.color_scale_drawers[map_name].x = self.px_x_to_axis_x(ax_px_x_end-ax_px_x_start, ax) + self.dpi_x_size_to_axis(0.75, ax) + j*(self.dpi_x_size_to_axis(self.scale_spacing, ax))
                self.color_scale_drawers[map_name].y = ylim[0] + y_size - self.dpi_y_size_to_axis(self.color_scale_drawers[map_name].h, ax)
                self.color_scale_drawers[map_name].draw(ax)
                j += 1
