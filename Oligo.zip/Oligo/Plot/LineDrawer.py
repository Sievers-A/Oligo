from Oligo import Prot
import matplotlib.pyplot as plt
from .Drawers import Drawer, Drawer3D

class LineDrawer(Drawer):

    def __init__(self, y, xmin=None, xmax=None, colors='k', linestyles='solid', label=None):
        self.y = y
        self.xmin, self.xmax = xmin, xmax
        self.colors = colors
        self.linestyles = linestyles
        self.label = label
        

    def draw(self, ax):
        ax.hlines(self.y, self.xmin, self.xmax, self.colors, self.linestyles, self.label)
