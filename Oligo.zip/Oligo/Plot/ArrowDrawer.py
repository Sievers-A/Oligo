from Oligo import Prot
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from .Drawers import Drawer

class ArrowDrawer(Drawer):

    def __init__(self, x_base, y_base, x_tip, y_tip, width, color='black', edgecolor=None, facecolor=None, linestlye='-', linewidth=0):
        self.x_base = x_base
        self.y_base = y_base
        self.x_tip = x_tip-x_base
        self.y_tip = y_tip-y_base
        self.width = width
        if facecolor is None:
            self.facecolor = color
        if edgecolor is None:
            self.edgecolor = color
        self.linestlye = linestlye
        self.linewidth = linewidth
        

    def draw(self, ax):
        ax.arrow(self.x_base,self.y_base,self.x_tip,self.y_tip,width=self.width, edgecolor=self.edgecolor,facecolor=self.facecolor,linestyle=self.linestlye,linewidth=self.linewidth)
        
        
class AnnotatorDrawer(Drawer):

    def __init__(self, text, x_base, y_base, x_tip, y_tip, width, color='black', edgecolor=None, facecolor=None, linestlye='-', linewidth=0):
        self.text = text
        self.x_base = x_base
        self.y_base = y_base
        self.x_tip = x_tip-x_base
        self.y_tip = y_tip-y_base
        self.width = width
        if facecolor is None:
            self.facecolor = color
        if edgecolor is None:
            self.edgecolor = color
        self.linestlye = linestlye
        self.linewidth = linewidth

    def draw(self, ax):
        ax.annotate(self.text, xytext=(self.x_base,self.y_base), xy=(self.x_tip,self.y_tip), arrowprops={})#{'width':self.width, 'edgecolor':self.edgecolor,'facecolor':self.facecolor,'linestyle':self.linestlye,'linewidth':self.linewidth})
        #ax.annotate('Increase',xy=(1,1),xytext=(0,0),arrowprops={})   

