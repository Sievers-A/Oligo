import Oligo
from Oligo import Prot
import numpy as np

DEFAULT_DIMER_PROPERTIES_FILENAME = 'E:/Daten/DiProGB_Dinucleotide_Properties_Database.txt'

class KmerModel():

    def __init__(self, dict, default_value=None, name=None):
        self.dict = dict
        self.default_value = default_value
        self.name = name
    
    def predict(self, kmer):
        try:
            self.dict[kmer]
        except:
            return self.default_value
        else:
            return self.dict[kmer]
            
    def predict_spectrum(self, spectrum, relative=True):
        x = 0.0
        values_sum = 0.0
        for kmer in spectrum.get_kmers():
            value = spectrum.get_freq(kmer)
            x += value * self.predict(kmer)
            values_sum += value
        if relative:
            return x/values_sum
        return x
        
    def predict_spectra(self, spectra, relative=True):
        x = []
        for spectrum in spectra:
            if spectrum.sum_of_values == 0:
                Prot.warn('Spectrum %s is empty in Oligo.Kmer.Models.predict_spectra.' % spectrum.name, 'empty')
                continue
            x.append(self.predict_spectrum(spectrum, relative))
        return np.mean(x), np.std(x)
  
  
    def prediction_estimates(self):
        x = [self.predict(kmer) for kmer in self.dict]
        return np.mean(x), np.std(x)
  
def create_dimer_properties_models(ids, names, input_filename=DEFAULT_DIMER_PROPERTIES_FILENAME, verbose=1):
    if verbose:
        Prot.write('Create %s Dimer-Models.' % len(ids))
    models = []
    for id, name in zip(ids, names):
        table = read_dimer_properties(id, input_filename=input_filename)
        models.append(KmerModel(table, name=name))
    if verbose:
        Prot.write('Created %s Dimer-Models.' % len(models))    
    return models

  
def read_dimer_properties(id, input_filename=DEFAULT_DIMER_PROPERTIES_FILENAME):
    # IDs can be found in the Textfile
    data = Oligo.File.read_dat_lines(input_filename)
    for d in data:
        if int(d['ID']) == int(id):
            return {key:float(d[key]) for key in d.keys() if key not in ['ID', 'PropertyName']}
            break
    return None
        