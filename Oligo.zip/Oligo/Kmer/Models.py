import Oligo

from math import sqrt
from numpy import prod

DINUCS = ['AA','TT','AT','TA','AC','GT','CA','TG','AG','CT','GA','TC','CC','GG','CG','GC']
REDUCED_DINUCS = ['AA','TT','AT','AC','GT','AG','CT','CC','GG','CG']
NUCS = ['A','C','G','T']

class NucleotideModel(object):
    
    def __init__(self, nucleotide_data, nuc_data_normalized=False):
        if not nuc_data_normalized:
            s = sum([nucleotide_data[nuc] for nuc in NUCS])
            if s == 0:
                Oligo.Prot.warn('Empty nucleotide spectrum given for Oligo.Kmer.Models.get_expected_dinucleotides Results will be empty.')
                self.nuc_data = {nuc:0 for nuc in NUCS}
            else:    
                self.nuc_data = {nuc:nucleotide_data[nuc]/s for nuc in NUCS}
        else:
            self.nuc_data = nucleotide_data
    
    def get_expected_kmer_data(self, kmer, sequence_length):
        n = sequence_length-(len(kmer)-1)
        p = prod([self.nuc_data[nuc] for nuc in kmer])
        m = p*n
        s = sqrt(p*(1-p)*n)
        return m, s
    
    def get_expected_kmers_data(self, kmers, sequence_length):
        kmers_mean_values, kmers_std_values = {},{}
        for kmer in kmers:
            m,s = self.get_expected_kmer_data(kmer, sequence_length)
            kmers_mean_values[kmer], kmers_std_values[kmer] = m, s
        return kmers_mean_values, kmers_std_values
    
    def get_expected_dinucleotides(self, sequence_length):
        kmers_mean_values, kmers_std_values = self.get_expected_kmers_data(REDUCED_DINUCS, sequence_length)
        for dinuc in DINUCS:
            try:
                kmers_mean_values[dinuc]
            except:
                kmers_mean_values[dinuc] = kmers_mean_values[dinuc[1]+dinuc[0]]
                kmers_std_values[dinuc] = kmers_std_values[dinuc[1]+dinuc[0]]
        return kmers_mean_values, kmers_std_values