import Oligo
from Oligo import Prot
from scipy.stats import pearsonr
import numpy as np

class KmerSpectrum(dict):

    def __init__(self, kmers=None, values=None, name=None, target=None, k=None, kmer_dict=None):
        if kmer_dict is not None:
            self.data = kmer_dict
        else:
            self.data = {kmer:value for kmer,value in zip(kmers,values)}
        self.target = target
        self.name = name
        if kmer_dict is not None:
            self.sum_of_values = self.sum()
        else:
            self.sum_of_values = sum(values)
        if k is None:
            k = self.calculate_k(kmers)
        self.k = k
       
    def get_name(self):
        return self.name
    
    def sum(self):
        x = 0
        for kmer in self.data:
            x += self.data[kmer]
        return x
    
    def filter_by_nuc(self, allowed_nucs=None):
        if allowed_nucs is None:
            allowed_nucs = ['A','C','G','T','U']
        filtered_kmers = []
        for kmer in sorted(self.get_kmers()):
            filter = False
            for c in kmer:                         
                if c not in allowed_nucs:
                    filter = True
                    break
            if not filter:
                filtered_kmers.append(kmer)
        values = [self.get_count(kmer) for kmer in filtered_kmers]
        return KmerSpectrum(filtered_kmers, values, name=self.name, target=self.target, k=self.k)
    
    def calculate_k(self, kmers):
        if not kmers:
            return None
        k = len(kmers[0])
        for kmer in kmers[1:]:
            if len(kmer) != k:
                return None
        return k
        
    def get_kmers(self):
        return self.data.keys()
        
    def get_count(self, kmer):
        try:
            self.data[kmer]
        except:
            return 0
        else:
            return self.data[kmer]
        

    def get_freq(self, kmer):
        try:
            return float(self.get_count(kmer))/self.sum_of_values
        except:
            if self.get_count(kmer) == 0 and self.sum_of_values == 0:
                return 0.0
        
    def __len__(self):
        return len(self.get_kmers())
        
    def __repr__(self):
        return '<KmerSpectrum:%s|%s|k=%s|>' % (str(self.target),self.name,self.k)
        
    @classmethod
    def kmer_set_from_spectra(cls, spectra):
        kmers = []
        for spectrum in spectra:
            kmers += spectrum.get_kmers()
        return list(set(kmers))
        
    @classmethod
    def kmer_set_from_spectra_filenames(cls, filenames):
        kmers = []
        for filename in filenames:
            spectrum = cls.read(filename)
            kmers += spectrum.get_kmers()
            kmers = list(set(kmers))
        return kmers
        
    def opperator(self, other, func, func_args=(), name=None, target=None, k=None, relative=True):
        kmers = KmerSpectrum.kmer_set_from_spectra([self,other])
        if k is None and self.k == other.k:
            k = self.k
        if target is None and self.target == other.target:
            target = self.target
        values = []
        for kmer in kmers:
            if relative:
                v1, v2 = self.get_freq(kmer), other.get_freq(kmer)
            else:
                v1, v2 = self.get_count(kmer), other.get_count(kmer)
            values.append(func(v1, v2, *func_args))
        return KmerSpectrum(kmers, values, name, target, k)
        
    def __add__(self, other):
        self.opperator(other, sum, name=str(self.name)+'+'+str(other.name))
        
    def __sub__(self, other):
        self.opperator(other, lambda v1,v2:v1-v2, name=str(self.name)+'-'+str(other.name))
   
    def __div__(self, other):
        self.opperator(other, lambda v1,v2:v1/v2, name=str(self.name)+'/'+str(other.name))
        
    def save(self, output_filename):
        save_kmer_spectra(output_filename, [self])
        
    def basic_stats(self):
        n = len(self)
        f = n/4.**self.k
        Prot.write('n = %s' % n)
        Prot.write('f = %s' % f)
     
    def get_bins(self):
        kmers = sorted(self.get_kmers())
        bins = []
        for i,kmer in enumerate(kmers):
            bin = Oligo.Loci.Bin(self.get_count(kmer), i-.5, i+.5, name=kmer)
            bins.append(bin)
        return bins
    
    def correlate(self, spectrum):
        kmers = KmerSpectrum.kmer_set_from_spectra([self,spectrum])
        v1 = np.array([self.get_count(kmer) for kmer in kmers]) 
        v2 = np.array([spectrum.get_count(kmer) for kmer in kmers])
        r,c = pearsonr(v1, v2)
        return r
    
    @classmethod
    def read(cls, input_filename, k=None, name=None, filter_N=True, verbose=1):
        if verbose:
            Prot.write('Reading k-mer spectrum from %s.' % input_filename)
        if name is not None:
            names = [name]
        else:
            names = None
        spectrum = read_kmer_spectra(input_filename, k=k, names=names, filter_N=filter_N, verbose=0)[0]
        if verbose:
           Prot.write('Found spectrum for k=%s.' % spectrum.k) 
        return spectrum
    
    @classmethod
    def read_old(cls, input_filename, k=None, names=None, tragets=None, filter_N_containing_kmers=True, verbose=1):
        if verbose:
            Prot.write('Reading k-mer spectrum from %s.' % input_filename)
        # Old Code
        seqs = {}
        seq = None
        f = open(input_filename,'r')
        for line in f:
            words = line.rstrip('\n').split(' ')
            if words[0] == '#SEQ:':
                seq = words[1]
                seqs[seq] = {}
            elif line[0] != '#':
                kmer = words[0]
                try:
                    count = int(words[1])
                except:
                    count = float(words[1])
                seqs[seq][kmer] = count
        f.close()
        # ---
        spectra = []
        kmers = []
        seq_keys = list(seqs.keys())
        for seq in seq_keys:
            if not kmers:
                kmers = sorted(seqs[seq].keys())
                if filter_N_containing_kmers:
                    kmers = [kmer for kmer in kmers if 'N' not in kmer]
            values = [seqs[seq][kmer] for kmer in kmers]
            del seqs[seq]
            if names:
                name = names[seq]
            else:
                name = None
            if tragets:
                target = targets[seq]
            else:
                target = None
            spectrum = KmerSpectrum(kmers, values, name=name, target=target, k=k)
            spectra.append(spectrum)
        if verbose:
           Prot.write('Found %s spectra.' % len(spectra)) 
        return spectra
        
    @classmethod
    def read_old_kmer_heatmap(cls, input_filename, k=None, verbose=1):
        if verbose:
            Prot.write('Reading k-mer spectrum from %s.' % input_filename)
        matrix = Oligo.Matrix.Matrix.read_old_heatmap(input_filename, verbose=0)
        matrix.transpose(copy=False)
        spectra = KmerSpectrum.from_matrix(matrix, k)
        if verbose:
           Prot.write('Found %s spectra.' % len(spectra))  
        return spectra    
      
    @classmethod
    def from_matrix(cls, matrix, k=None):
        spectra = []
        for n in range(matrix.len_cols()):
            spectrum = KmerSpectrum(matrix.row_names, matrix.col(ix=n), name=matrix.col_names[n], k=k)
            spectra.append(spectrum)
        return spectra
     
    @classmethod
    def correlate_spectra(cls, spectra1, spectra2=None, verbose=1):
        if verbose:
            Prot.write('Correlate k-mer spectra.')
        dict = {}
        row_names = [spectrum.get_name() for spectrum in spectra1]
        if spectra2 is None:
            same_spectra = True
            spectra2 = spectra1
            for i,spectrum1 in enumerate(spectra1):
                dict[i] = {i:1.0}
                for j,spectrum2 in enumerate(spectra2[0:i]):
                    dict[i][j] = spectrum1.correlate(spectrum2)
        else:
            same_spectra = False
            for i,spectrum1 in enumerate(spectra1):
                dict[i] = {}
                for j,spectrum2 in enumerate(spectra2):
                    dict[i][j] = spectrum1.correlate(spectrum2)
        col_names = [spectrum.get_name() for spectrum in spectra2]
        data = []
        for i in range(len(spectra1)):
            data.append([])
            for j in range(len(spectra2)):
                try:
                    dict[i][j]
                except:
                    if same_spectra:
                        v = dict[j][i]
                    else:
                        v = dict[i][j]
                else:
                    v = dict[i][j]
                data[-1].append(v)        
        return Oligo.Matrix.Matrix(data, row_names, col_names)

def kmer_spectra_to_matrix(spectra):
    kmers = KmerSpectrum.kmer_set_from_spectra(spectra)
    col_names = []
    data = []
    for spectrum in spectra:
        if spectrum.target is not None:
            col_names.append(str(spectrum.target)+'/'+str(spectrum.name))
        else:
            col_names.append(str(spectrum.name))
    for kmer in kmers:
        data.append([spectrum.get_count(kmer) for spectrum in spectra])
    return Oligo.Matrix.Matrix(data=data, col_names=col_names, row_names=kmers, copy=False)
                
def save_kmer_spectra(output_filename, spectra):
    matrix = kmer_spectra_to_matrix(spectra)
    matrix.save(output_filename)

def read_kmer_spectra(input_filename, k=None, names=None, filter_N=True, verbose=1):
    if verbose:
        Prot.write('Reading k-mer Spectra from %s.' % input_filename)
    matrix = Oligo.Matrix.Matrix.read(input_filename, verbose=0)
    #print matrix.show()
    spectra = KmerSpectrum.from_matrix(matrix, k=k)
    if filter_N:
        spectra = [spectrum.filter_by_nuc() for spectrum in spectra]
    if names is not None:
        for i in range(len(spectra)):
            spectra[i].name = names[i]
    if verbose:
        Prot.write('Found %s spectra.' % (len(spectra)))
    return spectra

def get_k_from_spectra(spectra):
    k = None
    for spectrum in spectra:
        if k is None:
            k = spectrum.k
        elif k != spectrum.k:
            return None
    return k
    
def get_target_from_spectra(spectra):
    target = None
    for spectrum in spectra:
        if target is None:
            target = spectrum.target
        elif target != spectrum.target:
            return None
    return target

def combine(spectra, name=None, verbose=1):
    if verbose:
        Prot.write('Combining %s k-mer spectra.' % len(spectra))
    k = get_k_from_spectra(spectra)
    target = get_target_from_spectra(spectra)
    kmers = KmerSpectrum.kmer_set_from_spectra(spectra)
    values = []
    for kmer in kmers:
        v = 0
        for spectrum in spectra:
            v += spectrum.get_count(kmer)
        values.append(v)
    spectrum = KmerSpectrum(kmers, values, name=name, target=target, k=k)
    if verbose:
        Prot.write('Created Combined Spectrum for k=%s (%s words).' % (k, len(kmers)))
    return spectrum
    
def calculate_GC(spectra, verbose=1):
    if verbose:
        Prot.write('Calculating GC for %s spectra.' % len(spectra))
    data = []
    row_names = []
    for spectrum in spectra:
        row_names.append(spectrum.name)
        data.append([spectrum.get_count(kmer='G')+spectrum.get_count(kmer='C'), spectrum.get_count(kmer='A')+spectrum.get_count(kmer='T')])
    matrix = Oligo.Matrix.Matrix(data=data, row_names=row_names, col_names=['G/C','A/T'])
    return matrix
            
def correlation_contributions(spectra1=None, spectra2=None, k=None, symmetric=True, sort=True, output_filename=None, allow_delete=False, verbose=1):
    if k is None:
        k = spectra1[0].k
    if verbose:
        if spectra2 is None:
            Prot.write('Calculating Correlation Contributions for %s (k=%s) spectra.' % (len(spectra1), k))
        else:
            Prot.write('Calculating Correlation Contributions for %s with %s (k=%s) spectra.' % (len(spectra1), len(spectra2), k))
    if spectra2 is None:
        kmers = KmerSpectrum.kmer_set_from_spectra(spectra1)
    else:
        kmers = KmerSpectrum.kmer_set_from_spectra(spectra1+spectra2)
    n_words = len(kmers)
    contribution_means = np.empty(n_words)#[0.0]*len(kmers)
    contribution_stds = np.empty(n_words)#[0.0]*len(kmers)
    if verbose:
        Prot.write('Found %s kmer Words.' % n_words)
    m = 1./4**k
    if verbose:
        Prot.write('Calculate Constant Sums.')
    sums1 = []
    for spectrum in spectra1:
        s = 0.0
        for kmer in spectrum.get_kmers():
            s += (spectrum.get_freq(kmer)-m)**2
        sums1.append(s)
    if spectra2 is None:
        sums2 = sums1
        spectra2 = spectra1
    else:
        sums2 = []
        for spectrum in spectra2:
            s = 0.0
            for kmer in spectrum.get_kmers():
                s += (spectrum.get_freq(kmer)-m)**2
            sums2.append(s)
    # Calculate Number of Pairs ams Constants
    if verbose:
        Prot.write('Calculating Constant.')
    n = 0
    N = []
    for i,spectrum1 in enumerate(spectra1):
        N.append([])
        for j,spectrum2 in enumerate(spectra2):
            if j < i or not symmetric:
                N[-1].append(1./np.sqrt(sums1[i]*sums2[j]))
                n += 1           
    total_sum = 0.0
    if verbose:
        Prot.write('Calculate Contributions for %s words.' % (n_words))
    for kmer_index,kmer in enumerate(kmers):
        if verbose > 1:
            Prot.write('Processing Word %s/%s.' % (kmer_index+1,n_words))
        # Mean Values
        sum = 0.0
        for i,spectrum1 in enumerate(spectra1):
            s1 = spectrum1.get_freq(kmer)-m
            for j,spectrum2 in enumerate(spectra2):
                if j < i or not symmetric:
                    sum += N[i][j]*s1*(spectrum2.get_freq(kmer)-m)            
        contribution_mean = sum/n
        total_sum += contribution_mean
        # Standard Deviation
        sum = 0.0
        for i,spectrum1 in enumerate(spectra1):
            s1 = spectrum1.get_freq(kmer)-m
            for j,spectrum2 in enumerate(spectra2):
                if j < i or not symmetric:
                    x = N[i][j]*s1*(spectrum2.get_freq(kmer)-m) 
                    sum += (x**2-contribution_mean**2) 
        contribution_std = np.sqrt(sum/n)
        contribution_means[kmer_index] = contribution_mean            
        contribution_stds[kmer_index] = contribution_std
    if allow_delete:
        del spectra1
        del spectra2
    if sort:
        kmers, contribution_means, contribution_stds, total_sum, n = sort_correlation_contributions(kmers, contribution_means, contribution_stds, total_sum, n, verbose)
    if output_filename:
        save_correlation_contributions(output_filename, kmers,contribution_means,contribution_stds,total_sum,n,verbose)
    return kmers,contribution_means,contribution_stds,total_sum,n
    #sums = []
    #vals = []
    #for spectrum in spectra:
    #    s = 0.0
    #    v = {}
    #    for kmer in spectrum.get_kmers():
    #        s += (spectrum.get_freq(kmer)-m)**2
    #        v[kmer] = spectrum.get_freq(kmer)-m
    #    sums.append(s)
    #    vals.append(v)
    #contributions = {}
    #full_n = 0
    #for i,spectrum1 in enumerate(spectra):
    #    sum1 = sums[i]
    #    contributions[i] = {}
    #    for j,spectrum2 in enumerate(spectra):
    #        if j < i or not symmetric:
    #            full_n += 1
    #            sum2 = sums[j]
    #            # Calculate Normalization Constant
    #            N = 1./np.sqrt(sum1*sum2)
    #            kmers = KmerSpectrum.kmer_set_from_spectra([spectrum1,spectrum2]) # Memory Error after hours
    #            # Calculate Contribution of Individual Words
    #            contributions[i][j] = {}
    #            for kmer in kmers:
    #                try:
    #                    vals[i][kmer]
    #                except:
    #                    v1 = 0.0
    #                else:
    #                    v1 = vals[i][kmer]
    #                try:
    #                    vals[j][kmer]
    #                except:
    #                    v2 = 0.0
    #                else:
    #                    v2 = vals[j][kmer]
    #                contributions[i][j][kmer] = (N*v1*v2)
    #kmers = KmerSpectrum.kmer_set_from_spectra(spectra)
    #results = []
    #full_sum = 0.0
    #
    #for kmer in kmers:
    #    d = []
    #    for i in contributions:
    #        for j in contributions[i]:
    #            d.append(contributions[i][j][kmer])
    #    mean = np.mean(d)
    #    std = np.std(d)
    #    n = len(d)
    #    rel_n = float(n)/full_n
    #    s = sum(d)
    #    full_sum += s
    #    results.append([s,mean,std,n, rel_n])
    #for i in range(len(results)):
    #    results[i].append(float(results[i][0])/full_sum)       
    #    results[i].append(float(results[i][1])/full_sum)       
    ## Sort kmers
    #kmers = [kmer for _,kmer in sorted(zip(results, kmers))]
    #results = sorted(results)
    #kmers.reverse()
    #results.reverse()
    ## Generate Matrix
    #matrix = Oligo.Matrix.Matrix(data=results, row_names=kmers, col_names=['Contribution','Mean Contribution','Std Contribution','Word Occurences','Relative Word Occurence','Relative Contribution','Std Relative Contribution'], copy=False)
    #if verbose:
    #    Prot.write('Calculated Correlation Contribution for %s kmer-words.' % len(matrix))
    #return matrix

    
def get_memory_spectrum(filename, mem_spectra, memory_max):
    try:
        mem_spectra[filename]
    except:
        spectra_names = list(mem_spectra.keys())
        if len(spectra_names) >= memory_max:
            delete_name = np.random.choice(spectra_names)
            del mem_spectra[delete_name]
        mem_spectra[filename] = Oligo.Kmer.KmerSpectrum.read(filename)
    else:
        Oligo.Prot.write('Reading %s from memory.' % filename)
    return mem_spectra[filename]

def kmer_set_from_spectra_filenames(filenames, mem_spectra, memory_max):
        kmers = []
        for filename in filenames:
            spectrum = get_memory_spectrum(filename, mem_spectra, memory_max)
            kmers += spectrum.get_kmers()
            kmers = list(set(kmers))
        return kmers

def correlation_contributions2(filenames1, filenames2=None, k=None, symmetric=True, sort=True, output_filename=None, memory_max=50, verbose=1):
    mem_spectra = {}
    if verbose:
        if filenames2 is None:
            Prot.write('Calculating Correlation Contributions for %s spectra.' % (len(filenames2)))
        else:
            Prot.write('Calculating Correlation Contributions for %s with %s spectra.' % (len(filenames1), len(filenames2)))
    # Collect all kmers:
    if filenames2 is None:
        kmers = kmer_set_from_spectra_filenames(filenames1, mem_spectra, memory_max)
    else:
        kmers = kmer_set_from_spectra_filenames(filenames1+filenames2, mem_spectra, memory_max)
    n_words = len(kmers)
    contribution_means = np.empty(n_words)
    contribution_stds = np.empty(n_words)
    if verbose:
        Prot.write('Found %s kmer Words.' % n_words)
    m = 1./4**k
    if verbose:
        Prot.write('Calculate Constant Sums.')
    sums1 = []
    for filename in filenames1:
        spectrum = get_memory_spectrum(filename, mem_spectra, memory_max)
        s = 0.0
        for kmer in spectrum.get_kmers():
            s += (spectrum.get_freq(kmer)-m)**2
        sums1.append(s)
    if filenames2 is None:
        sums2 = sums1
        filenames2 = filenames1
    else:
        sums2 = []
        for filename in filenames2:
            spectrum = get_memory_spectrum(filename, mem_spectra, memory_max)
            s = 0.0
            for kmer in spectrum.get_kmers():
                s += (spectrum.get_freq(kmer)-m)**2
            sums2.append(s)
    # Calculate Number of Pairs ams Constants
    if verbose:
        Prot.write('Calculating Constant.')
    n = 0
    N = []
    for i,filename1 in enumerate(filenames1):
        N.append([])
        for j,filename2 in enumerate(filenames2):
            if j < i or not symmetric:
                N[-1].append(1./np.sqrt(sums1[i]*sums2[j]))
                n += 1           
    total_sum = 0.0
    if verbose:
        Prot.write('Calculate Contributions for %s words.' % (n_words))
    for kmer_index,kmer in enumerate(kmers):
        if verbose > 1:
            Prot.write('Processing Word %s/%s.' % (kmer_index+1,n_words))
        # Mean Values
        sum = 0.0
        for i,filename1 in enumerate(filenames1):
            spectrum1 = get_memory_spectrum(filename1, mem_spectra, memory_max)
            s1 = spectrum1.get_freq(kmer)-m
            for j,filename2 in enumerate(filenames2):
                spectrum2 = get_memory_spectrum(filename2, mem_spectra, memory_max)
                if j < i or not symmetric:
                    sum += N[i][j]*s1*(spectrum2.get_freq(kmer)-m)            
        contribution_mean = sum/n
        total_sum += contribution_mean
        # Standard Deviation
        sum = 0.0
        for i,filename1 in enumerate(filenames1):
            spectrum1 = get_memory_spectrum(filename1, mem_spectra, memory_max)
            s1 = spectrum1.get_freq(kmer)-m
            for j,filename2 in enumerate(filenames2):
                spectrum2 = get_memory_spectrum(filename2, mem_spectra, memory_max)
                if j < i or not symmetric:
                    x = N[i][j]*s1*(spectrum2.get_freq(kmer)-m) 
                    sum += (x**2-contribution_mean**2) 
        contribution_std = np.sqrt(sum/n)
        contribution_means[kmer_index] = contribution_mean            
        contribution_stds[kmer_index] = contribution_std
    if sort:
        kmers, contribution_means, contribution_stds, total_sum, n = sort_correlation_contributions(kmers, contribution_means, contribution_stds, total_sum, n, verbose)
    if output_filename:
        save_correlation_contributions(output_filename, kmers,contribution_means,contribution_stds,total_sum,n,verbose)
    return kmers,contribution_means,contribution_stds,total_sum,n
    
def sort_correlation_contributions(kmers,contribution_means,contribution_stds,total_sum,n,verbose=1):
    if verbose:
        Prot.write('Sorting %s Correlation Contributions.' % (len(kmers)))
    inds = contribution_means.argsort()
    inds = np.flip(inds)
    kmers = [kmers[i] for i in inds]
    contribution_stds = contribution_stds[inds]
    contribution_means = contribution_means[inds]
    return kmers,contribution_means,contribution_stds,total_sum,n
    
def save_correlation_contributions(output_filename, kmers,contribution_means,contribution_stds,total_sum,n,verbose=1):
    if verbose:
        Prot.write('Saving Correlation Contributions to %s.' % output_filename)
    f = open(output_filename, 'w')
    f.write('#Correlation Contribution Matrix\n#Generated by Oligo.Kmer.Spectra.save_correlation_contributions()\n')
    f.write('$n = %s\n' % n)
    f.write('$total sum = %s\n' % total_sum)
    f.write('Row Name\tMean Correlation Contribution\tStd Correlation Contribution\tNormalized Correlation Contribution\tStd Normalized Correlation Contribution\n')
    for i,kmer in enumerate(kmers):
        f.write('%s\t%s\t%s\t%s\t%s\n' % (kmer, contribution_means[i] ,contribution_stds[i], contribution_means[i]/total_sum, contribution_stds[i]/total_sum))
    f.close()
    
def gc_content(seq):
    gc = 0
    for nuc in seq:
        if nuc == 'C' or nuc == 'G':
            gc += 1
    return float(gc)/len(seq)
    
def is_repeat(seq, unit_size):
    base = seq[0:unit_size]
    i = len(base)
    while i < len(seq)-unit_size+1:
        if seq[i] != base[i%unit_size]:
            return False
        i += 1
    return True
        