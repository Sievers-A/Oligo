import Oligo
CONFIG_FILEPATH = 'Oligo/config.dat'

username = None
email = None
institutions = None
data_paths = ['data','']
results_path = 'results'
seq_files = ['default.seqs']
prot_print = 1
prot_file = 'protocol.txt'
blast_path = ''
python_version = None
properties_filepath = 'Oligo/Model/DiProGB_Dinucleotide_Properties_Database.txt'

def get_default_properties_filename():
    return Oligo.File.search(properties_filepath)

def get_default_seqs_filename():
    return Oligo.File.search(seq_files[0])
    
def read_config_data(config_filename=CONFIG_FILEPATH, verbose=1):
    if verbose:
        Oligo.Prot.write('Reading Config file %s.' % config_filename)
    global username, email, institutions, data_paths, results_path, seq_files, prot_print, prot_file, blast_path
    f = open(Oligo.File.get_absolute_path(config_filename), 'r')
    for line in f:
        line = line.rstrip()
        if line != '' and line[0] != '#':
            words = line.split('\t')
            if words[0] == 'USERNAME':
                username = words[1]
            elif words[0] == 'EMAIL':
                email = words[1]
            elif words[0] == 'INSTITUTIONS':
                institutions = words[1]
            elif words[0] == 'DATA PATHS':
                data_paths = words[1].split(',')
            elif words[0] == 'RESULTS_PATH':
                results_path = words[1]
            elif words[0] == 'SEQFILES':
                seq_files = words[1].split(',')
            elif words[0] == 'PROT PRINT':
                prot_print = int(words[1])
            elif words[0] == 'PROT FILE':
                if words[0] in ['None','-','']:
                    prot_file = None
                else:
                    prot_file = words[1]
            elif words[0] == 'BLAST PATH':
                blast_path = words[1]
            elif words[0] == 'PROPERTIES PATH':
                properties_filepath = words[1]
    f.close()
    if verbose:
        show_config()

def show_config():
    Oligo.Prot.write('Config Data:')
    Oligo.Prot.write('USERNAME:\t%s' % username)
    Oligo.Prot.write('EMAIL:\t%s' % email)
    Oligo.Prot.write('INSTITUTIONS:\t%s' % institutions)
    Oligo.Prot.write('DATA PATHS:\t%s' % ','.join(data_paths))
    Oligo.Prot.write('RESULTS PATH:\t%s' % results_path)
    Oligo.Prot.write('SEQFILES:\t%s' % ','.join(seq_files))
    Oligo.Prot.write('PROT PRINT:\t%s' % str(prot_print))
    Oligo.Prot.write('PROT FILE:\t%s' % str(prot_file))
    Oligo.Prot.write('BLAST PATH:\t%s' % str(blast_path))
