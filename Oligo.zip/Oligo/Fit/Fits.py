import numpy as np

def chi_squared(y_data, y_fit, y_err=None):
    if y_err is None:
        y_err = [1.]*len(y_data)
    return np.sum([((y_data[i]-y_fit[i])/y_err[i])**2 for i in range(len(y_data))])
    
    
def chi_squared_reduced(y_data, y_fit, dof, y_err=None):
    #  equals the number of observations n minus the number of fitted parameters m
    # chi**2 >> 1   poor fit model
    # chi**2 > 1    fit has not fully captured the data (or that the error variance has been underestimated).
    # chi**2 ~ 1    good fit
    # chi**2 < 1    model is "over-fitting" the data
    return chi_squared(y_data, y_fit, y_err=y_err)/dof
    
def rmsd(y_data, y_fit):
    return np.sqrt(np.sum([(y_data[i]-y_fit[i])**2 for i in range(len(y_data))])/len(y_data))
    
def nrmsd(y_data, y_fit):
    return np.sqrt(np.sum([(y_data[i]-y_fit[i])**2 for i in range(len(y_data))])/len(y_data))/np.mean(y_data)