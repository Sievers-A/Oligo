import numpy as np

def fit(x,y, n):
    f = np.polyfit(x, y, n, cov='unscaled')
    coefficients = f[0]
    errors = [np.sqrt(f[1][i][i]) for i in range(len(f[1]))]
    return coefficients, errors
    
def extrapolate(x, coefficients):
    y = []
    for xi in x:
        n = len(coefficients)-1
        yi = 0.
        for i,c in enumerate(coefficients):
            yi += c*xi**(n-i)
        y.append(yi)
    return y