import Oligo
from Oligo import Prot
from math import ceil
import numpy as np
import datetime
import pandas
from scipy.stats import pearsonr

COUNT_MAP = 1
COVERAGE_MAP = 2

class DensityMap(dict):

    def __init__(self, bins=None, name=None, orga=None, target_lengths=None, loci=None, target_loci=None, mode=COUNT_MAP, resolution=None):
        if bins is None:
            bins = {}
        self.target_lengths = target_lengths
        if loci is not None:
            bins = DensityMap.bins_from_loci(loci, resolution, mode)
            if target_lengths is None:
                self.target_lengths = DensityMap.get_target_lengths(loci)
        elif target_loci is not None:
            bins = DensityMap.bins_from_target_loci(target_loci, resolution, mode)
        super(DensityMap, self).__init__(bins)
        self.name = name
        if orga is None and loci and loci[0].target is not None:
            self.orga = loci[0].target.orga
        else:
            self.orga = orga
        self.resolution = resolution

    def get_loci(self, target_names=None, filter_func=None, filter_func_args=(), verbose=1):
        if target_names is None:
            target_names = self.get_target_names()
        target_loci = {}
        n = 0
        k = 0
        for target_name in target_names:
            target_loci[target_name] = []
            for bin in self[target_name]:
                n += 1
                if filter_func is None or filter_func(bin, *filter_func_args):
                    #print(bin.count,filter_func_args[0])
                    k += 1
                    locus = Oligo.Locus(bin.start, bin.end)
                    locus.set_value('count',bin.count)
                    target_loci[target_name].append(locus)
        if verbose and filter_func is not None:
            Prot.write('Accepted %s of %s (%s%%)' % (k,n,round(100*k/n)))
        return target_loci

    def get_resolution(self):
        if self.resolution is None:
            self.resolution = min([len(bin) for bin in self.bins])
        return self.resolution
    
    def get_target_names(self):
        return sorted(self.keys())#self.target_lengths.keys()
    
    def save(self, output_filename, header=None, verbose=1):
        if verbose:
            Prot.write('Saving Map '+str(self.name)+' to %s.' % output_filename)
        if header is None:
            header = {}
        f = open(output_filename,'w')
        f.write('#date:\t'+str(datetime.datetime.now())+'\n')
        Oligo.File.write_head(f, header)
        f.write('$Name:\t'+str(self.name)+'\n')
        f.write('$Organism:\t'+str(self.orga)+'\n')
        f.write('$Resolution:\t'+str(self.resolution)+'\n')
        f.write('$Target Lengths:\t')
        f.write(','.join([str(target_name)+':'+str(self.target_lengths[target_name]) for target_name in self.keys()])+'\n')
        f.write('Target\tStart\tValue\tError\n')
        #print self.keys()
        for target_name in self.keys():
            for bin in self[target_name]:
                if bin.std is not None:
                    f.write(target_name+'\t'+str(bin.start)+'\t'+str(bin.count)+'\t'+str(bin.std)+'\n')
                else:
                    f.write(target_name+'\t'+str(bin.start)+'\t'+str(bin.count)+'\n')
        f.close()

    def save_to_wiggle(self, output_filename, variable_step=False, verbose=1):
        if verbose:
            Prot.write('Saving Map %s to %s.' % (self.name,output_filename))
        f = open(output_filename,'w')
        f.write('track type=wiggle_0\n')
        if not variable_step:
            for target_name in self.get_target_names():
                f.write('fixedStep chrom=chr%s start=1 step=%s\n' % (target_name.split(' ')[-1][1:], int(self.resolution)))
                values_list = self.list(target_names = [target_name])
                for value in values_list:
                    f.write(str(value)+'\n')
            f.close()
        else:
            for target_name in self.get_target_names():
                f.write('variableStep chrom=chr%s span=%s\n' % (target_name.split(' ')[-1][1:], int(self.resolution)))
                for bin in self[target_name]:
                    f.write(str(bin.start)+'\t'+str(bin.count)+'\n')
            f.close()
        

    @classmethod
    def read(cls, input_filename, target_name_mode=1, name=None, verbose=1):
        f = open(input_filename, 'r')
        if verbose:
            Prot.write('Reading DensityMap from %s.' % input_filename)
        target_bins = {}
        head_data, head_rows = Oligo.File.read_head(input_filename)
        target_lengths = {}
        for t in head_data['Target Lengths'].split(','):
            if target_name_mode:
                target_lengths[t.split(':')[0]] = int(t.split(':')[1])
            else:
                target_lengths[t.split(':')[0].split(' ')[-1]] = int(t.split(':')[1])
        data = pandas.read_csv(input_filename, sep='\t', skiprows=head_rows)
        for row in data.itertuples():
            if target_name_mode:
                target_name = row.Target
            else:
                target_name = row.Target.split(' ')[-1]
            try:
                target_bins[target_name]
            except:
                target_bins[target_name] = []
            try:
                row.Error
            except:
                err = None
            else:
                err = row.Error
            target_bins[target_name].append(Oligo.Loci.bins.Bin(row.Value, row.Start, row.Start+float(head_data['Resolution']), std=err))
        map = DensityMap(bins=target_bins, name=head_data['Name'], orga=Oligo.Orga.Organism(name=head_data['Organism']), target_lengths=target_lengths, resolution=float(head_data['Resolution']))
        if name is not None:
            map.name = name
        f.close()
        if verbose:
            Prot.write('Found Map '+str(map.name)+' with %s targets, %s bins.' % (len(map.keys()), len(data)))
        return map

    def __repr__(self):
        return '<Oligo.DensityMap:'+str(self.name)+'|'+str(self.orga)+'|res:'+str(self.resolution)+'>'

    def __str__(self):
        return self.name

    @classmethod
    def split_loci_by_target(cls, loci):
        target_loci = {}
        for locus in loci:
            if locus.target is not None:
                try:
                    target_loci[locus.target.name]
                except:
                    target_loci[locus.target.name] = []
                target_loci[locus.target.name].append(locus)
            else:
                Prot.warn('Locus %s cannot be mapped because it has no target.' % locus,'locus map')
        return target_loci

    @classmethod
    def get_target_lengths(cls, loci):
        target_lengths = {}
        for locus in loci:
            if locus.target is not None:
                target_lengths[locus.target.name] = len(locus.target)
        return target_lengths

    @classmethod
    def bins_from_loci(cls, loci, resolution, mode=COUNT_MAP, verbose=1):
        target_loci = cls.split_loci_by_target(loci)
        return cls.bins_from_target_loci(target_loci, resolution, mode=mode, verbose=1)
        
    @classmethod
    def bins_from_target_loci(cls, target_loci, resolution, mode=COUNT_MAP, verbose=1):
        if verbose:
            l = sum([len(target_loci[key]) for key in target_loci])
            Prot.write('Generate Density Bins (%s) from Loci (%s)' % (resolution, l))
        map_bins = {}
        target_names = target_loci.keys()
        for target_name in target_names:
            loci = target_loci[target_name]
            if verbose:
                Prot.write('Generate Density bins for %s (%s loci).' % (target_name, len(loci)))
            bins = {}
            if loci:
                min_value = int(min([locus.start for locus in loci])/resolution)*resolution
                max_value = ceil(max([locus.get_end() for locus in loci])/resolution)*resolution
            else:
                Prot.warn('Creating no bins from no loci in DensityMap.bins_from_target_loci.')
                min_value = 0
                max_value = 0
            for locus in loci:
                posi = locus.start
                locus_end = locus.get_end()
                while posi < locus_end + resolution:
                    index = int((posi-min_value)/resolution)
                    try:
                        bins[index]
                    except:
                        bins[index] = Oligo.Loci.bins.Bin(0.0, index*resolution+min_value, (index+1)*resolution+min_value)
                    bin = bins[index]
                    bin_locus = Oligo.Locus(start=index*resolution+min_value, length=resolution)
                    overlap_start, overlap_end = locus.get_overlap(bin_locus)
                    #print posi, index, locus, bin_locus
                    if overlap_end is None:
                        overlap_length = 0
                    else:
                        overlap_length = overlap_end-overlap_start
                    if mode == COUNT_MAP:
                        value = float(overlap_length)/len(locus)
                    elif mode == COVERAGE_MAP:
                        value = float(overlap_length)/resolution
                    else:
                        Prot.error('Unknown Map-Binning Mode %s found in DensityMap.bins_from_loci.', 'Unknown Binning Mode')
                        value = None
                    bin.count += value
                    posi += resolution
            if verbose:
                Prot.write('Generated %s bins.' % len(bins.keys()))
            map_bins[target_name] = [bins[k] for k in sorted(bins.keys())]
        if verbose:
            Prot.write('Generated (%s) maps.' % len(map_bins))
        return map_bins

    def list(self, target_names=None, limits=None, mask=None, map_mask=None):
        if target_names is None:
            target_names = self.get_target_names()
        if limits is None:
            limits = {}
            for target_name in target_names:
                try:
                    self.target_lengths[target_name]
                except:
                    limits[target_name] = (0,0)
                    Prot.warn('Generating List for target "%s" not in map %s. Result will be empty (DensityMap.list())' % (target_name, self.name), 'target not found')
                else:
                    limits[target_name] = (0,np.ceil(float(self.target_lengths[target_name])/self.resolution))
        data = []
        for target_name in target_names:
            posi = limits[target_name][0]*self.resolution
            while posi < limits[target_name][1]*self.resolution:
                bin = self.get_bin_at(target_name, posi)
                if bin is not None:
                    data.append(bin.count)
                else:
                    data.append(0.0)
                posi += self.resolution
        if map_mask is not None:
            if mask is not None:
                Oligo.Prot.warn('Specified Mask and MapMask for list conversion of Map %s. Only MapMask will be applied.' % self.name)
            mask = map_mask.get_list(target_names=target_names)
        if mask:
            if len(mask) != len(data):
                Prot.warn('Mask (%s) not fitting map size (%s) for map %s.' % (len(mask), len(data), self.name),'input')
            data = [data[i] for i in range(len(data)) if mask[i]]
        return data
    
    def mean(self, target_names=None, limits=None, mask=None):
        return np.mean(self.list(target_names=target_names, limits=limits, mask=mask))

    def std(self, target_names=None, limits=None, mask=None):
        return np.std(self.list(target_names=target_names, limits=limits, mask=mask))

    def check_empty(self):
        for target_name in self.bins.keys():
            if len(self.bins[target_name]) > 0:
                return False
        return True
    
    def get_density_bins(self, bin_width=None, n_bins=None, target_names=None, limits=None, mask=None, verbose=1):
        values = self.list(target_names=target_names, limits=limits, mask=mask)
        return Oligo.Loci.bins.create_bins(values, bin_width=bin_width, n_bins=n_bins, verbose=verbose)
    
    def get_theory_density_bins(self, mask=None, target_names=None, limits=None, bins=None):
        values = self.list(target_names=target_names, limits=limits, mask=mask)
        corrected_length = self.resolution*len(values)
        n = round(np.sum(values))
        p = float(self.resolution)/corrected_length
        theo_bins = []
        m = len(values)
        if bins is None:
            bins = self.get_density_bins(bin_width, n_bins, target_names, limits, mask, verbose=0)
        for bin in bins:
            theo_bin = bin.copy()
            k = bin.start
            #print(n,p,k)
            #pk = float((n*p)**k)/np.math.factorial(k)*np.exp(-n*p)
            l = n*p
            pk = np.exp(-(k-l)**2/(2*l))/np.sqrt(2.*np.pi*l)
            theo_bin.count = m*pk
            theo_bin.std = np.sqrt(m*pk*(1.-pk))
            theo_bins.append(theo_bin)
            #print(theo_bin.count, theo_bin.std)
        return theo_bins
        
    def get_theo_values(self, mask=None, target_names=None, limits=None):
        values = self.list(target_names=target_names, limits=limits, mask=mask)
        corrected_length = self.resolution*len(values)
        n = round(np.sum(values))
        try:
            p = float(self.resolution)/corrected_length
        except:
            Oligo.Prot.warn('Corrected length of zero occured in DensityMaps.py:get_theo_values.','zero division catched')
            return None, n, None, None
        return p, n, n*p, np.sqrt(n*p*(1.-p))
    
    def get_value_at(self, target_name, x):
        bin = self.get_bin_at(target_name, x)
        if bin is None:
            return None
        return bin.count

    def get_bin_at(self, target_name, x):
        try:
            self[target_name]
        except:
            return None
        for bin in self[target_name]:
            if x >= bin.start and x < bin.end:
                return bin
        return None

    def __len__(self):
        return len(self.keys())

    def reduced_resolution(self, factor, verbose=1):
        if verbose:
            Prot.write('Reducing Resolution of map %s from %s to %s (factor %s).' % (self.name, self.resolution, self.resolution*factor, factor))
        bins = {}
        dx = self.resolution
        new_resolution = self.resolution*factor
        for target_name in self.keys():
            x = 0
            sub_i = 0
            count = 0
            target_length = self.target_lengths[target_name]
            bins[target_name] = []
            while x < target_length:
                v = self.get_value_at(target_name, x)
                #print target_name,x,v
                if v is not None:
                    count += v
                sub_i += 1
                if sub_i == factor:
                    if count != 0:
                        index = int((x-(factor-1)*self.resolution)/new_resolution)
                        bins[target_name].append(Oligo.Loci.bins.Bin(count, index*new_resolution, (index+1)*new_resolution))
                        count = 0
                    #print '!',target_name,x,count,index, index*new_resolution, (index+1)*new_resolution
                    sub_i = 0
                x += dx
        return DensityMap(bins=bins, name=self.name, orga=self.orga, target_lengths=self.target_lengths, resolution=new_resolution)

class DensityMapVB(DensityMap):
    # Density Map with variable Bin sizes
    
    def __init__(self, bins=None, name=None, orga=None, target_lengths=None, loci=None, target_loci=None, mode=COUNT_MAP, target_bin_sizes=None):
        if bins is None:
            bins = {}
        self.target_lengths = target_lengths
        if loci is not None:
            bins = DensityMapVB.bins_from_loci(loci, target_bin_sizes, mode)
            if target_lengths is None:
                self.target_lengths = DensityMap.get_target_lengths(loci)
        elif target_loci is not None:
            bins = DensityMapVB.bins_from_target_loci(target_loci, resolution, mode)
        super(DensityMap, self).__init__(bins)
        self.name = name
        if orga is None and loci and loci[0].target is not None:
            self.orga = loci[0].target.orga
        else:
            self.orga = orga

    def save_to_wiggle(self, output_filename, variable_step=False, verbose=1):
        if verbose:
            Prot.write('Saving Map %s to %s.' % (self.name,output_filename))
        f = open(output_filename,'w')
        f.write('track type=wiggle_0\n')
        if not variable_step:
            for target_name in self.get_target_names():
                f.write('fixedStep chrom=chr%s start=1 step=%s\n' % (target_name.split(' ')[-1][1:], int(self.resolution)))
                values_list = self.list(target_names = [target_name])
                for value in values_list:
                    f.write(str(value)+'\n')
            f.close()
        else:
            for target_name in self.get_target_names():
                f.write('variableStep chrom=chr%s span=%s\n' % (target_name.split(' ')[-1][1:], int(self.resolution)))
                for bin in self[target_name]:
                    f.write(str(bin.start)+'\t'+str(bin.count)+'\n')
            f.close()        

    def __repr__(self):
        return '<Oligo.DensityMapVB:'+str(self.name)+'|'+str(self.orga)+'>'

    @classmethod
    def bins_from_loci(cls, loci, target_bin_sizes, mode=COUNT_MAP, verbose=1):
        target_loci = DensityMap.split_loci_by_target(loci)
        return cls.bins_from_target_loci(target_loci, target_bin_sizes, mode=COUNT_MAP, verbose=1)
        
    @classmethod
    def bins_from_target_loci(cls, target_loci, target_bin_sizes, mode=COUNT_MAP, verbose=1):
        if verbose:
            l = sum([len(target_loci[key]) for key in target_loci])
            Prot.write('Generate Density Bins (%s) from Loci (%s)' % (bin_sizes, l))
        map_bins = {}
        target_names = target_loci.keys()
        for target_name in target_names:
            map_bins[target_name] = []
            loci = target_loci[target_name]
            bin_sizes = target_bin_sizes[target_name]
            if verbose:
                Prot.write('Generate Density bins for %s (%s loci).' % (target_name, len(loci)))
            loci_buckets = Oligo.Loci.generate_touch_buckets(loci)    
            for bin_size in bin_sizes:
                bin = Oligo.Bin(0, bin_size[0], bin_size[0]+bin_size[1])
                bin_locus = Oligo.Locus(start=bin_size[0], length=bin_size[1])
                overlapping_loci = Oligo.Loci.filter_loci_by_overlap2(None, [bin_locus], loci_buckets)
                for locus in ovelapping_loci:
                    overlap_start, overlap_end = locus.get_overlap(bin_locus)
                    overlap_length = overlap_end-overlap_start
                    if mode == COUNT_MAP:
                        value = float(overlap_length)/len(locus)
                    elif mode == COVERAGE_MAP:
                        value = float(overlap_length)/resolution
                    else:
                        Prot.error('Unknown Map-Binning Mode %s found in DensityMap.bins_from_loci.', 'Unknown Binning Mode')
                        value = None
                    bin.count += value
                map_bins[target_name].append(bin)
        if verbose:
            Prot.write('Generated (%s) maps.' % len(map_bins))
        return map_bins

 

def add_missing_targets(map1, map2):
    for target_name in map1.keys():
        try:
            map2[target_name]
        except:
            map2[target_name] = [Oligo.Loci.bins.Bin(0.0, bin.start, bin.end) for bin in map1[target_name]]
            map2.target_lengths[target_name] = map1.target_lengths[target_name]

def check_same_target_lengths(map1, map2):
    for target_name in map1.target_lengths.keys():
        if map1.target_lengths[target_name] != map2.target_lengths[target_name]:
            return False
    return True

def correlate(map1, map2, corr_function=None, corr_func_para=(), target_names=None, limits=None, mask=None, map_mask=None):
    if map1.resolution != map2.resolution:
        Prot.warn('Resolution (%s, %s) of Correlated Maps (%s, %s) not matching.' % (map1.resolution, map2.resolution, map1.name, map2.name),'resolution_missmatch')
    if corr_function is None:
        corr_function = pearsonr
    add_missing_targets(map1, map2)
    add_missing_targets(map2, map1)
    if target_names is None:
        target_names = map1.get_target_names()
    if not check_same_target_lengths(map1, map2):
        Prot.warn('Correlating Maps (%s, %s) with different target lengths.' % (map1.name, map2.name), 'target_length_missmatch')
    v1 = map1.list(target_names=target_names, limits=limits, mask=mask, map_mask=map_mask)
    v2 = map2.list(target_names=target_names, limits=limits, mask=mask, map_mask=map_mask)
    #print(len(v1),len(v2))
    r, d = corr_function(v1, v2, *corr_func_para)
    return r
    
def check_no_variance(values):
    ref = values[0]
    for v in values:
        if v != ref:
            return False
    return True
    
def boot_correlate(map1, map2, corr_function=None, corr_func_para=(), target_names=None, limits=None, mask=None, map_mask=None, sample_size=100, repeats=100, shuffle=False, decomposition=False, verbose=1):
    if verbose:
        Prot.write('Correlating %s and %s' % (map1.name, map2.name))
    if map1.resolution != map2.resolution:
        Prot.warn('Resolution (%s, %s) of Correlated Maps (%s, %s) not matching.' % (map1.resolution, map2.resolution, map1.name, map2.name),'resolution_missmatch')
    if corr_function is None:
        corr_function = pearsonr
    add_missing_targets(map1, map2)
    add_missing_targets(map2, map1)
    if not check_same_target_lengths(map1, map2):
        Prot.warn('Correlating Maps (%s, %s) with different target lengths.' % (map1.name, map2.name), 'target_length_missmatch')
    if target_names is None:
        target_names = map1.get_target_names()
    #print len(mask), len(map1.list(target_names=target_names, limits=limits)), len(map2.list(target_names=target_names, limits=limits))
    v1 = map1.list(target_names=target_names, limits=limits, mask=mask, map_mask=map_mask)
    v2 = map2.list(target_names=target_names, limits=limits, mask=mask, map_mask=map_mask)
    if len(v1) != len(v2):
        Prot.warn('Map lengths (%s, %s) of Correlated Maps (%s, %s) not matching.' % (len(v1), len(v2), map1.name, map2.name),'length_missmatch')
    if len(v1) == 0 and len(v2) == 0:
        selection_limit = 1
        Prot.warn('Map lengths (%s, %s) of Correlated Maps (%s, %s) both zero.' % (len(v1), len(v2), map1.name, map2.name),'length_zero')
        v1,v2 = [0], [0]
    else:
        selection_limit = max(len(v1),len(v2))
    #print map1.name, map2.name, len(mask), len(v1), len(v2)
    rs = []
    decomp_data = []
    for i in range(repeats):
        selection1 = np.random.randint(0, selection_limit, sample_size)
        if decomposition:
            decomp_data += boot_correlation_decomposition(v1, v2, selection)
        if shuffle:
            selection2 = np.random.randint(0, selection_limit, sample_size)#np.random.shuffle(v2)
        else:
            selection2 = selection1
        v1i = [v1[i] for i in selection1]
        v2i = [v2[i] for i in selection2]
        if check_no_variance(v1i):
            if check_no_variance(v2i):
                r = 1.0
            else:
                r = 0.0
        elif check_no_variance(v2i):
            r = 0.0
        else:
            r, d = corr_function(v1i, v2i, *corr_func_para)
        rs.append(r)
    m, std =  np.mean(rs), np.std(rs)
    if verbose:
        Prot.write('Results: %s +/- %s' % (m,std))
    if decomposition:
        return m, std, decomp_data
    return m, std
    
def boot_correlation_decomposition(v1, v2, selection):
    const = 1./np.sqrt(np.std(v1)**2*np.std(v2)**2)
    m1 = np.mean(v1)
    m2 = np.mean(v2)
    decomp_data = []
    for i in selection:
        v = (v1[i]-m1)*(v2[i]-m2)*const
        decomp_data.append([i,v])
    return decomp_data

def correlation_matrix(maps, names=None, target_names=None, limits=None, mask=None, map_mask=None):
    data = []
    if names is None:
        names = []
        for m in maps:
            names.append(m.name)
    for i,m1 in enumerate(maps):
        data.append([])
        for j,m2 in enumerate(maps):
            if j >= i:
                r = Oligo.Maps.correlate(m1, m2, target_names=target_names, limits=limits, mask=mask, map_mask=map_mask)
            else:
                r = data[j][i]
            data[-1].append(r)
    matrix = Oligo.Matrix.Matrix(data=data, col_names=names, row_names=names)
    return matrix

def increase_counter_at(counts, dx):
    try:
        counts[dx]
    except:
        counts[dx] = 1
    else:
        counts[dx] += 1

def density_profile_execute_buckets(buckets, map_index, target_name, target_length, res, data, limit, f):
    for key in buckets.get_keys():
        bucket = buckets.get_bucket(bucket_key=key)
        n = len(bucket)
        start, end = buckets.get_bucket_limits(key=key)
        x = start
        #v = map.get_value_at(target_name, x)
        v = map_index[target_name].get_value(x)
        #if v == None:
        #    v = 0.
        try:
            data[0]
        except:
            data[0] = []
        if v is not None:
            data[0] += n*[v]
        dx = -res
        while x+dx > 0 and (limit is None or abs(dx) < limit):
            #v = map.get_value_at(target_name, x+dx)
            v = map_index[target_name].get_value(x+dx)
            #if v == None:
            #    v = 0.
            try:
                data[f*dx]
            except:
                data[f*dx] = []
            if v is not None:
                data[f*dx] += n*[v]
            dx -= res
        dx = res
        while x+dx < target_length and (limit is None or abs(dx) < limit):
            #v = map.get_value_at(target_name, x+dx)
            v = map_index[target_name].get_value(x+dx)
            #if v == None:
            #    v = 0.
            try:
                data[f*dx]
            except:
                data[f*dx] = []
            if v is not None:
                data[f*dx] += n*[v]
            dx += res

def density_profile_new(loci, map, consider_strain=False, limit=None, target_name=None, verbose=1):
    if verbose:
        Prot.write('Generating Density Profile for %s loci in %s (%s targets) map.' % (len(loci), map.name, len(map.keys())))
    # Map index:
    map_index = {target_name:Oligo.Index(map[target_name], index_func= lambda bin:bin.start, value_func=lambda bin:bin.count, allow_multiple=False) for target_name in map.keys()}
    # Generate Pseudo Map
    res = map.resolution
    if consider_strain:
        reverse_loci = [locus for locus in loci if locus.strand == '-']
        loci = [locus for locus in loci if locus.strand in ['+',None,'?']]
        reverse_buckets = Oligo.Loci.generate_main_buckets(reverse_loci, bucket_size=res)
    else:
        reverse_buckets = Oligo.Loci.generate_main_buckets([], bucket_size=res, verbose=0)
    buckets = Oligo.Loci.generate_main_buckets(loci, bucket_size=res)
    data = {}
    target_length = map.target_lengths[target_name]
    density_profile_execute_buckets(buckets, map_index, target_name, target_length, res, data, limit, f=+1)
    density_profile_execute_buckets(reverse_buckets, map_index, target_name, target_length, res, data, limit, f=-1)
    ret = {'distance':[],'mean density':[], 'std density':[], 'n':[], 'err':[], 'model density':[], 'model err':[], 'map density':[], 'map std':[]}
    for key in sorted(data.keys()):
        if len(data[key]) == 0:
            v = 0.0
            err = 0.0
            std = 0.0
            n = 0
        else:
            v = np.mean(data[key])
            std = np.std(data[key])
            n = len(data[key])
            err = std/np.sqrt(n)
        ret['distance'].append(key)
        ret['mean density'].append(v)
        ret['std density'].append(std)
        ret['n'].append(n)
        ret['err'].append(err)
        ret['model density'].append(sum([bin.count for bin in map[target_name]])/len(map[target_name]))
        ret['model err'].append(np.sqrt(ret['model density'][-1]*(1.-1./len(map))))
        ret['map density'].append(sum([bin.count for bin in map[target_name]])/len(map[target_name]))
        ret['map std'].append(np.std([bin.count for bin in map[target_name]]))
    if verbose:
        Prot.write('Generated Density Profile with %s values.' % len(ret['distance']))
    return ret

def density_profile(loci, map, consider_strain=False, limit=None, target_name=None, verbose=1):
    if verbose:
        Prot.write('Generating Density Profile for %s loci in %s (%s targets) map.' % (len(loci), map.name, len(map.keys())))
    data = {}
    for locus in loci:
        x = locus.start
        if target_name is None:
            target_name = locus.target.name
        if consider_strain and locus.strand != 1:
            f = -1
        else:
            f = 1
        v = map.get_value_at(target_name, x)
        try:
            data[0]
        except:
            data[0] = []
        if v is not None:
            data[0].append(v)
        dx = -map.resolution
        while x+dx > 0 and (limit is None or abs(dx) < limit):
            v = map.get_value_at(target_name, x+dx)
            try:
                data[f*dx]
            except:
                data[f*dx] = []
            if v is not None:
                data[f*dx].append(v)
            dx -= map.resolution
        dx = map.resolution
        while x+dx < map.target_lengths[target_name] and (limit is None or abs(dx) < limit):
            v = map.get_value_at(target_name, x+dx)
            try:
                data[f*dx]
            except:
                data[f*dx] = []
            if v is not None:
                data[f*dx].append(v)
            dx += map.resolution

    ret = {'distance':[],'mean density':[], 'std density':[], 'n':[], 'err':[], 'model density':[], 'model err':[], 'map density':[], 'map std':[]}
    for key in sorted(data.keys()):
        if len(data[key]) == 0:
            v = 0.0
            err = 0.0
            std = 0.0
            n = 0
        else:
            v = np.mean(data[key])
            std = np.std(data[key])
            n = len(data[key])
            err = std/np.sqrt(n)
        ret['distance'].append(key)
        ret['mean density'].append(v)
        ret['std density'].append(std)
        ret['n'].append(n)
        ret['err'].append(err)
        ret['model density'].append(sum([bin.count for bin in map[target_name]])/len(map[target_name]))
        ret['model err'].append(np.sqrt(ret['model density'][-1]*(1.-1./len(map))))
        ret['map density'].append(sum([bin.count for bin in map[target_name]])/len(map[target_name]))
        ret['map std'].append(np.std([bin.count for bin in map[target_name]]))
    if verbose:
        Prot.write('Generated Density Profile with %s values.' % len(ret['distance']))
    return ret

def save_density_profile(output_filename, profile):
    Oligo.File.save_dat(output_filename, profile)

def read_density_profile_old(input_filename, verbose=1):
    if verbose:
        Prot.write('Reading Density Profile from %s.' % input_filename)
    data = Oligo.File.read_dat(input_filename)
    for key in ['distance','mean density', 'std density', 'err', 'model err', 'model density']:
        data[key] = [float(d) for d in data[key]]
    for key in ['n']:
        data[key] = [int(d) for d in data[key]]
    if verbose:
        Prot.write('Found %s lines.' % len(data['n']))
    return data
    
def read_density_profile(input_filename, verbose=1):
    if verbose:
        Prot.write('Reading Density Profile from %s.' % input_filename)
    data = Oligo.File.read_dat_lines(input_filename)
    for i,d in enumerate(data):
        for key in ['distance','mean density', 'std density', 'err', 'model err', 'model density']:
            data[i][key] = float(d[key])
        for key in ['n']:
            data[i][key] = int(d[key])
    if verbose:
        Prot.write('Found %s lines.' % len(data))
    return data

def get_density_profile_value_at_distance(profile, distance):
    for i, d in enumerate(profile['distance']):
        if d == distance:
            return {'distance':profile['distance'][i],'mean density':profile['mean density'][i], 'std density':profile['std density'][i], 'n':profile['n'][i], 'err':profile['err'][i], 'model err':profile['model err'][i] ,'model density':profile['model density'][i]}
    return None

def combine_density_profiles_old(profiles, rel=False):
    # Collect all distances
    distances = []
    for profile in profiles:
        distances += profile['distance']
    distances = sorted(list(set(distances)))
    n = [0]*len(distances)
    mean_densities = [0.0]*len(distances)
    std_densities = [0.0]*len(distances)
    errs = [0.0]*len(distances)
    if not rel:
        mean_model_densities = [0.0]*len(distances)
        model_errs = [0.0]*len(distances)
    else:
        mean_model_densities = [0.0]*len(distances)
        model_errs = [1.0]*len(distances)
    for i, distance in enumerate(distances):
        densities = []
        model_densities = []
        for p in profiles:
            data = get_density_profile_value_at_distance(p, distance)
            if data is not None:
                n[i] += 1
                if rel:
                    densities.append((data['mean density']-data['model density'])/np.sqrt(data['std density']**2+data['model err']**2))
                else:
                    densities.append(data['mean density'])
                    model_densities.append(data['model density'])
        if not rel:
            mean_model_densities[i] = np.mean(model_densities)
            model_errs[i] = np.std(model_densities)/np.sqrt(n[i])
        mean_densities[i] = np.mean(densities)
        std_densities[i] = np.std(densities)
        errs[i] = std_densities[i]/np.sqrt(n[i])
    return {'distance':distances,'mean density':mean_densities, 'std density':std_densities, 'n':n, 'err':errs, 'model density':mean_model_densities, 'model err':model_errs}

def combine_density_profiles(profiles, rel=False):
    # Collect all distances
    distances = sorted([d['distance'] for d in profiles[0]])
    mean_densities = []
    std_densities = []
    ns = []
    data = []
    for dist in distances:
        values = []
        model_values = []
        for profile in profiles:
            for d in profile:
                if d['distance'] == dist:
                   values.append(d['mean density'])
                   model_values.append(d['model density'])
                   break
        data.append({'distance':dist, 'mean density':np.mean(values), 'std density':np.std(values), 'n':len(values), 'err':np.std(values)/np.sqrt(len(values)), 'model density':np.mean(model_values), 'model err':np.std(model_values)/np.sqrt(len(values))})
    return data
    
def generate_sequence_property_bins(targets, resolution, name, properties_index, k=None, verbose=1):
    if k is None:
        k = len(properties_index.keys()[0])
    if verbose:
        Prot.write('Generate %s Property Bins (%skb) from targets %s.' % (name, resolution, len(targets)))
    map_bins = {}
    for target in targets:
        if verbose:
            Prot.write('Generate %s Property Bins bins for %s (%sbp).' % (name, target.name, len(target)))
        if target.seq is None:
            target.load_seq()
            drop_seq = True
        else:
            drop_seq = False
        bins = {}
        target_bin = 0
        max_index = ceil(len(target)/resolution)
        for i in range(len(target)):
            seq = target.seq[i:i+k]
            bin_index = int(i/resolution)
            try:
                bins[bin_index]
            except:
                bins[bin_index] = Oligo.Loci.bins.Bin(0.0, bin_index*resolution, (bin_index+1)*resolution)
            try:
                properties_index[seq]
            except:
                v = 0.0
            else:
                v = properties_index[seq]
            bins[bin_index].count += v
        if verbose:
            Prot.write('Generated %s bins.' % len(bins))
        map_bins[target.name] = bins
        map_bins[target.name] = [map_bins[target.name][ki] for ki in sorted(map_bins[target.name].keys())]
        if drop_seq:
            target.unload_seq()
    return map_bins

def generate_sequence_property_map(targets, resolution, name, properties_index, k=None, verbose=1):
    map_bins = generate_sequence_property_bins(targets, resolution, name, properties_index, k, verbose)
    map = DensityMap(bins={str(target):map_bins[target.name] for target in targets}, name=name, orga=targets[0].orga, target_lengths={str(target):len(target) for target in targets}, resolution=resolution)
    return map

def generate_sequence_property_loci_bins(targets, resolution, name, properties_index, k=None, loci=None, target_loci=None, verbose=1):
    #print properties_index,properties_index.keys()
    if k is None:
        k = len(properties_index.keys()[0])
    if verbose:
        if loci is not None:
            Prot.write('Generate Generate %s Property Bins (%s) from targets %s at loci %s.' % (name, resolution, len(targets), len(loci)))
        else:
            n = sum([len(target_loci[key]) for key in target_loci])
            Prot.write('Generate Generate %s Property Bins (%s) from targets %s at loci. %s' % (name, resolution, len(targets), n))
    map_bins = {}
    if target_loci is None:
        target_loci = DensityMap.split_loci_by_target(loci)
    for target in targets:
        loci = target_loci[target.name]
        if verbose:
            Prot.write('Generate Generate %s Property bins for %s (%s loci).' % (name, target.name, len(loci)))
        if target.seq is None:
            target.load_seq()
            drop_seq = True
        else:
            drop_seq = False
        mean_value = np.mean([properties_index[key] for key in properties_index])
        bins = {}
        min_value = int(min([locus.start for locus in loci])/resolution)*resolution
        max_value = ceil(max([locus.get_end() for locus in loci])/resolution)*resolution
        for locus in loci:
            #if target.name == 'c2':
            #    print 1,locus
            posi = locus.start
            locus_end = locus.get_end()
            while posi < locus_end:
                index = int((posi-min_value)/resolution)
                bin_locus = Oligo.Locus(start=index*resolution+min_value, length=resolution)
                overlap_start, overlap_end = locus.get_overlap(bin_locus)
                #if target.name == 'c2':
                #    print 2,index,bin_locus,overlap_start,overlap_end,k
                for i in range(overlap_start, overlap_end-k+1):
                    seq = target.seq[i:i+k]
                    try:
                        bins[index]
                    except:
                        bins[index] = Oligo.Loci.bins.Bin(0.0, index*resolution, (index+1)*resolution)
                    #if target.name == 'c2':
                    #    print 3,bins[index]
                    try:
                        properties_index[seq]
                    except:
                        v = mean_value
                    else:
                        v = properties_index[seq]
                    bins[index].count += v
                posi += resolution
        if verbose:
            Prot.write('Generated %s bins.' % len(bins.keys()))
        map_bins[target.name] = bins
        map_bins[target.name] = [map_bins[target.name][key] for key in sorted(map_bins[target.name].keys())]
        if drop_seq:
            target.unload_seq()
    if verbose:
        Prot.write('Generated (%s) maps.' % len(map_bins))
    return map_bins

def generate_sequence_property_loci_map(targets, resolution, name, properties_index, k=None, loci=None, target_loci=None, verbose=1):
    map_bins = generate_sequence_property_loci_bins(targets, resolution, name, properties_index, k, loci, target_loci, verbose)
    map = DensityMap(bins={str(target):map_bins[target.name] for target in targets}, name=name, orga=targets[0].orga, target_lengths={str(target):len(target) for target in targets}, resolution=resolution)
    return map

def generate_nucleotide_content_bins(targets, resolution, verbose=1):
    if verbose:
        Prot.write('Generate Nucleotide Density Bins (%skb) from targets %s.' % (resolution, len(targets)))
    map_bins = {}
    for target in targets:
        if verbose:
            Prot.write('Generate Nucleotide Density bins for %s (%sbp).' % (target.name, len(target)))
        if target.seq is None:
            target.load_seq()
            drop_seq = True
        else:
            drop_seq = False
        bins = {'A':{},'C':{},'G':{},'T':{},'N':{}}
        target_bin = 0
        max_index = ceil(len(target)/resolution)
        for i in range(len(target)):
            nuc = target.seq[i]
            bin_index = int(i/resolution)
            try:
                bins[nuc]
            except:
                bins[nuc] = {}
            try:
                bins[nuc][bin_index]
            except:
                bins[nuc][bin_index] = Oligo.Loci.bins.Bin(0.0, bin_index*resolution, (bin_index+1)*resolution)
            bins[nuc][bin_index].count += 1
        if verbose:
            Prot.write('Generated %s bins.' % len(bins))
        map_bins[target.name] = bins
        for nuc in map_bins[target.name].keys():
            map_bins[target.name][nuc] = [map_bins[target.name][nuc][k] for k in sorted(map_bins[target.name][nuc].keys())]
        if drop_seq:
            target.unload_seq()
    return map_bins

def generate_nucleotide_content_maps(targets, resolution, verbose=1):
    map_bins = generate_nucleotide_content_bins(targets, resolution, verbose)
    maps = []
    for nuc in ['A','C','G','T','N']:
        map = DensityMap(bins={str(target):map_bins[target.name][nuc] for target in targets}, name=nuc+' Content', orga=targets[0].orga, target_lengths={str(target):len(target) for target in targets}, resolution=resolution)
        maps.append(map)
    return maps

def generate_nucleotide_content_loci_bins(targets, resolution, loci=None, target_loci=None, verbose=1):
    if verbose:
        if loci is not None:
            Prot.write('Generate Nucleotide Density Bins (%s) from targets %s at loci %s.' % (resolution, len(targets), len(loci)))
        else:
            Prot.write('Generate Nucleotide Density Bins (%s) from targets %s at loci.' % (resolution, len(targets)))
    map_bins = {}
    if target_loci is None:
        target_loci = DensityMap.split_loci_by_target(loci)
    for target in targets:
        loci = target_loci[target.name]
        if verbose:
            Prot.write('Generate Nucleotide Density bins for %s (%s loci).' % (target.name, len(loci)))
        if target.seq is None:
            target.load_seq()
            drop_seq = True
        else:
            drop_seq = False
        bins = {'A':{},'C':{},'G':{},'T':{},'N':{}}
        min_value = int(min([locus.start for locus in loci])/resolution)*resolution
        max_value = ceil(max([locus.get_end() for locus in loci])/resolution)*resolution
        for locus in loci:
            posi = locus.start
            locus_end = locus.get_end()
            while posi < locus_end:
                index = int((posi-min_value)/resolution)
                bin_locus = Oligo.Locus(start=index*resolution+min_value, length=resolution)
                overlap_start, overlap_end = locus.get_overlap(bin_locus)
                for i in range(overlap_start, overlap_end):
                    nuc = target.seq[i]
                    try:
                        bins[nuc]
                    except:
                        bins[nuc] = {}
                    try:
                        bins[nuc][index]
                    except:
                        bins[nuc][index] = Oligo.Loci.bins.Bin(0.0, index*resolution, (index+1)*resolution)
                    bins[nuc][index].count += 1
                posi += resolution
        if verbose:
            Prot.write('Generated %s bins.' % len(bins.keys()))
        map_bins[target.name] = bins
        for nuc in map_bins[target.name].keys():
            map_bins[target.name][nuc] = [map_bins[target.name][nuc][k] for k in sorted(map_bins[target.name][nuc].keys())]
        if drop_seq:
            target.unload_seq()
    if verbose:
        Prot.write('Generated (%s) maps.' % len(map_bins))
    return map_bins

def generate_nucleotide_content_loci_maps(targets, resolution, loci=None, target_loci=None, name='loci', verbose=1):
    map_bins = generate_nucleotide_content_loci_bins(targets, resolution, loci, target_loci, verbose)
    maps = []
    for nuc in ['A','C','G','T','N']:
        map = DensityMap(bins={str(target):map_bins[target.name][nuc] for target in targets}, name=name+' '+nuc+' Content', orga=targets[0].orga, target_lengths={str(target):len(target) for target in targets}, resolution=resolution)
        maps.append(map)
    return maps

def modify_map(map, modify_func, modify_func_args=(), map_name=None, verbose=1):
    if verbose:
        Prot.write('Modifying Map %s (%s).' % (map.name, len(map)))
    if map_name is None:
        map_name = map.name
    target_names = map.keys()
    target_names = list(set(target_names))
    target_lengths = {}
    for target_name in map:
        target_lengths[target_name] = map.target_lengths[target_name]
    resolution = map.resolution
    bins = {}
    for target_name in target_names:
        i = 0
        bins[target_name] = []
        while i*resolution < target_lengths[target_name]:
            value = map.get_value_at(target_name, i*resolution)
            x = modify_func(value, *modify_func_args)
            if x != 0:
                bins[target_name].append(Oligo.Loci.bins.Bin(x, i*resolution, (i+1)*resolution))
            i += 1
    map = DensityMap(bins=bins, name=map_name, orga=map.orga, target_lengths=map.target_lengths, resolution=resolution)
    return map

def norm_func(x, mean, std):
    if x is None:
        x = 0.
    return float(x-mean)/std

def norm_map(map, mask=None):
    mean, std = map.mean(mask=mask), map.std(mask=mask)
    map = modify_map(map, modify_func=norm_func, modify_func_args=(mean, std), map_name=map.name)
    return map
    
def combine_maps2(maps, map_name, combine_func=sum, combine_func_args=(), resolution=None, verbose=1):
    if verbose:
        Prot.write('Combining Maps %s maps (%s).' % (len(maps),','.join([str(map.name) for map in maps])))
    if resolution is None:
        resolution = maps[0].resolution
    # Collect all target names
    target_names = []
    target_lengths = {}
    for map in maps:
        target_names += map.keys()
        for target_name in map.keys():
            target_lengths[target_name] = map.target_lengths[target_name]
    target_names = list(set(target_names))
    bins = {}
    for target_name in target_names:
        bins[target_name] = []
        # collect all bin positions
        positions = []
        for map in maps:
            map_bins = map[target_name]
            try:
                map_bins = map[target_name]
            except:
                map_bins = []
            for bin in map_bins:
                positions.append(bin.start)
            del map_bins
        positions = list(set(positions))
        # Create Map Indices
        map_indices = [Oligo.Index(map[target_name], index_func= lambda bin:bin.start, allow_multiple=False) for map in maps]
        # Combine Maps
        for position in positions:
            values = [map_indices[i].get_value(position) for i,map in enumerate(maps)]
            x = combine_func(values, *combine_func_args)
            if x != 0 and x != None:
                bins[target_name].append(Oligo.Loci.bins.Bin(x, position, position+resolution))
        del map_indices, positions
    # Create new map
    map = DensityMap(bins=bins, name=map_name, orga=maps[0].orga, target_lengths=target_lengths, resolution=resolution)
    return map
                
                
def combine_maps(maps, map_name=None, combine_func=sum, combine_func_args=(), resolution=None, verbose=1):
    if verbose:
        Prot.write('Combining Maps %s maps (%s).' % (len(maps),','.join([str(map.name) for map in maps])))
    target_names = []
    for map in maps:
        target_names += map.keys()
    target_names = list(set(target_names))
    target_lengths = {}
    for map in maps:
        for target_name in map:
            target_lengths[target_name] = map.target_lengths[target_name]
    if resolution is None:
        resolution = maps[0].resolution
    bins = {}
    for target_name in target_names:
        i = 0
        bins[target_name] = []
        while i*resolution < target_lengths[target_name]:
            values = [map.get_value_at(target_name, i*resolution) for map in maps]
            values = [v if v is not None else 0.0 for v in values]
            #print i,values
            x = combine_func(values, *combine_func_args)
            #print i,values,x
            #print(target_name, values, x)
            if x != 0:
                bins[target_name].append(Oligo.Loci.bins.Bin(x, i*resolution, (i+1)*resolution))
            i += 1
    map = DensityMap(bins=bins, name=map_name, orga=maps[0].orga, target_lengths=target_lengths, resolution=resolution)
    return map
    
def mask_from_map(map, lower_th=None, upper_th=None, target_names=None, limits=None):
    data = map.list(target_names=target_names, limits=limits)
    mask = []
    for i in range(len(data)):
        if (lower_th is None or data[i] >= lower_th) and (upper_th == None or data[i] <= upper_th):
            mask.append(1)
        else:
            mask.append(0)
    return mask

  
def generate_kmer_bins(spectra, kmer, resolution):
    bins = []
    ix = 0
    for spectrum in spectra:
        value = spectrum.get_count(kmer)
        if value != 0:
            #bins[ix] = Oligo.Loci.bins.Bin(value, ix*resolution, (ix+1)*resolution)
            bins.append(Oligo.Loci.bins.Bin(value, ix*resolution, (ix+1)*resolution))
        ix += 1
    return bins
  
def generate_kmer_maps(chromos, resolution, k, output_filenames=None, words=None, allow_delet_seq=True, filter_loci=None, allow_delete_maps=False, filter_loci_read_functions=None, filter_loci_read_functions_args=None, verbose=1):
    if verbose:
        Prot.write('Generate k-mer map (k=%s) for %s targets.' % (k, len(chromos)))
    spectra = {}
    for chromo in chromos:
        region_loci = []
        posi = 0
        while posi < len(chromo):
            region_loci.append(Oligo.Locus(start=posi, end=posi+resolution))
            posi += resolution
        if filter_loci is not None:
            fl = filter_loci[chromo.name]
        elif filter_loci_read_functions is not None:
            fl = filter_loci_read_functions[chromo.name](*filter_loci_read_functions_args[chromo.name])
        else:
            fl = None
        spectra[str(chromo)] = Oligo.Search.search_individual_loci_kmer(chromo.get_seq(), k, output_filename=None, loci=region_loci, data_seq_name=chromo.name, merge_loci=False, filter_loci=fl)
        if allow_delet_seq:
            chromo.unload_seq()
        del fl
    if verbose:
        Prot.write('Convert spectra to maps.')
    if words is None:
        all_spectra = []
        for chromo in chromos:
            all_spectra += spectra[str(chromo)]
        words = Oligo.Kmer.get_k_from_spectra(all_spectra)
        del all_spectra
    maps = []
    for word in words:
        map = DensityMap(bins={str(target): generate_kmer_bins(spectra[str(target)], word, resolution) for target in chromos}, name=word, orga=chromos[0].orga, target_lengths={str(target):len(target) for target in chromos}, resolution=resolution)
        if allow_delete_maps:
            map.save(output_filenames[map.name])
            del map
        else:
            maps.append(map)
    if not allow_delete_maps:
        if verbose:
            Prot.write('Generated %s maps.' % len(maps))
        if output_filenames is not None:
            for map in maps:
                map.save(output_filenames[map.name])
        return maps
    return None

def bins_from_list(list, target_names, target_lengths, resolution):
    target_list_sizes = {}
    target_bins = {target_name:[] for target_name in target_names}
    for target_name in target_names:
        target_length = target_lengths[target_name]
        target_list_sizes[target_name] = int(target_length/resolution)
        if int(target_length/resolution)*resolution < target_length:
            target_list_sizes[target_name] += 1
    offset = 0
    for target_name in target_names:
        target_data = list[offset:offset+target_list_sizes[target_name]]
        for i,value in enumerate(target_data):
            if value != 0:
                target_bins[target_name].append(Oligo.Bin(value,i*resolution,(i+1)*resolution))
        offset += target_list_sizes[target_name]
    return target_bins

def shuffle_list(original_list, mask=None):
    target_list = list(range(len(original_list)))
    np.random.shuffle(target_list)
    shuffled_list = [0]*len(original_list)
    j = 0
    for i,e in enumerate(original_list):
        if mask is None or mask[i]:
            while mask is not None and not mask[target_list[j]]:
                j += 1
            shuffled_list[target_list[j]] = e
            j += 1
    return shuffled_list
        
def map_from_list(list, target_names, target_lengths, resolution, map_name):
    bins = bins_from_list(list, target_names, target_lengths, resolution)
    return DensityMap(bins=bins, name=map_name, target_lengths=target_lengths, resolution=resolution)
    
def shuffle_map(map, mask=None, map_name=None, verbose=1):
    if verbose:
        Oligo.Prot.write('Shuffle Map %s.' % map.name)
    if map_name is None:
        map_name = str(map.name)+' shuffled'
    target_names = map.get_target_names()
    list = map.list(target_names=target_names)
    list = shuffle_list(list,mask)
    return map_from_list(list, target_names, map.target_lengths, map.resolution, map_name)
    
