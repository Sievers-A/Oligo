from Oligo.Loci.bins import Bin

class Map(object):

    def __init__(self, name, bin_start, bin_size, bins=None, target=None):
        self.target = target
        self.bin_start = bin_start
        self.bin_size = bin_size
        self.name = name
        self.bins = bins
        
    def get_bin_ix(self, posi):
        return int((posi-self.bin_start)/self.bin_size)
        
    def get_locus_bin(self, locus):
        return self.get_bin_at(locus.start)
        
    def get_bin_at(self, posi):    
        bin_ix = self.get_bin_ix(posi)
        try:
            self.bins[bin_ix]
        except:
            return Bin(0.0, self.bin_start+bin_ix*self.bin_size, self.bin_start+(bin_ix+1)*self.bin_size)
        return self.bins[bin_ix]
        
    def get_neighbour_bins(self, posi, n_neighbour=1):
        dx = n_neighbour*self.bin_size
        return [self.get_bin_at(posi-dx), self.get_bin_at(posi+dx)]