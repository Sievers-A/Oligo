import Oligo
from Oligo import Prot
from math import ceil

class MapMask(object):

    def __init__(self, target_lists, target_names):
        self.target_lists = {target_name:target_list for (target_name, target_list) in zip(target_names,target_lists)}
        self.target_names = target_names
        
    def get_list(self, target_names=None):
        if target_names is None:
            target_names = self.target_names
        r = []
        for target_name in target_names:
            try:
                self.target_lists[target_name]
            except:
                r += []
                Prot.warn('Could not find target_name "%s" in get_list of MapMask.' % target_name)
            else:
                r += self.target_lists[target_name]
        return r
    
    def get_map(self, resolution, target_lengths=None, name=None, orga=None):
        if target_lengths is None:
            target_lengths = {target_name : resolution*len(self.target_lists[target_name]) for target_name in self.target_lists}
        map_bins = {}
        for target_name in self.target_names:
            map_bins[target_name] = [Oligo.Loci.bins.Bin(x, index*resolution, (index+1)*resolution) for index,x in enumerate(self.target_lists[target_name])]
        return Oligo.Maps.DensityMap(bins=map_bins, name=name, orga=orga, target_lengths=target_lengths, resolution=resolution)
    
    def save(self,output_filename):
        Oligo.Prot.write('Saving Mask to %s.' % output_filename)
        output_file = open(output_filename,'w')
        for target_name in self.target_names:
            output_file.write('target\t%s\n' % target_name)
            for v in self.target_lists[target_name]:
                output_file.write('%s\n' % v)
        output_file.close()
    
    def inverse(self):
        target_lists = []
        for target_name in self.target_names:
            target_lists.append([1 if x == 0 else 1 for x in self.target_lists[target_name]])
        return MapMask(target_lists, self.target_names[:])
        
    @classmethod
    def mask_from_loci(cls, resolution, target_loci=None, target_names=None, target_lengths=None, chromosomes=None):
        mask = MapMask.empty_mask(resolution, target_names, target_lengths, chromosomes)
        if target_names is None:
            target_names = [chromo.name for chromo in chromosomes]
        for target_name in target_names:
            loci = target_loci[target_name]
            for locus in loci:
                posi = locus.start
                end = locus.get_end()
                while posi < end:
                    index = int(posi/resolution)
                    if index >= len(mask.target_lists[target_name]):
                        Oligo.Prot.warn('Index %s (position: %s) out of range. Max. index: %s (%s bp).' % (index,index*resolution,len(mask.target_lists[target_name])-1,resolution*(len(mask.target_lists[target_name])-1)))
                    mask.target_lists[target_name][index] = 1
                    posi += resolution
        return mask
                
    @classmethod
    def empty_mask(cls, resolution, target_names=None, target_lengths=None, chromosomes=None):
        if target_lengths is None:
            target_names, target_lengths = [], []
            for chromo in chromosomes:
                target_names.append(chromo.name)
                target_lengths.append(len(chromo))
        target_lists = []
        for (target_name,target_length) in zip(target_names, target_lengths):
            #print(target_length, resolution, float(target_length)/resolution, ceil(float(target_length)/resolution))
            max_index = ceil(float(target_length)/resolution)
            target_lists.append([0]*(max_index+1))
            #print(target_name,max_index,target_length)
        return MapMask(target_lists, target_names)
    
    @classmethod
    def read(cls, input_filename):
        Oligo.Prot.write('Reading Mask from %s.' % input_filename)
        f = open(input_filename,'r')
        target_names = []
        target_lists = []
        for line in f:
            if line != '' and line[0] != '#':
                if line[0] == 't':
                    words = line.rstrip().split('\t')
                    target_names.append(words[1])
                    target_lists.append([])
                else:
                    target_lists[-1].append(int(line))
        f.close()
        return MapMask(target_lists=target_lists, target_names=target_names)
        
    @classmethod
    def mask_from_map(cls, map, mask_function=None, mask_function_args=[], target_names=None):
        Oligo.Prot.write('Creating Mask from Map (%s).' % map.name)
        if target_names is None:
            target_names = map.get_target_names()
        target_lists = []
        for target_name in target_names:
            target_lists.append([])
            l = map.list(target_names=[target_name])
            for li in l:
                if mask_function is None:
                    v = li
                else:
                    v = mask_function(li,*mask_function_args)
                target_lists[-1].append(v)
        return MapMask(target_lists=target_lists, target_names=target_names)
        
    @classmethod
    def combine_masks(cls, masks, combine_function=None, combine_function_args=[]):
        Oligo.Prot.write('Combining %s masks.' % len(masks))
        target_names = masks[0].target_names
        target_lists = []
        for target_name in target_names:
            target_lists.append([])
            ls = [mask.get_list(target_names=[target_name]) for mask in masks]
            s = None
            for l in ls:
                if s is None:
                    s = len(l)
                elif len(l) != s:
                    Prot.warn('Cannot combine masks of different sizes %s and %s for targes %s in MapMask.combine_masks.' % (s,len(l),target_name))
            for i in range(len(ls[0])):
                vs = [l[i] for l in ls]
                if combine_function is None:
                    combine_function = lambda vis: 1 if 0 not in vis else 0
                target_lists[-1].append(combine_function(vs,*combine_function_args))
        return MapMask(target_lists=target_lists, target_names=target_names)
        