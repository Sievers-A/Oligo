import numpy as np
from Oligo.Loci import Locus
from Oligo.Loci.locus import generate_start_buckets
from Oligo import Prot

class Variant(Locus):

    def __init__(self, start, ref, alt, target, genotype=None, allelic_depth=None, allelic_frequency=None, strand='+'):
        length = len(alt)
        self.ref = ref
        self.alt = alt
        self.allelic_depth = allelic_depth
        self.allelic_frequency = allelic_frequency
        self.genotype = genotype
        super(Variant, self).__init__(start=start, length=length, strand=strand, target=target)

    def is_heterozygote(self):
        return str(self.target) != 'chrX' and self.genotype == '0/1'

    def is_homozygote(self):
        return str(self.target) != 'chrX' and self.genotype == '1/1'

    def __eq__(self, other):
        if isinstance(other, Locus) and self.target == other.target and other.start == self.start and other.alt == self.alt:
            return True
        return False

    def __repr__(self):
        return '<Variant:'+str(self.target)+':'+str(self.start)+'|'+str(self.ref)+'->'+str(self.alt)+'|'+str(self.genotype)+'|'+str(self.allelic_frequency)+'|'+str(self.allelic_depth)+'>'

    @classmethod
    def read(cls, input_filename, sample_id=None, verbose=1):
        if verbose:
            Prot.write('Reading variants from %s.' % input_filename)
        variants = []
        f = open(input_filename, 'r')
        for line in f:
            if line[0:1] != '##':
                words = line.rstrip().split('\t')
                if words[0] == '#CHROM':
                    words[0] = words[0][1:]
                    # #CHROM	POS	ID	REF	ALT	QUAL	FILTER	INFO	FORMAT	index
                    head_index = {w:i for i,w in enumerate(words)}
                    samples = words[9:]
                    if sample_id is None:
                        sample_id = samples[0]
                elif line[0] != '#':
                    start = int(words[head_index['POS']])
                    ref = words[head_index['REF']]
                    alt = words[head_index['ALT']]
                    target = words[head_index['CHROM']]
                    if len(target) < 4: #  Different chromosome naming conventions
                        target = 'chr'+target
                    # Generate Format data
                    format_keys= words[head_index['FORMAT']].split(':')
                    format = {sample:{k:None for k in format_keys} for sample in samples}
                    for sample in samples:
                        format_sample_values = words[head_index[sample]].split(':')
                        format[sample] = {k:format_sample_values[i] for i,k in enumerate(format_keys)}
                    genotype = format[sample_id]['GT']
                    allelic_depth = int(format[sample_id]['AD'].split(',')[1])
                    dp = int(format[sample_id]['DP'])
                    if allelic_depth != 0:
                        allelic_frequency = float(allelic_depth)/dp
                    else:
                        allelic_frequency = 0.0
                    variant = Variant(start, ref, alt, target, genotype, allelic_depth, allelic_frequency)
                    variant.set_value('sample',words[-1])
                    variant.set_value('ID',words[head_index['ID']])
                    variant.set_value('QUAL',words[head_index['QUAL']])
                    variant.set_value('FILTER',words[head_index['FILTER']])
                    variant.set_value('INFO',words[head_index['INFO']])
                    variant.set_value('FORMAT',words[head_index['FORMAT']])
                    variants.append(variant)
        f.close()
        if verbose:
            Prot.write('Found %s variants.' % len(variants))
        return variants

def allelic_frequency_stats(variants):
    data = np.array([v.allelic_frequency for v in variants if v.allelic_frequency is not None])
    return {'mean':np.mean(data),'std':np.std(data),'n':len(data)}

def read(input_filename, sample_id=None, verbose=1):
    return Variant.read(input_filename, sample_id, verbose)

def filter_false_positives(variants, ref_variants, force_matching_genotype=True, verbose=1):
    if verbose:
        Prot.write('Filtering false positive variants (%s) by reference variants (%s)' % (len(variants), len(ref_variants)))
    # Generate Index
    ref_index = {}
    for variant in ref_variants:
        try:
            ref_index[variant.start]
        except:
            ref_index[variant.start] = [variant]
        else:
            ref_index[variant.start].append(variant)
    filtered_variants = []
    for variant in variants:
        tp = False
        try:
            ref_index[variant.start]
        except:
            pass
        else:
            for ref_variant in ref_index[variant.start]:
                if ref_variant == variant and (not force_matching_genotype or ref_variant.genotype == variant.genotype):
                    tp = True
                    break
        if not tp:
            filtered_variants.append(variant)
    if verbose:
        Prot.write('%s variants remaining (%s%%)' % (len(filtered_variants), 100.*round(float(len(filtered_variants))/len(variants),2)))
    return filtered_variants

def filter_true_positives(variants, ref_variants, force_matching_genotype=True, verbose=1):
    if verbose:
        Prot.write('Filtering true positive variants (%s) by reference variants (%s)' % (len(variants), len(ref_variants)))
    # Generate Index
    ref_index = {}
    for variant in ref_variants:
        try:
            ref_index[variant.start]
        except:
            ref_index[variant.start] = [variant]
        else:
            ref_index[variant.start].append(variant)
    filtered_variants = []
    for variant in variants:
        tp = False
        try:
            ref_index[variant.start]
        except:
            pass
        else:
            for ref_variant in ref_index[variant.start]:
                if ref_variant == variant and (not force_matching_genotype or ref_variant.genotype == variant.genotype):
                    tp = True
                    break
        if tp:
            filtered_variants.append(variant)
    if verbose:
        Prot.write('%s variants remaining (%s%%)' % (len(filtered_variants), 100.*round(float(len(filtered_variants))/len(variants),2)))
    return filtered_variants

def filter_loci(variants, loci, bucket_size=None, verbose=1):
    if verbose:
        Prot.write('Filter variants (%s) by loci (%s)' % (len(variants), len(loci)))
    max_loci_size = max([len(locus) for locus in loci])
    max_variant_size = max([len(v) for v in variants])
    bucket_size = min(100000, max(max_loci_size, max_variant_size)+1)
    if verbose:
        Prot.write('max loci size = %s , max variant size = %s Set bucket size to %s.' % (max_loci_size, max_variant_size, bucket_size))
    # Generate loci buckets:
    buckets = generate_start_buckets(loci, bucket_size, verbose=1)
    # Filtering
    f_variants = []
    for variant in variants:
        is_exon_variant = False
        key = buckets.calculate_bucket_key(variant.start)
        keys = [key-1, key, key+1]
        for key in keys:
            bucket_loci = buckets.get_bucket(key)
            for locus in bucket_loci:
                if locus.check_overlap(variant):
                    is_exon_variant = True
                    break
            if is_exon_variant:
                break
        if is_exon_variant:
            f_variants.append(variant)
    if verbose:
        Prot.write('%s variants passed (%s%%)' % (len(f_variants), round(100*float(len(f_variants))/len(variants))))
    return f_variants
