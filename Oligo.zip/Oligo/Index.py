import Oligo

class Index(dict):

    def __init__(self, objects, index_func, index_func_args=(), value_func=None, value_func_args=(), ignore_none_index=True, allow_multiple=True, verbose=1):
        index = {}
        if value_func is None:
            value_func = lambda o : o
        for o in objects:
            i_s = index_func(o, *index_func_args)
            if isinstance(i_s, str):
                i_s = [i_s]
            else:
                try: # check if index function multiple outputs
                    i_s[0]
                except:
                    i_s = [i_s]
            for i in i_s:
                if i is not None or not ignore_none_index:
                    try:
                        index[i]
                    except:
                        if allow_multiple:
                            index[i] = [value_func(o, *value_func_args)]
                        else:
                            index[i] = value_func(o, *value_func_args)
                    else:
                        if allow_multiple:
                            index[i].append(value_func(o, *value_func_args))
                        else:
                            Oligo.Prot.warn('Duplicate occured while allow_multiple=False in Oligo.locus.generate_index (i=%s). Duplicate value was dropped.' % i,'Duplicate dropped')
        super(Index, self).__init__(index)
        
    def get_value(self, i):
        try:
            self[i]
        except:
            return None
        return self[i]
        
#class LayerIndex(dict):
#
#    def __init__(self, objects, index_funcs, index_func_args=None, value_func=None, value_func_args=(), ignore_none_index=True, allow_multiple=True, verbose=1):
#        self.index = 
#    
#    def get_value(self, i):
#        return self.index.get_value(i[1:0])