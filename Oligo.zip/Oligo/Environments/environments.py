import Oligo
from math import sqrt
import numpy as np

class Environment(dict):
    
    def __init__(self, bins=None, name=None, resolution=None, unit=None):
        if bins is None:
            bins = {}
        super(Environment, self).__init__(bins)
        self.name = name
        self.resolution = resolution
        self.unit = unit
    
    @classmethod
    def identify_distance_column(cls, dataset):
        distance_column_names = ['distance','Distance','distance','Distance','3D distance','3D Distance','dist','3D dist']
        for column_name in distance_column_names:
            try:
                dataset[column_name]
            except:
                continue
            else:
                return column_name
        for column_name in distance_column_names:
            for key in dataset.keys():
                if key.split(' ')[0] == column_name:
                    return key
        return -1
    
    @classmethod
    def identify_unit(cls, distance_column_name):
        s = distance_column_name.split(' ')
        if len(s) > 1:
            return s[1]
        return None
    
    @classmethod
    def read(cls, input_filename, value_column_name, error_column_name=None, std_column_name=None, n_column_name=None, name=None, distance_column_name=None, resolution=None):
        Oligo.Prot.write('Reading Environment from %s.' % input_filename)
        if name is None:
            name = input_filename.split('/')[-1]
        data = Oligo.File.read_dat_lines(input_filename, verbose=0)
        if distance_column_name is None:
            distance_column_name = cls.dentify_distance_column(data[0])
            if distance_column_name == -1:
                Oligo.Prot.error('Could not identify distance column while reading environment from %s.' % input_filename)
        unit = cls.identify_unit(distance_column_name)
        if resolution is None:
            if data:
                resolution = abs(float(data[1][distance_column_name])-float(data[0][distance_column_name]))
        bins = {}
        for d in data:
            dist = float(d[distance_column_name])
            if error_column_name is not None:
                err = float(d[error_column_name])
            elif std_column_name is not None:
                if n_column_name is not None:
                    n = float(d[n_column_name])
                    if n > 0:
                        err = float(d[std_column_name])/sqrt(n)
                    else:
                        err = 0
                else:
                    err = float(d[std_column_name])
            bin = Oligo.Bin(count=float(d[value_column_name]), start=dist, end=dist+resolution, std=err)
            bins[dist] = bin
        Oligo.Prot.write('Read Environment with %s entries.' % len(bins.keys()))
        return Environment(bins, name, resolution, unit)
        
    def get_distances(self):
        return list(self.keys())
    
    def get_values(self):
        return list([self[key].count for key in self])
       
    def get_errors(self):
        return list([self[key].std for key in self])
       
    def get_max(self, min_dist=None, max_dist=None):
        max_value = None
        max_value_dists = []
        for dist in self.keys():
            bin = self[dist]
            value = bin.count
            if (min_dist is None or dist >= min_dist) and (max_dist is None or dist <= max_dist):
                if (max_value is None) or max_value < value:
                    max_value = value
                    max_value_dists = [dist]
                elif max_value == value:
                    max_value_dists.append(dist)
        return max_value, max_value_dists
        
    def get_min(self, min_dist=None, max_dist=None):
        min_value = None
        min_value_dists = []
        for dist in self.keys():
            bin = self[dist]
            value = bin.count
            if (min_dist is None or dist >= min_dist) and (max_dist is None or dist <= max_dist):
                if (min_value is None) or min_value > value:
                    min_value = value
                    min_value_dists = [dist]
                elif main_value == value:
                    min_value_dists.append(dist)
        return min_value, min_value_dists
    
    def get_stats(self, min_dist=None, max_dist=None):
        values = []
        for dist in self.keys():
            bin = self[dist]
            value = bin.count
            if (min_dist is None or dist >= min_dist) and (max_dist is None or dist <= max_dist):
                values.append(value)
        return np.mean(values), np.std(values)
    
    def modify(self, func, para=(), err_func=None, err_para=(), name=None, unit=None, min_dist=None, max_dist=None):
        bins = {}
        if name is None:
            name = '%s*' % (self.name)
        for dist in self.keys():
            if (min_dist is None or dist >= min_dist) and (max_dist is None or dist <= max_dist):
                v1 = self[dist].count
                e1 = self[dist].std
                if err_func is not None:
                    err = err_func(v1, e1, *err_para)
                else:
                    err = None
                bin = Oligo.Bin(count=func(v1, e1, *para), start=dist, end=dist+self.resolution, std=err)
                bins[dist] = bin
        return Environment(bins, name, self.resolution, unit)
    
    def derive_baseline(self, far_distance):
        mean,std = self.get_stats(min_dist=far_distance)
        return mean, std
        
    def normalize_to_baseline(self, baseline=None, baseline_error=None, far_distance=None):
        if far_distance is not None:
            baseline, baseline_error = self.derive_baseline(far_distance)
        return self.modify(func =  lambda v,e : v-baseline, err_func = lambda v,e : sqrt((e)**2+(baseline_error)**2), name='%s normalized' % self.name, unit=self.unit)
    
    def combine(self, environment, func, para=(), err_func=None, err_para=(), name=None, unit=None, min_dist=None, max_dist=None):
        bins = {}
        if name is None:
            name = '%s + %s' % (self.name, environment.name)
        if self.resolution != environment.resolution:
            Oligo.Prot.warn('Trying to combine environments (%s and %s) with different resolutions (%s, %s)' % (self.name, environment.name, self.resolution, environment.resolution))
        for dist in self.keys():
            if (min_dist is None or dist >= min_dist) and (max_dist is None or dist <= max_dist):
                v1 = self[dist].count
                v2 = environment[dist].count
                e1 = self[dist].std
                e2 = environment[dist].std
                if err_func is not None:
                    err = err_func(v1, v2, e1, e2, *err_para)
                else:
                    err = None
                bin = Oligo.Bin(count=func(v1, v2, e1, e2, *para), start=dist, end=dist+self.resolution, std=err)
                bins[dist] = bin
        return Environment(bins, name, self.resolution, unit)
    
    @classmethod
    def mean(cls, environments, name=None, unit=None, min_dist=None, max_dist=None):
        bins = {}
        if name is None:
            name = 'mean(%s)' % (','.join([env.name for env in environments]))
        resolutions = list(set([env.resolution for env in environments]))
        if len(resolutions) > 1:
            Oligo.Prot.warn('Trying to derive mean from environments with differenc resolutions (%s).' % resolutions)
        distances = []
        for env in environments:
            distances += env.get_distances()
        distances = sorted(list(set(distances)))
        for dist in distances:
            if (min_dist is None or dist >= min_dist) and (max_dist is None or dist <= max_dist):
                vi = []
                for env in environments:
                    try:
                        env[dist]
                    except:
                        pass
                        #Oligo.Prot.warn('Could not find distance %s in environment %s. Environment will not be considered for mean value of this distance.' % (dist, env.name))
                    else:
                        vi.append(env[dist].count)
                bin = Oligo.Bin(count=np.mean(vi), start=dist, end=dist+resolutions[0], std=np.std(vi)/np.sqrt(len(vi)))
                bins[dist] = bin
        return Environment(bins, name, resolutions[0], unit)
        
        
    def difference(self, environment, min_dist=None, max_dist=None):
        return self.combine(environment, func=lambda v1,v2,e1,e2 : v1-v2, err_func=lambda v1,v2,e1,e2 : sqrt(e1**2+e2**2), name='%s - %s' % (self.name, environment.name), min_dist=min_dist, max_dist=max_dist, unit=self.unit)
    
    def add(self, environment, min_dist=None, max_dist=None):
        return self.combine(environment, func=lambda v1,v2,e1,e2 : v1+v2, err_func=lambda v1,v2,e1,e2 : sqrt(e1**2+e2**2), name='%s + %s' % (self.name, environment.name), min_dist=min_dist, max_dist=max_dist, unit=self.unit)
    
    def save(self, output_filename):
        data = []
        for dist in self.keys():
            if self.unit is not None:
                d = {'distance %s' % self.unit:dist}
            else:
                d = {'distance':dist}
            d['value'] = self[dist].count
            d['error'] = self[dist].std
            data.append(d)
        Oligo.File.save_dat_lines(data=data, output_filename=output_filename)
        
    def call_peaks(self, min_dist=None, max_dist=None):
        peaks = []
        left_peak_bound = None
        peak_height = None
        peak_height_err = None
        max_height_dist = None
        for dist in self.keys():
            if dist < min_dist or dist > max_dist:
                continue
            v, e = self[dist].count, self[dist].std
            if abs(v) > e:
                if left_peak_bound is None:
                    peak_height = v
                    peak_height_err = e
                    left_peak_bound = dist
                    max_height_dist = dist
                elif v*peak_height > 0:
                    if v > peak_height:
                        peak_height = v
                        peak_height_err = e
                        max_height_dist = dist
                else:
                    peak = Peak(max_height_dist, peak_height, peak_height_err, left_width=max_height_dist-left_peak_bound, right_width=dist-max_height_dist)
                    peaks.append(peak)
                    left_peak_bound = dist
                    peak_height = v
                    peak_height_err = e
                    max_height_dist = dist
            elif left_peak_bound is not None:
                peak = Peak(max_height_dist, peak_height, peak_height_err, left_width=max_height_dist-left_peak_bound, right_width=dist-max_height_dist)
                peaks.append(peak)
                left_peak_bound = None
                peak_height = None
                peak_height_err = None
                max_height_dist = None
        if left_peak_bound is not None:
            peak = Peak(max_height_dist, peak_height, peak_height_err, left_width=max_height_dist-left_peak_bound, right_width=dist-max_height_dist)
            peaks.append(peak)
        return peaks
            
class Peak(object):
    
    def __init__(self, position, height, height_error, left_width, right_width):
        self.position = position
        self.height = height
        self.height_error = height_error
        self.left_width = left_width
        self.right_width = right_width
        
    def __repr__(self):
        return '<Oligo.Environments.Environment:Posi:%s|width:%s|height:%s(%s)>' % (self.position, self.get_width(), self.height, self.height_error)
        
    def get_width(self):
        return self.left_width+self.right_width
        
    def get_boundaries(self):
        return (self.position-self.left_width, self.position+self.right_width)
        
    @classmethod
    def save(cls, output_filename):
        data = []
        for peak in peaks:
            d = {'position':peak.position, 'height':peak.height, 'height error':peak.height_err, 'left width':peak.left_width, 'right_width':peak.right_width, 'width':peak.get_width()}
            data.append(d)
        Oligo.File.save_dat_lines(data=data, output_filename=output_filename)
        
    @classmethod
    def read(input_filename):
        data = Oligo.File.read_dat_lines('input_filename')
        peaks = []
        for d in data:
            peak = Peak(float(d['position']), float(d['height']), float(d['height error']), float(d['left width']), float(d['right width']))
    
    
            
                    
                    
                