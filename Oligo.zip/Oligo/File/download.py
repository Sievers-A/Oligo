import Oligo
from time import sleep
from Bio import Entrez, SeqIO
from Oligo import Prot
from . import file, genbank

EMAIL = 'Fechterschnecke@web.de'

def download_genbank(seq_id, filename=None, seqs_filenames=None, path='', labels=None, verbose=1):
    if verbose:
        Prot.write('Downloading sequence for ID=%s from NCBI.' % seq_id)
    if labels is None:
        labels = []
    if seqs_filenames is None:
        seqs_filenames = ['default.seqs']
    Entrez.email = EMAIL
    handle = Entrez.efetch(db='nuccore', id=seq_id, rettype='gbwithparts', retmode='full')
    text = handle.read()
    if filename is None:
        filename = path+Oligo.File.generate_temp_name('.gb')
    filename = Oligo.File.translate_output_filename(filename)
    if verbose:
        Prot.write('Saving data (%s chars) to %s.' % (len(text), filename))
    if not Oligo.File.check_path_exists(filename):
        pass
    text_file = open(filename, 'w')
    text_file.write(text)
    text_file.close()
    del text
    if seqs_filenames:
        meta = Oligo.File.read_genbank_meta(filename, verbose=0)
        if meta['name'] != '?':
            new_filename = meta['orga']+'_'+meta['name']
        else:
            new_filename = meta['orga']
        new_filename = new_filename.replace('/', '_')
        new_filename = new_filename.replace('?', '_')
        new_filename = new_filename.replace(':', '_')
        meta['orga'] = meta['orga'].replace('/', '_')
        meta['orga'] = meta['orga'].replace('?', '_')
        meta['orga'] = meta['orga'].replace(':', '_')
        new_filename = path+new_filename+'.gb'
        read_filename = Oligo.File.translate_output_filename(new_filename)
        if not file.check_file_exists(read_filename):
            file.rename_file(filename, read_filename)
        else:
            Prot.warn('Could not rename %s to %s in download.download_genbank(), because filename %s already exists.' % (filename, read_filename, read_filename),'already exists')
        for seq_filename in seqs_filenames:
            Oligo.File.add_genbank_to_seqs_file(seq_filename, id=meta['id'], name=meta['name'], organism=meta['orga'], topology=meta['topology'], length=meta['length'], file=new_filename, labels=[meta['molecule']]+labels)

def download_genbanks(seq_ids, seqs_filename='default.seqs', seqs_filenames=None, path='', labels=None, verbose=1):
    if verbose:
        Prot.write('Downloading %s sequences from NCBI.' % len(seq_ids))
    if seqs_filenames is None:
        seqs_filenames = []
    if seqs_filename is not None:
        seqs_filenames.append(seqs_filename)
    for seq_id in seq_ids:
        download_genbank(seq_id, filename=None, seqs_filenames=seqs_filenames, path=path, labels=labels, verbose=verbose)

def download_chromo(chromo, filename=None, seqs_filenames=[], path='', labels=None, verbose=1):
    if verbose:
        Prot.write('Downloading %s from NCBI.' % str(chromo))
    if filename is None:
        filename = file.add_data_filepath(str(chromo+'.gb'))
    download_genbank(chromo.id, filename, seqs_filenames, path, labels)

def download_genome(genome=None, orga=None, seqs_filenames=[], path='', labels=None):
    if genome is None:
        genome = file.read_genome(orga)
    for chromo in genome:
        download_chromo(chromo, seqs_filenames=seqs_filenames, path=path, labels=labels)
