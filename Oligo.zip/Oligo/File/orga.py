import pandas
import Oligo
from Oligo import Prot

def query_seqs_file(input_filename, translator_func=None, translator_func_args=(), filter_func=None, filter_func_args=()): 
    try:
        data = pandas.read_csv(input_filename, sep='\t')
    except pandas.errors.EmptyDataError:
        return []
    ret = []
    for i in data.index:
        if translator_func is None:
            x = data.loc[i]
        else:
            x = translator_func(data.loc[i], *translator_func_args)
        if filter_func is None or filter_func(x, *filter_func_args):
            ret.append(x)
    return ret
         
  
def translate_chromosome(row):
    chromo = Oligo.Orga.Chromosome(row['name'], Oligo.Orga.Organism(row['organism']), row['topology'], row['length'], row['file'], labels=row['labels'].split(','), id=row['id'])
    return chromo
  
def genome_filter(chromo, orga):
    return 'Genome' in chromo.labels and chromo.orga == orga
  
def name_filter(chromo, name):
    return str(chromo) == name
  
def read_all_seqs(seqs_filename=None):
    if seqs_filename is None:
        seqs_filename = Oligo.Data.get_default_seqs_filename()
    seqs_filename = Oligo.File.search(seqs_filename)
    seqs = query_seqs_file(seqs_filename, translator_func=translate_chromosome)
    return seqs
  
def read_all_orgas(seqs_filename=None):
    if seqs_filename is None:
        seqs_filename = Oligo.Data.get_default_seqs_filename()
    seqs_filename = Oligo.File.search(seqs_filename)
    orga_names = []
    d = query_seqs_file(seqs_filename, translator_func=lambda d: d['organism'])
    for name in d:
        if name not in orga_names:
            orga_names.append(name)
    return [Oligo.Orga.Organism(orga_name) for orga_name in orga_names]
    
def read_all_genomes(seqs_filename=None, verbose=1):
    if verbose:
        Oligo.Prot.write('Reading Genomes from %s.' % seqs_filename)
    if seqs_filename is None:
        seqs_filename = Oligo.Data.get_default_seqs_filename()
    seqs_filename = Oligo.File.search(seqs_filename)
    orgas = read_all_orgas(seqs_filename)
    genomes = [read_genome(orga.name, seqs_filename=seqs_filename) for orga in orgas]
    if verbose:
        Oligo.Prot.write('Found %s Genomes.' % (len(genomes)))
    return genomes
  
def read_human_genome(seqs_filename=None, verbose=1):
    return read_genome('Homo sapiens', seqs_filename=seqs_filename, verbose=verbose)
  
def read_mouse_genome(seqs_filename=None, verbose=1):
    return read_genome('Mus musculus', seqs_filename=seqs_filename, verbose=verbose)
  
def read_genome(orga_name, seqs_filename=None, verbose=1):
    if verbose:
        Prot.write('Reading Genome for %s.' % orga_name)
    if seqs_filename is None:
        seqs_filename = Oligo.Data.get_default_seqs_filename()
    seqs_filename = Oligo.File.search(seqs_filename)
    orga = Oligo.Orga.Organism(orga_name)
    chromosomes = query_seqs_file(seqs_filename, translator_func=translate_chromosome, filter_func=genome_filter, filter_func_args=(orga,))
    if not chromosomes:
        Oligo.Prot.warn('No Seqeuences found for Genome of %s in %s.' % (orga_name, seqs_filename),'')
    genome = Oligo.Orga.Genome(orga, chromosomes)
    if verbose:
        Prot.write('Found %s Chromosomes (%s).' % (len(genome), ','.join([c.name for c in genome][0:50])))
    return genome
    
def read_chromosome(chromo_name, seqs_filename=None, verbose=1):
    if seqs_filename is None:
        seqs_filename = Oligo.Data.get_default_seqs_filename()
    seqs_filename = Oligo.File.search(seqs_filename)
    orga_name = ' '.join(chromo_name.split(' ')[0:-1])
    orga = Oligo.Orga.Organism(orga_name)
    chromosomes = query_seqs_file(seqs_filename, translator_func=translate_chromosome, translator_func_args=(), filter_func=name_filter, filter_func_args=(chromo_name,))
    if not chromosomes:
        Oligo.Prot.warn('No Chromosome found with name %s found in %s.' % (chromo_name, seqs_filename), 'Empty Seqs File Query')
        return None
    return chromosomes[0]
    
def save_as_seqs_file(output_filename, seqs, verbose=1):
    if verbose:
        Prot.write('Saving %s seqs to seqs-file %s.' % (len(seqs),output_filename))
    if not seqs:
        Prot.warn('No seqs found, to add to sequence file in File.orga.save_as_seqs_file. File was not changed.','No Data')
        return
    f = open(output_filename, 'w')
    f.write('id\tname\torganism\ttopology\tlength\tfile\tlabels\n')
    n = 0
    for chromo in seqs:
        f.write('\t'.join([chromo.id, str(chromo.name), str(chromo.orga), str(chromo.topology), str(chromo.length), str(chromo.filename), ','.join(chromo.labels)])+'\n')
    f.close()
    if verbose:
        Prot.write('Saved %s sequences in %s.' % (len(seqs), output_filename))
    
def add_genbank_to_seqs_file(seqs_filename, id, name, organism, topology, length, file, labels, verbose=1):
    if verbose:
        Prot.write('Adding Data (id=%s/orga=%s/name=%s) to seqs-file: %s.' % (id, organism, name, seqs_filename))
    if Oligo.File.check_file_exists(seqs_filename):
        seqs = read_all_seqs(seqs_filename)
    else:
        seqs = []
    new_seq = Oligo.Orga.Chromosome(name, Oligo.Orga.Organism(str(organism)), topology=topology, length=length, filename=file, seq=None, labels=labels, id=id)
    seqs.append(new_seq)
    save_as_seqs_file(Oligo.File.search(seqs_filename), seqs)
    
    