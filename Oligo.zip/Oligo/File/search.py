def add_filepath(input_filename):
    return input_filename

def add_output_filepath(output_filename):
    return output_filename
    
def add_data_filepath(output_filename):
    return output_filename