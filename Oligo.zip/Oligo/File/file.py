import Oligo
from Oligo import Prot
from os import path, rename, remove, listdir, makedirs
from shutil import move
import random

def add_data_filepath(filepath):
    p = Oligo.Data.data_paths[0]
    return p+'/'+filepath

def check_file_exists(filename):
    return path.exists(filename)

def check_files_exist(filenames):
    for filename in filenames:
        if not check_file_exists(filename):
            return False
    return True

def get_everything_in_dir(dir):
    return listdir(dir)

def check_path_exists(filename):
    p = '/'.join(filename.split('/')[:-1])
    return path.exists(p)

def create_folder(folder):
    if not path.exists(folder):
        makedirs(folder)

def search(filename):
    filepath = get_absolute_path(filename)
    if check_file_exists(filepath):
        return filepath
    for path in Oligo.Data.data_paths:
        filepath = get_absolute_path(path+'/'+filename)
        if check_file_exists(filepath):
            return filepath
    filepath = get_absolute_path(Oligo.Data.results_path+'/'+filename)
    if check_file_exists(filepath):
        return filepath
    return filename

def translate_input_filename(filename):
    return search(filename)

def translate_output_filename(filename):
    filepath = get_absolute_path(filename)
    if check_path_exists(filepath):
        return filepath
    return filename

def translate_output_path(output_path):
    abs_output_path = get_absolute_path(output_path)
    if check_file_exists(abs_output_path):
        return abs_output_path+'/'
    return output_path+'/'

def rename_file(original_filename, new_filename=None, func=None, func_args=(), verbose=1):
    if new_filename is None:
        new_filename = func(original_filename, *func_args)
    if verbose:
        Prot.write('Renaming file %s to %s.' % (original_filename, new_filename))
    rename(original_filename, new_filename)

def move_file(filename, new_path, verbose=1):
    if verbose:
        Prot.write('Moving file %s to %s.' % (filename, new_path))
    move(filename, new_path)
    
def delete_file(filename, ignore_exist=False, verbose=1):
    if verbose:
        Prot.write('Deleting file %s.' % filename)
    if not ignore_exist or check_file_exists(filename):
        remove(filename)

def get_fileextension(filename):
    s = filename.split('.')
    if len(s) > 1:
        return s[-1]
    else:
        return None

def write_head(file, head):
    for key, value in head.items():
        file.write('#'+str(key)+':\t'+str(value)+'\n')

def read_head(input_filename, include_comments=False):
    head_data = {}
    head_rows = 0
    f = open(input_filename,'r')
    for line in f:
        line = line.rstrip()
        if line != '' and line[0] != '#' and line[0] != '$':
            break
        elif line[0] == '$' or include_comments:
            t = line.split('\t')
            key = t[0][1:-1]
            if len(t) > 1:
                value = t[1]
            else:
                value = None
            head_data[key] = value
        head_rows += 1
    f.close()
    return head_data, head_rows

def generate_random_filename(ending='.txt', length=30):
    name = ''
    for i in range(length):
        name += random.choice("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890")
    return name+ending

def generate_temp_name(ending, length=30):
    create_folder('temp')
    filename = 'temp/'+generate_random_filename(ending, length)
    #filename = get_absolute_path(filename)
    while check_file_exists(filename):
        filename = 'temp/'+generate_random_filename(ending)
    return filename

def get_absolute_path(relative_filepath):
    dirname = path.dirname(path.dirname(path.dirname(__file__)))
    return path.join(dirname, relative_filepath)

def save_dat(output_filename, data, head=None, delim='\t'):
    file = open(output_filename,'w')
    if head is not None:
        write_head(file, head)
    file.write(delim.join([str(key) for key in data.keys()])+'\n')
    key = list(data.keys())[0]
    for i in range(len(data[key])):
        file.write(delim.join([str(data[key][i]) for key in data.keys()])+'\n')
    file.close()

def read_dat_lines(input_filename, delim='\t', col_names=None, verbose=1):
    if verbose:
        Prot.write('Reading data from %s.' % input_filename)
    head_data, n_rows = read_head(input_filename)
    f = open(input_filename,'r')
    i = 0
    data = []
    for line in f:
        if line[0] not in ['#','$']:
            words = line.rstrip().split(delim)
            if col_names is None and i == n_rows:
                col_names = words
            else:
                data.append({col_name:word for col_name,word in zip(col_names, words)})
                #print data[-1]
                #raise
        i += 1
    if verbose:
        Prot.write('Read %s lines of data.' % len(data))
    return data

def save_dat_lines(output_filename, data, head=None, delim='\t', keys=None, verbose=1):
    if verbose:
        Prot.write('Saving data (%s line) to %s.' % (len(data), output_filename))
    file = open(output_filename,'w')
    if head is not None:
        write_head(file, head)
    if keys is None:
        keys = data[0].keys()
    file.write(delim.join([str(x) for x in keys])+'\n')
    for line in data:
        file.write(delim.join([str(line[key]) for key in keys])+'\n')
    file.close()

def save_dat_lines_as_html_table(output_filename, data, keys=None, color_func=None, color_func_args=(), verbose=1):
    if verbose:
        Prot.write('Saving data (%s line) to %s.' % (len(data), output_filename))
    file = open(output_filename,'w')
    file.write('<table>\n')
    if keys is None:
        keys = data[0].keys()
    file.write('\t<tr>\n')
    for key in keys:
        file.write('\t\t<td>%s</td>\n' % key)
    file.write('\t</tr>\n')
    for line in data:
        file.write('\t<tr>\n')
        for key in keys:
            if color_func is None:
                #print(line[key])
                file.write('\t\t<td>%s</td>\n' % (line[key]))
            else:
                color = color_func(key, line[key], line, *color_func_args)
                if color is not None:
                    file.write('\t\t<td style="background-color:rgb(%s,%s,%s)">%s</td>\n' % (color[0], color[1], color[2], line[key]))
                else:
                    file.write('\t\t<td>%s</td>\n' % line[key])
        file.write('\t</tr>\n')
    file.close()
    
def convert_dat_lines_to_html(input_filename, output_filename, keys=None, color_func=None, color_func_args=(), round_numbers=3, verbose=1):
    if verbose:
        Prot.write('Converting %s HTML-Table.' % (input_filename))
    data = read_dat_lines(input_filename)
    if round_numbers is not None:
        for d in data:
            for k in d.keys():
                if check_number_string(d[k]) == 1:
                    try:
                        d[k] = round(float(d[k]),round_numbers)
                    except:
                        Prot.warn('Could not interpret %s properly in File.convert_dat_lines_to_html' % d[k])
    save_dat_lines_as_html_table(output_filename, data, keys=keys, color_func=color_func, color_func_args=color_func_args)
   
def check_number_string(a):
    if a[0] == '-':
        a = a[1:]
    if a.isdigit():
       return 0 # integer
    elif a.replace('.','',1).isdigit() and a.count('.') < 2:
       return 1 # float
    else:
       return None # no number

def read_dat(input_filename, delim='\t', column_names=None):
    head_data, n_rows = read_head(input_filename)
    data = {}
    if column_names is not None:
        data = {col_name:[] for col_name in column_names}
    i = 0
    f = open(input_filename,'r')
    for line in f:
        if line[0] not in ['#','$']:
            words = line.rstrip().split(delim)
            if i == n_rows and column_names is None:
                column_names = words[:]
                for word in words:
                    data[word] = []
            else:
                for word,name in zip(words, column_names):
                    data[name].append(word)
        i += 1
    f.close()
    return data
    
    
def append_to_file(filename, text, create_if_not_existing=True, head_string=None, verbose=0):
    if create_if_not_existing and not check_file_exists(filename):
        if verbose:
            Prot.write('Creating %s.' % filename)
        f = open(filename,'w')
        if head_string is not None:
            f.write(head_string)
        f.close()
    if verbose:
        Prot.write('Appending %s[...] to %s.' % (text[0:10], filename))
    f = open(filename, 'a')
    f.write(text)
    f.close()
