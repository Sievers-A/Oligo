import Oligo
from .file import get_fileextension
from .genbank import genbank_extensions

bed_extensions = ['bed','BED']
    
    
def read_locus_type(input_filename, type):
    ext = get_fileextension(input_filename)
    if type == 'loci':
        if ext in bed_extensions:
            loci = Oligo.Locus.read_bed(input_filename)
        else:    
            loci = Oligo.Locus.read(input_filename)
    elif type == 'genes':
        if ext == 'loci':
            loci = Oligo.Gene.read(input_filename)
        elif ext in genbank_extensions:
            loci = Oligo.File.genbank.read_genes(input_filename) 
    elif type == 'npc_genes':
        if ext == 'loci':
            loci = Oligo.Gene.read(input_filename)
        elif ext in genbank_extensions:
            loci = Oligo.File.genbank.read_non_protein_coding_genes(input_filename)
    elif type == 'lncRNA':
        if ext == 'loci':
            loci = Oligo.Gene.read(input_filename)
        elif ext in genbank_extensions:
            loci = Oligo.File.genbank.read_lncRNAs(input_filename)
    elif type == 'miRNA':
        if ext == 'loci':
            loci = Oligo.Gene.read(input_filename)
        elif ext in genbank_extensions:
            loci = Oligo.File.genbank.read_miRNAs(input_filename)
    else:
        Oligo.Prot.error('Cannot read unknown Locus type "%s" for filename %s in File.locus.read_locus_type().' % (type, input_filename),'unknown type')
        raise
    return loci
