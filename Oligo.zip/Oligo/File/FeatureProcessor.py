import Oligo

class FeatureProcessor(object):

    def process_feature(self, feature, index, features):
        return None

    def check_feature_gene(self, feature):
        return feature.type == 'gene'

    def check_feature_centromere(self, feature):
        return feature.type == 'centromere'

    def check_feature_cds(self, feature):
        return feature.type == 'CDS'

    def check_feature_exon(self, feature):
        return feature.type == 'exon'

    def check_feature_mRNA(self, feature):
        return feature.type == 'mRNA'

    def check_feature_tRNA(self, feature):
        return feature.type == 'tRNA'

    def check_feature_rRNA(self, feature):
        return feature.type == 'rRNA'

    def check_feature_gap(self, feature):
        return feature.type == 'assembly_gap'

    def check_feature_precursor_RNA(self, feature):
        return feature.type == 'precursor_RNA'

    def check_feature_ncRNA(self, feature):
        return feature.type == 'ncRNA'

    def check_feature_lncRNA(self, feature):
        #print feature.type
        if not feature.type == 'ncRNA':
            return False
        #print feature,feature.qualifiers
        try:
            feature.qualifiers['ncRNA_class']
        except:
            return False
        else:
            return 'lncRNA' in feature.qualifiers['ncRNA_class']


    def check_feature_miRNA(self, feature):
        if not feature.type == 'ncRNA':
            return False
        try:
            feature.qualifiers['ncRNA_class']
        except:
            return False
        else:
            return 'miRNA' in feature.qualifiers['ncRNA_class']

    def check_feature_snoRNA(self, feature):
        if not feature.type == 'ncRNA':
            return False
        try:
            feature.qualifiers['ncRNA_class']
        except:
            return False
        else:
            return 'snoRNA' in feature.qualifiers['ncRNA_class']
            
    def check_feature_snRNA(self, feature):
        if not feature.type == 'ncRNA':
            return False
        try:
            feature.qualifiers['ncRNA_class']
        except:
            return False
        else:
            return 'snRNA' in feature.qualifiers['ncRNA_class']

    def check_feature_pseudo(self, feature):
        try:
            feature.qualifiers
        except:
            return False
        try:
           feature.qualifiers['pseudo']
        except:
            return False
        return True


    def get_feature_loci(self, feature):
        try:
            feature.location
        except:
            return []
        try:
            feature.location.parts
        except:
            return [Oligo.Locus(start=int(feature.location.start), end=int(feature.location.end), strand=feature.location.strand)]
        else:
            return [Oligo.Locus(start=int(part.start), end=int(part.end), strand=part.strand) for part in feature.location.parts]
        return []

    def get_child_features(self, feature, index, features, filter_func=None, filter_func_args=()):
        #print '-----------------------------------------'
        #print feature
        feature_loci = self.get_feature_loci(feature)
        #print feature_loci
        child_features = []
        i = 1
        while index+i < len(features):
            current_feature = features[index+i]
            current_feature_loci = self.get_feature_loci(current_feature)
            #print current_feature_loci, Oligo.Loci.check_overlaps(feature_loci, current_feature_loci)
            if Oligo.Loci.check_overlaps(feature_loci, current_feature_loci):
                if filter_func is None or filter_func(current_feature, index+i, features, *filter_func_args):
                   child_features.append(current_feature)
            else:
                break
            i += 1
        #print '-----------------------------------------'
        return child_features

    def check_feature_has_gene_id(self, feature, gene_id):
        return gene_id == self.get_feature_gene_id(feature)

    def get_feature_gene_id(self, feature):
        try:
            feature.qualifiers
        except:
            return None
        try:
            feature.qualifiers['GeneID']
        except:
            return None
        return feature.qualifiers['GeneID']

    def check_feature_types(self, feature, types):
        return feature.type in types

    def check_feature_protein_coding(self, feature, index, features):
        child_features = self.get_child_features(feature, index, features, filter_func=lambda f,i,fs: FeatureProcessor.check_feature_cds(self,f) or FeatureProcessor.check_feature_mRNA(self,f))
        return bool(child_features)

    def check_feature_non_protein_coding(self, feature, index, features):
        child_features = self.get_child_features(feature, index, features, filter_func=lambda f,i,fs: FeatureProcessor.check_feature_cds(self,f) or FeatureProcessor.check_feature_mRNA(self,f))
        return not bool(child_features)

    def check_feature_non_coding_RNA(self, feature, index, features):
        child_features = self.get_child_features(feature, index, features, filter_func=lambda f,i,fs: FeatureProcessor.check_feature_tRNA(self,f) or FeatureProcessor.check_feature_rRNA(self,f) or FeatureProcessor.check_feature_precursor_RNA(self,f) or FeatureProcessor.check_feature_ncRNA(self,f))
        return bool(child_features)

    def check_feature_long_non_coding_RNA(self, feature, index, features):
        child_features = self.get_child_features(feature, index, features, filter_func=lambda f,i,fs: FeatureProcessor.check_feature_lncRNA(self,f))

        return bool(child_features)
        #return self.check_feature_lncRNA(feature)

    def check_feature_micro_RNA(self, feature, index, features):
        #print feature
        child_features = self.get_child_features(feature, index, features, filter_func=lambda f,i,fs: FeatureProcessor.check_feature_miRNA(self,f))
        #print [f.qualifiers['ncRNA_class'] for f in child_features]
        return bool(child_features)
        #return self.check_feature_miRNA(feature)

    def get_gene_name(self, feature):
        try:
            feature.qualifiers['locus_tag'][0]
        except:
            try:
                feature.qualifiers['gene'][0]
            except:
                return None
            return feature.qualifiers['gene'][0]
        return feature.qualifiers['locus_tag'][0]

    def get_gene_id(self, feature):
        try:
            feature.qualifiers['db_xref']
        except:
            try:
                feature.qualifiers['gene'][0]
            except:
                return None
            return feature.qualifiers['gene'][0]
        else:
            for quali in feature.qualifiers['db_xref']:
                if quali[0:6] == 'GeneID':
                    return quali[7:]
            return feature.qualifiers['db_xref'][0]
            
    def get_alt_names(self, feature):
        try:
            feature.qualifiers['gene_synonym'][0]
        except:
            return []
        return feature.qualifiers['gene_synonym'][0].split('; ')

    def filter(self, feature, index, features):
        return True

    def feature_filters(self, feature, index, features):
        return self.filter(feature, index, features)

    def process(self, features, filter_func=None, filter_args=()):
        results = []
        for i in range(len(features)):
            current_results = self.process_feature(features[i], i, features)
            for locus in current_results:
                if filter_func is None or filter_func(locus, *filter_args):
                    results.append(locus)
        return results

    def get_parts(self, feature):
        try:
            parts = feature.location.parts
        except:
            parts = [feature.location]
        return parts


class GeneFeatureProcessor(FeatureProcessor):

    def __init__(self, target=None, filter=None, filter_args=(), add_exons=False, add_introns=False, add_cds=False, add_mRNA=False, add_ncRNA=False, add_lncRNA=False, add_miRNA=False, add_tRNA=False, add_rRNA=False, add_precursor_RNA=False, add_snoRNA=False, add_snRNA=False, add_alt_names=False):
        self.target = target
        if filter is not None:
            self.filter = filter
        self.filter_args = filter_args
        self.add_exons = add_exons
        self.add_introns = add_introns
        self.add_cds = add_cds
        self.add_mRNA = add_mRNA
        self.add_ncRNA = add_ncRNA
        self.add_lncRNA = add_lncRNA
        self.add_miRNA = add_miRNA
        self.add_tRNA = add_tRNA
        self.add_rRNA = add_rRNA
        self.add_precursor_RNA = add_precursor_RNA
        self.add_snoRNA = add_snoRNA
        self.add_snRNA = add_snRNA
        self.add_alt_names = add_alt_names

    def create_exons(self, feature, index, features):
        cild_features = self.get_child_features(feature, index, features)
        exons = []
        for child_feature in cild_features:
            if self.check_feature_exon(child_feature):
                start = int(child_feature.location.start)
                end = int(child_feature.location.end)
                exons.append(Oligo.Locus(start, end=end, target=self.target))
        return exons

    def create_cds(self, feature, index, features):
        cild_features = self.get_child_features(feature, index, features)
        cds = []
        for child_feature in cild_features:
            if self.check_feature_cds(child_feature):
                parts = self.get_parts(child_feature)
                for part in parts:
                    start = int(part.start)
                    end = int(part.end)
                    #print start, end, child_feature
                    cds.append(Oligo.Locus(start, end=end, target=self.target))
        return cds

    def create_mRNA(self, feature, index, features):
        cild_features = self.get_child_features(feature, index, features)
        mRNAs = []
        for child_feature in cild_features:
            if self.check_feature_mRNA(child_feature):
                parts = self.get_parts(child_feature)
                for part in parts:
                    parts = self.get_parts(child_feature)
                    for part in parts:
                        start = int(part.start)
                        end = int(part.end)
                        mRNAs.append(Oligo.Locus(start, end=end, target=self.target))
        return mRNAs

    def create_ncRNAs(self, feature, index, features):
        cild_features = self.get_child_features(feature, index, features)
        ncRNAs = []
        lncRNAs = []
        miRNAs = []
        tRNAs = []
        rRNAs = []
        precursor_RNAs = []
        snoRNAs = []
        snRNAs = []
        for child_feature in cild_features:
            if self.check_feature_ncRNA(child_feature) or self.check_feature_tRNA(child_feature) or self.check_feature_rRNA(child_feature) or self.check_feature_precursor_RNA(child_feature):
                if self.add_lncRNA and self.check_feature_lncRNA(child_feature):
                    is_lncRNA = True
                else:
                    is_lncRNA = False
                if self.add_miRNA and self.check_feature_miRNA(child_feature):
                    is_miRNA = True
                else:
                    is_miRNA = False
                if self.add_tRNA and self.check_feature_tRNA(child_feature):
                    is_tRNA = True
                else:
                    is_tRNA = False
                if self.add_rRNA and self.check_feature_rRNA(child_feature):
                    is_rRNA = True
                else:
                    is_rRNA = False
                if self.add_precursor_RNA and self.check_feature_precursor_RNA(child_feature):
                    is_precursor_RNA = True
                else:
                    is_precursor_RNA = False
                if self.add_snoRNA and self.check_feature_snoRNA(child_feature):
                    is_snoRNA = True
                else:
                    is_snoRNA = False
                if self.add_snRNA and self.check_feature_snRNA(child_feature):
                    is_snRNA = True
                else:
                    is_snRNA = False
                parts = self.get_parts(child_feature)
                for part in parts:
                    parts = self.get_parts(child_feature)
                    for part in parts:
                        start = int(part.start)
                        end = int(part.end)
                        if self.add_ncRNA:
                            ncRNAs.append(Oligo.Locus(start, end=end, target=self.target))
                        if is_lncRNA and self.add_lncRNA:
                            lncRNAs.append(Oligo.Locus(start, end=end, target=self.target))
                        if is_miRNA and self.add_miRNA:
                            miRNAs.append(Oligo.Locus(start, end=end, target=self.target))
                        if is_tRNA and self.add_tRNA:
                            tRNAs.append(Oligo.Locus(start, end=end, target=self.target))
                        if is_rRNA and self.add_rRNA:
                            rRNAs.append(Oligo.Locus(start, end=end, target=self.target))
                        if is_precursor_RNA and self.add_precursor_RNA:
                            precursor_RNAs.append(Oligo.Locus(start, end=end, target=self.target))
                        if is_snoRNA and self.add_snoRNA:
                            snoRNAs.append(Oligo.Locus(start, end=end, target=self.target))
                        if is_snRNA and self.add_snRNA:
                            snRNAs.append(Oligo.Locus(start, end=end, target=self.target))
        return ncRNAs, lncRNAs, miRNAs, tRNAs, rRNAs, precursor_RNAs, snoRNAs, snRNAs

    def create_introns(self, exons, gene):
        if exons:
            introns = Oligo.Loci.invert(exons, (gene.start, gene.get_end()), verbose=0)
        else:
            introns = []
        for intron in introns:
            intron.strand = gene.strand
        return introns

    def process_feature(self, feature, index, features):
        genes = []
        if self.check_feature_gene(feature) and self.feature_filters(feature, index, features):
            gene_id = self.get_gene_id(feature)
            gene_name = self.get_gene_name(feature)
            parts = self.get_parts(feature)
            for part in parts:
                start = int(part.start)
                end = int(part.end)
                #start = int(feature.location.start)
                #end = int(feature.location.end)
                #print gene_id,gene_name
                if end < start:
                    start, end = end, start
                strand = feature.strand
                if strand == 1:
                    strand = '+'
                elif strand == -1:
                    strand = '-'
                else:
                    strand = None
                target = self.target
                gene = Oligo.Gene(id=gene_id, name=gene_name, start=start, end=end, strand=strand, target=self.target)
                if self.get_alt_names:
                    gene.alt_names = self.get_alt_names(feature)
                if self.add_exons:
                    gene.exons = self.create_exons(feature, index, features)
                else:
                    gene.exons = []
                if self.add_cds:
                    gene.cds = self.create_cds(feature, index, features)
                else:
                    gene.cds = []
                if self.add_mRNA:
                    gene.mRNA = self.create_mRNA(feature, index, features)
                else:
                    gene.mRNA = []
                if self.add_introns:
                    gene.introns = self.create_introns(gene.exons+gene.cds+gene.mRNA, gene)
                else:
                    gene.introns = []
                if self.add_ncRNA or self.add_lncRNA or self.add_miRNA or self.add_tRNA or self.add_rRNA or self.add_precursor_RNA or self.add_snoRNA or self.add_snRNA:
                    gene.ncRNAs, gene.lncRNAs, gene.miRNAs, gene.tRNAs, gene.rRNAs, gene.precursor_RNAs, gene.snoRNAs, gene.snRNAs = self.create_ncRNAs(feature, index, features)
                else:
                    gene.ncRNAs, gene.lncRNAs, gene.miRNAs, gene.tRNAs, gene.rRNAs, gene.precursor_RNAs, gene.snoRNAs, gene.snRNAs = [], [], [], [], [], [], [], []
                genes.append(gene)
            return genes
        return []

class ProteinCodingGeneFeatureProcessor(GeneFeatureProcessor):

    def feature_filters(self, feature, index, features):
        return super(ProteinCodingGeneFeatureProcessor, self).feature_filters(feature, index, features) and self.check_feature_protein_coding(feature, index, features)


class PseudoGeneFeatureProcessor(GeneFeatureProcessor):

    def feature_filters(self, feature, index, features):
        return super(PseudoGeneFeatureProcessor, self).feature_filters(feature, index, features) and self.check_feature_pseudo(feature)


class NonProteinCodingGeneFeatureProcessor(GeneFeatureProcessor):

    def feature_filters(self, feature, index, features):
        return super(NonProteinCodingGeneFeatureProcessor, self).feature_filters(feature, index, features) and self.check_feature_non_protein_coding(feature, index, features)


class RNAGeneFeatureProcessor(GeneFeatureProcessor):

    def feature_filters(self, feature, index, features):
        return super(RNAGeneFeatureProcessor, self).feature_filters(feature, index, features) and self.check_feature_non_coding_RNA(feature, index, features)

class LongNoneCodingRNAFeatureProcessor(GeneFeatureProcessor):

    def feature_filters(self, feature, index, features):
        return super(LongNoneCodingRNAFeatureProcessor, self).feature_filters(feature, index, features) and self.check_feature_long_non_coding_RNA(feature, index, features)

class MicroRNAFeatureProcessor(GeneFeatureProcessor):

    def feature_filters(self, feature, index, features):
        return super(MicroRNAFeatureProcessor, self).feature_filters(feature, index, features) and self.check_feature_micro_RNA(feature, index, features)

class GapFeatureProcessor(FeatureProcessor):

    def __init__(self, target=None, filter=None, filter_args=()):
        self.target = target
        if filter is not None:
            self.filter = filter
        self.filter_args = filter_args

    def process_feature(self, feature, index, features):
        gaps = []
        if self.check_feature_gap(feature) and self.feature_filters(feature, index, features):
            parts = self.get_parts(feature)
            for part in parts:
                start = int(part.start)
                end = int(part.end)
                target = self.target
                gap = Oligo.Locus(start=start, end=end, target=self.target)
                gaps.append(gap)
            return gaps
        return []
        
class CentromereFeatureProcessor(FeatureProcessor):

    def __init__(self, target=None, filter=None, filter_args=()):
        self.target = target
        if filter is not None:
            self.filter = filter
        self.filter_args = filter_args

    def process_feature(self, feature, index, features):
        centros = []
        if self.check_feature_centromere(feature) and self.feature_filters(feature, index, features):
            parts = self.get_parts(feature)
            for part in parts:
                start = int(part.start)
                end = int(part.end)
                target = self.target
                centro = Oligo.Locus(start=start, end=end, target=self.target)
                centros.append(centro)
            return centros
        return []
