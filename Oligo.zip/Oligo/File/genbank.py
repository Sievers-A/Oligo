from Bio import SeqIO
from Oligo.File import get_fileextension
from Oligo import Prot
from . import FeatureProcessor
import Oligo

fasta_extensions = ['fa','fasta']
fastq_extensions = ['fq','fastq']
genbank_extensions = ['gb','genbank','genebank']

def read_sequence_file(input_filename, input_filename_type=None, allow_multiple=False):
    if input_filename_type is None:
        ext = get_fileextension(input_filename)
        if ext in fasta_extensions:
            input_filename_type = 'fasta'
        elif ext in genbank_extensions:
            input_filename_type = 'genbank'
        elif ext in fastq_extensions:
            input_filename_type = 'fastq'
    data = []
    for record in SeqIO.parse(input_filename, input_filename_type):
        seq_id = record.id
        seq = record.seq
        data.append((seq_id, seq))
    if not allow_multiple:
        return data[0][0], data[0][1]
    return data

def read_all_features(input_filename):
    features = []
    for gb_record in SeqIO.parse(open(input_filename,'r'), 'genbank'):
        for gb_feature in gb_record.features:
            features.append(gb_feature)
    return features

def read_genbank_meta(input_filename, verbose=1):
    meta = {}
    if verbose:
        Prot.write('Reading Meta-Data from %s.' % input_filename)
    for record in SeqIO.parse(input_filename, 'genbank'):
        for feature in record.features:
            if feature.type == 'source':
                try:
                    feature.qualifiers['chromosome']
                except:
                    meta['name'] = '?'
                else:
                    meta['name'] = 'c'+str(feature.qualifiers['chromosome'][0])
                if meta['name'] == '?':
                    try:
                        feature.qualifiers['segment']
                    except:
                        meta['name'] = '?'
                    else:
                        meta['name'] = 's'+str(feature.qualifiers['segment'][0])
                if meta['name'] == '?':
                    try:
                        feature.qualifiers['organelle']
                    except:
                        meta['name'] = '?'
                    else:
                        if feature.qualifiers['organelle'][0] == 'mitochondrion':
                            meta['name'] = 'MT'
                        elif feature.qualifiers['organelle'][0] in ['plastid', 'plastid:chloroplast', 'chloroplast', 'chromatophore']:
                            meta['name'] = 'Pltd'
                        elif feature.qualifiers['organelle'][0] == 'plasmid':
                            meta['name'] = 'Plsm'
                        else:
                            meta['name'] = feature.qualifiers['organelle'][0]
                if meta['name'] == '?':
                    try:
                        feature.qualifiers['linkage_group']
                    except:
                        meta['name'] = '?'
                    else:
                        meta['name'] = str(feature.qualifiers['linkage_group'][0])
                break
        seq_id = record.id
        meta['id'] = seq_id
        meta['orga'] = record.annotations['organism']
        meta['length'] = len(record.seq)
        meta['topology'] = record.annotations['topology']
        meta['molecule'] = record.annotations['molecule_type']
    if verbose:
        Prot.write('Results: id=%s,name=%s,organism=%s,topology=%s,length=%s,molecule=%s' % (meta['id'], meta['name'], meta['orga'], meta['topology'], meta['length'], meta['molecule']))
    return meta

def read_genbank(input_filename, feature_processor=None, verbose=1):
    features = read_all_features(input_filename)
    if feature_processor is None:
        return features
    return feature_processor.process(features)

def read_chromo(chromosome, read_func, verbose=1):
    return read_func(chromosome.filename, chromosome=chromosome, verbose=verbose)

def interpret_read_input(read_func, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose):
    if organism is not None:
        return [read_chromo(chromosome, read_func, verbose) for chromosome in Oligo.File.read_genome(organism, seqs_filename=seqs_filename)]
    elif chromosome is not None:
        return read_chromo(chromosome, read_func, verbose)
    else:
        return read_chromo(Oligo.File.read_chromosome(chromo_name, seqs_filename), read_func, verbose)
    return None

#def read_chromo_genes(chromosome, verbose=1):
#    #return read_genes(chromosome.filename, chromosome=chromosome, verbose=verbose)

def read_centromere(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_centromere, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading Centromere from '+str(input_filename))
    fp = FeatureProcessor.CentromereFeatureProcessor(chromosome)
    centros = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if chromosome is not None:
        Oligo.Loci.add_target(centros, chromosome)
    if verbose:
        Prot.write('Found '+str(len(centros))+' centromeres.')
    if not centros:
        Prot.warn('No valid centromere found in '+input_filename, type='Empty Read Result')
    return centros

def read_genes(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, add_exons=False, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_genes, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading all Genes from '+str(input_filename))
    fp = FeatureProcessor.GeneFeatureProcessor(chromosome, add_exons=add_exons)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if chromosome is not None:
        Oligo.Loci.add_target(genes, chromosome)
    if verbose:
        Prot.write('Found '+str(len(genes))+' genes.')
    if not genes:
        Prot.warn('No valid genes found in '+input_filename, type='Empty Read Result')
    return genes

def read_exons(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, max_exons=True, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_exons, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading all Exons from '+str(input_filename))
    if max_exons:
        fp = FeatureProcessor.GeneFeatureProcessor(chromosome, add_exons=True, add_mRNA=True, add_ncRNA=True, add_lncRNA=True, add_miRNA=True, add_tRNA=True, add_rRNA=True, add_precursor_RNA=True, add_snoRNA=True, add_snRNA=True, max_exons=max_exons)
    else:
        fp = FeatureProcessor.GeneFeatureProcessor(chromosome, add_exons=True, max_exons=max_exons)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if not genes:
        Prot.warn('No valid genes found in '+input_filename, type='Empty Read Result')
    exons = []
    for gene in genes:
        exons += gene.exons
    if chromosome is not None:
        Oligo.Loci.add_target(exons, chromosome)
    if verbose:
        Prot.write('Found '+str(len(exons))+' exons.')
    if not exons:
        Prot.warn('No valid exons found in '+input_filename, type='Empty Read Result')
    return exons

def read_introns(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, min_introns=True, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_introns, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading all Introns from '+str(input_filename))
    fp = FeatureProcessor.GeneFeatureProcessor(chromosome, add_exons=True, add_mRNA=True, add_cds=True, add_introns=True, min_introns=min_introns)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if not genes:
        Prot.warn('No valid genes found in '+input_filename, type='Empty Read Result')
    introns = []
    for gene in genes:
        introns += gene.introns
    if chromosome is not None:
        Oligo.Loci.add_target(introns, chromosome)
    if verbose:
        Prot.write('Found '+str(len(introns))+' introns.')
    if not introns:
        Prot.warn('No valid introns found in '+input_filename, type='Empty Read Result')
    return introns

def read_cds(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_cds, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading all CDS from '+str(input_filename))
    fp = FeatureProcessor.GeneFeatureProcessor(chromosome, add_cds=True)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if not genes:
        Prot.warn('No valid genes found in '+input_filename, type='Empty Read Result')
    cds = []
    for gene in genes:
        cds += gene.cds
    if chromosome is not None:
        Oligo.Loci.add_target(cds, chromosome)
    if verbose:
        Prot.write('Found '+str(len(cds))+' CDS.')
    if not cds:
        Prot.warn('No valid CDS found in '+input_filename, type='Empty Read Result')
    return cds

def read_mRNA(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_mRNA, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading all mRNA from '+str(input_filename))
    fp = FeatureProcessor.GeneFeatureProcessor(chromosome, add_mRNA=True)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if not genes:
        Prot.warn('No valid genes found in '+input_filename, type='Empty Read Result')
    mRNAs = []
    for gene in genes:
        mRNAs += gene.mRNA
    if chromosome is not None:
        Oligo.Loci.add_target(mRNAs, chromosome)
    if verbose:
        Prot.write('Found '+str(len(mRNAs))+' mRNAs.')
    if not mRNAs:
        Prot.warn('No valid mRNA found in '+input_filename, type='Empty Read Result')
    return mRNAs
    
read_mRNAs = read_mRNA

def read_intergenics(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, chromosome_length=None, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_intergenics, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Extracting Intergenic Regions from %s.' % input_filename)
    genes = read_genes(input_filename=input_filename, chromosome=chromosome, verbose=verbose)
    if chromosome_length is None:
        if chromosome is None:
            Prot.warn('Trying to derive Intergenic regions without specifying chromosome or chromosome length.')
        chromosome_length = len(chromosome)
    intergenics = Oligo.Loci.invert(genes, [0, chromosome_length])
    if chromosome is not None:
        Oligo.Loci.add_target(intergenics, chromosome)
    if verbose:
        Prot.write('Extracted %s Intergenic Regions.' % len(intergenics))
    return intergenics

read_intergenic = read_intergenics

def read_protein_coding_genes(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_protein_coding_genes, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading Protein Coding Genes from %s.' % input_filename)
    fp = FeatureProcessor.ProteinCodingGeneFeatureProcessor(chromosome)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if chromosome is not None:
        Oligo.Loci.add_target(genes, chromosome)
    if verbose:
        Prot.write('Extracted %s Protein Coding Genes.' % len(genes))
    return genes

read_pc_genes = read_protein_coding_genes

def read_protein_coding_exons(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, max_exons=True, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_exons, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading all Protein Coding Exons from '+str(input_filename))
    if max_exons:
        fp = FeatureProcessor.ProteinCodingGeneFeatureProcessor(chromosome, add_exons=True, add_mRNA=True, add_ncRNA=True, add_lncRNA=True, add_miRNA=True, add_tRNA=True, add_rRNA=True, add_precursor_RNA=True, add_snoRNA=True, add_snRNA=True, max_exons=max_exons)
    else:
        fp = FeatureProcessor.ProteinCodingGeneFeatureProcessor(chromosome, add_exons=True, max_exons=max_exons)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if not genes:
        Prot.warn('No valid genes found in '+input_filename, type='Empty Read Result')
    exons = []
    for gene in genes:
        exons += gene.exons
    if chromosome is not None:
        Oligo.Loci.add_target(exons, chromosome)
    if verbose:
        Prot.write('Found '+str(len(exons))+' exons.')
    if not exons:
        Prot.warn('No valid exons found in '+input_filename, type='Empty Read Result')
    return exons

read_pc_exons = read_protein_coding_exons

def read_protein_coding_genes_introns(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, min_introns=True, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_introns, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading all Introns of Protein Coding Genes from '+str(input_filename))
    fp = FeatureProcessor.ProteinCodingGeneFeatureProcessor(chromosome, add_exons=True, add_mRNA=True, add_cds=True, add_introns=True, min_introns=min_introns)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if not genes:
        Prot.warn('No valid genes found in '+input_filename, type='Empty Read Result')
    introns = []
    for gene in genes:
        introns += gene.introns
    if chromosome is not None:
        Oligo.Loci.add_target(introns, chromosome)
    if verbose:
        Prot.write('Found '+str(len(introns))+' introns.')
    if not introns:
        Prot.warn('No valid introns found in '+input_filename, type='Empty Read Result')
    return introns

read_pc_introns = read_protein_coding_genes_introns

def read_pseudo_genes(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_pseudo_genes, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading Pseudo Genes from %s.' % input_filename)
    fp = FeatureProcessor.PseudoGeneFeatureProcessor(chromosome)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if chromosome is not None:
        Oligo.Loci.add_target(genes, chromosome)
    if verbose:
        Prot.write('Extracted %s Pseudo Genes.' % len(genes))
    return genes

def read_pseudo_genes_exons(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, max_exons=True, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_exons, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading all Exons pf Pseudo Genes from '+str(input_filename))
    if max_exons:
        fp = FeatureProcessor.PseudoGeneFeatureProcessor(chromosome, add_exons=True, add_mRNA=True, add_ncRNA=True, add_lncRNA=True, add_miRNA=True, add_tRNA=True, add_rRNA=True, add_precursor_RNA=True, add_snoRNA=True, add_snRNA=True, max_exons=max_exons)
    else:
        fp = FeatureProcessor.PseudoGeneFeatureProcessor(chromosome, add_exons=True, max_exons=max_exons)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if not genes:
        Prot.warn('No valid genes found in '+input_filename, type='Empty Read Result')
    exons = []
    for gene in genes:
        exons += gene.exons
    if chromosome is not None:
        Oligo.Loci.add_target(exons, chromosome)
    if verbose:
        Prot.write('Found '+str(len(exons))+' exons.')
    if not exons:
        Prot.warn('No valid exons found in '+input_filename, type='Empty Read Result')
    return exons

def read_pseudo_genes_introns(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, min_introns=True, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_introns, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading all Introns of Pseudo Genes from '+str(input_filename))
    fp = FeatureProcessor.PseudoGeneFeatureProcessor(chromosome, add_exons=True, add_mRNA=True, add_cds=True, add_introns=True, min_introns=min_introns)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if not genes:
        Prot.warn('No valid genes found in '+input_filename, type='Empty Read Result')
    introns = []
    for gene in genes:
        introns += gene.introns
    if chromosome is not None:
        Oligo.Loci.add_target(introns, chromosome)
    if verbose:
        Prot.write('Found '+str(len(introns))+' introns.')
    if not introns:
        Prot.warn('No valid introns found in '+input_filename, type='Empty Read Result')
    return introns

def read_non_protein_coding_genes(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_non_protein_coding_genes, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Extracting Non Protein Coding Genes from %s.' % input_filename)
    fp = FeatureProcessor.NonProteinCodingGeneFeatureProcessor(chromosome)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if chromosome is not None:
        Oligo.Loci.add_target(genes, chromosome)
    if verbose:
        Prot.write('Extracted %s Non Protein Coding Genes.' % len(genes))
    return genes

read_npc_genes = read_non_protein_coding_genes

def read_non_protein_coding_genes_exons(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, max_exons=True, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_exons, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading all Exons of non-Protein Coding Genes from '+str(input_filename))
    if max_exons:
        fp = FeatureProcessor.NonProteinCodingGeneFeatureProcessor(chromosome, add_exons=True, add_mRNA=True, add_ncRNA=True, add_lncRNA=True, add_miRNA=True, add_tRNA=True, add_rRNA=True, add_precursor_RNA=True, add_snoRNA=True, add_snRNA=True, max_exons=max_exons)
    else:
        fp = FeatureProcessor.NonProteinCodingGeneFeatureProcessor(chromosome, add_exons=True, max_exons=max_exons)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if not genes:
        Prot.warn('No valid genes found in '+input_filename, type='Empty Read Result')
    exons = []
    for gene in genes:
        exons += gene.exons
    if chromosome is not None:
        Oligo.Loci.add_target(exons, chromosome)
    if verbose:
        Prot.write('Found '+str(len(exons))+' exons.')
    if not exons:
        Prot.warn('No valid exons found in '+input_filename, type='Empty Read Result')
    return exons

read_npc_exons = read_non_protein_coding_genes_exons

def read_non_protein_coding_genes_introns(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, min_introns=True, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_introns, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading all Introns of non-Protein Coding Genes from '+str(input_filename))
    fp = FeatureProcessor.NonProteinCodingGeneFeatureProcessor(chromosome, add_exons=True, add_mRNA=True, add_cds=True, add_introns=True, min_introns=min_introns)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if not genes:
        Prot.warn('No valid genes found in '+input_filename, type='Empty Read Result')
    introns = []
    for gene in genes:
        introns += gene.introns
    if chromosome is not None:
        Oligo.Loci.add_target(introns, chromosome)
    if verbose:
        Prot.write('Found '+str(len(introns))+' introns.')
    if not introns:
        Prot.warn('No valid introns found in '+input_filename, type='Empty Read Result')
    return introns

read_npc_introns = read_non_protein_coding_genes_introns

def read_ncRNA_genes(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_ncRNA_genes, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Extracting RNA Genes from %s.' % input_filename)
    fp = FeatureProcessor.RNAGeneFeatureProcessor(chromosome)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if chromosome is not None:
        Oligo.Loci.add_target(genes, chromosome)
    if verbose:
        Prot.write('Extracted %s RNA Genes.' % len(genes))
    return genes

def read_ncRNAs(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_ncRNAs, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading all ncRNAs from '+str(input_filename))
    fp = FeatureProcessor.RNAGeneFeatureProcessor(chromosome, add_ncRNA=True)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if not genes:
        Prot.warn('No valid genes found in '+input_filename, type='Empty Read Result')
    ncRNAs = []
    for gene in genes:
        ncRNAs += gene.ncRNAs
    if chromosome is not None:
        Oligo.Loci.add_target(ncRNAs, chromosome)
    if not ncRNAs:
        Prot.warn('No valid ncRNA found in '+input_filename, type='Empty Read Result')
    return ncRNAs

def read_long_non_coding_rna_genes(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_long_non_coding_rnas, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Extracting Long non Coding RNAs from %s.' % input_filename)
    fp = FeatureProcessor.LongNoneCodingRNAFeatureProcessor(chromosome)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if chromosome is not None:
        Oligo.Loci.add_target(genes, chromosome)
    if verbose:
        Prot.write('Extracted %s Long non Coding RNAs.' % len(genes))
    return genes

read_lncRNA_genes = read_long_non_coding_rna_genes

def read_lncRNAs(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_lncRNAs, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading all lncRNAs from '+str(input_filename))
    fp = FeatureProcessor.RNAGeneFeatureProcessor(chromosome, add_lncRNA=True)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if not genes:
        Prot.warn('No valid genes found in '+input_filename, type='Empty Read Result')
    lncRNAs = []
    for gene in genes:
        lncRNAs += gene.lncRNAs
    if chromosome is not None:
        Oligo.Loci.add_target(lncRNAs, chromosome)
    if not lncRNAs:
        Prot.warn('No valid lncRNA found in '+input_filename, type='Empty Read Result')
    return lncRNAs

def read_micro_rna_genes(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_micro_rnas, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Extracting micro RNAs from %s.' % input_filename)
    fp = FeatureProcessor.MicroRNAFeatureProcessor(chromosome)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if chromosome is not None:
        Oligo.Loci.add_target(genes, chromosome)
    if verbose:
        Prot.write('Extracted %s micro RNAs.' % len(genes))
    return genes

read_miRNA_genes = read_micro_rna_genes

def read_miRNAs(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_miRNAs, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading all miRNAs from '+str(input_filename))
    fp = FeatureProcessor.RNAGeneFeatureProcessor(chromosome, add_miRNA=True)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if not genes:
        Prot.warn('No valid genes found in '+input_filename, type='Empty Read Result')
    miRNAs = []
    for gene in genes:
        miRNAs += gene.miRNAs
    if chromosome is not None:
        Oligo.Loci.add_target(miRNAs, chromosome)
    if not miRNAs:
        Prot.warn('No valid miRNA found in '+input_filename, type='Empty Read Result')
    return miRNAs
    
def read_snoRNAs(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_snoRNAs, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading all snoRNAs from '+str(input_filename))
    fp = FeatureProcessor.RNAGeneFeatureProcessor(chromosome, add_snoRNA=True)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if not genes:
        Prot.warn('No valid genes found in '+input_filename, type='Empty Read Result')
    snoRNAs = []
    for gene in genes:
        snoRNAs += gene.snoRNAs
    if chromosome is not None:
        Oligo.Loci.add_target(snoRNAs, chromosome)
    if not snoRNAs:
        Prot.warn('No valid snoRNA found in '+input_filename, type='Empty Read Result')
    return snoRNAs
    
def read_snRNAs(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_snRNAs, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading all snRNAs from '+str(input_filename))
    fp = FeatureProcessor.RNAGeneFeatureProcessor(chromosome, add_snRNA=True)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if not genes:
        Prot.warn('No valid genes found in '+input_filename, type='Empty Read Result')
    snRNAs = []
    for gene in genes:
        snRNAs += gene.snRNAs
    if chromosome is not None:
        Oligo.Loci.add_target(snRNAs, chromosome)
    if not snRNAs:
        Prot.warn('No valid snRNA found in '+input_filename, type='Empty Read Result')
    return snRNAs
    
def read_tRNAs(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_tRNAs, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading all tRNAs from '+str(input_filename))
    fp = FeatureProcessor.GeneFeatureProcessor(chromosome, add_tRNA=True)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if not genes:
        Prot.warn('No valid genes found in '+input_filename, type='Empty Read Result')
    tRNAs = []
    for gene in genes:
        tRNAs += gene.tRNAs
    if chromosome is not None:
        Oligo.Loci.add_target(tRNAs, chromosome)
    if not tRNAs:
        Prot.warn('No valid tRNA found in '+input_filename, type='Empty Read Result')
    return tRNAs
    
def read_rRNAs(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_rRNAs, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading all rRNAs from '+str(input_filename))
    fp = FeatureProcessor.GeneFeatureProcessor(chromosome, add_rRNA=True)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if not genes:
        Prot.warn('No valid genes found in '+input_filename, type='Empty Read Result')
    rRNAs = []
    for gene in genes:
        rRNAs += gene.rRNAs
    if chromosome is not None:
        Oligo.Loci.add_target(rRNAs, chromosome)
    if not rRNAs:
        Prot.warn('No valid rRNA found in '+input_filename, type='Empty Read Result')
    return rRNAs

def read_precursor_RNAs(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_precursor_RNAs, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading all precursor RNAs from '+str(input_filename))
    fp = FeatureProcessor.GeneFeatureProcessor(chromosome, add_precursor_RNA=True)
    genes = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if not genes:
        Prot.warn('No valid genes found in '+input_filename, type='Empty Read Result')
    precursor_RNAs = []
    for gene in genes:
        precursor_RNAs += gene.precursor_RNAs
    if chromosome is not None:
        Oligo.Loci.add_target(precursor_RNAs, chromosome)
    if not precursor_RNAs:
        Prot.warn('No valid precursor RNA found in '+input_filename, type='Empty Read Result')
    return precursor_RNAs

def read_gaps(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_gaps, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading all Gaps from '+str(input_filename))
    fp = FeatureProcessor.GapFeatureProcessor(chromosome)
    gaps = read_genbank(input_filename, feature_processor=fp, verbose=verbose)
    if chromosome is not None:
        Oligo.Loci.add_target(gaps, chromosome)
    if verbose:
        Prot.write('Found '+str(len(gaps))+' gaps.')
    if not gaps:
        Prot.warn('No valid gaps found in '+input_filename, type='Empty Read Result')
    return gaps
    
def read_sequence_gaps(input_filename=None, organism=None, chromosome=None, chromo_name=None, seqs_filename=None, verbose=1):
    if input_filename is None:
        return interpret_read_input(read_sequence_gaps, input_filename, organism, chromosome, chromo_name, seqs_filename, verbose)
    if verbose:
        Prot.write('Reading all Gaps from '+str(input_filename))
    data_seq_id, data_seq = Oligo.File.read_sequence_file(input_filename)
    gaps = Oligo.Search.simple_search_gaps(data_seq)
    if chromosome is not None:
        Oligo.Loci.add_target(gaps, chromosome)
    if verbose:
        Prot.write('Found '+str(len(gaps))+' gaps.')
    if not gaps:
        Prot.warn('No valid gaps found in '+input_filename, type='Empty Read Result')
    return gaps
