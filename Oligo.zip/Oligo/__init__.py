from . import Orga
from . import Regio
from . import Loci
from . import Seq
from . import Search
from . import Maps
from . import Matrix
from . import Prot
from . import File
from . import Input
from . import Data
from . import Plot
from . import Model
from . import Kmer
from . import Index
from . import Fit

from .Seq import Sequence
from .Loci import Locus
from .Loci import Gene
from .Loci import Bin
from .Index import Index

Data.read_config_data(verbose=0)
