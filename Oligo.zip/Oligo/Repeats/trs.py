import numpy as np
from math import sqrt

TRS = ['AA','CC','GG','TT','AC','GT','AG','CT','AT','CG']
DINUCS = ['AA','TT','AT','TA','AC','GT','CA','TG','AG','CT','GA','TC','CC','GG','CG','GC']

class TRModel(object):
    
    def get_repeat_nuc_at_posi(self,tr,posi):
        return tr[posi%2]
    
    def invert(self, tr):
        return tr[1]+tr[0]
        
    def count_simulated_tr(self, tr, length, repeat_counters, repeat_length_distributions):
        try:
            repeat_counters[tr]
        except:
            tr = self.invert(tr)
        repeat_counters[tr] += 1
        try:
            repeat_length_distributions[tr][length]
        except:
            repeat_length_distributions[tr][length] = 1
        else:
            repeat_length_distributions[tr][length] += 1
    
class TRMonomerModel(TRModel):
    
    def __init__(self, nuc_data, data_normalized=False, consider_inverse=True):
        self.nuc_data = nuc_data
        if not data_normalized:
            s = sum([self.nuc_data[nuc] for nuc in ['A','C','G','T']])
            if s != 0:
                self.nuc_data = {nuc:float(self.nuc_data[nuc])/s for nuc in ['A','C','G','T']}
        self.consider_inverse = consider_inverse
        
    def get_random_nucleotide(self):
        return np.random.choice(['A','C','G','T'], p=[self.nuc_data['A'],self.nuc_data['C'],self.nuc_data['G'],self.nuc_data['T']])
    
    def simulated_results(self, sequence_length=100, l_min=4, l_max=None):
        current_last_nuc = self.get_random_nucleotide()
        current_nuc = self.get_random_nucleotide()
        
        current_repeat = current_last_nuc+current_nuc
        current_repeat_length = 2
        
        repeat_counters = {tr:0 for tr in TRS}
        repeat_length_distributions = {}
        for tr in TRS:
            repeat_length_distributions[tr] = {}
            
        for i in range(2,sequence_length):
            current_last_nuc = current_nuc
            current_nuc = self.get_random_nucleotide()
            if current_nuc == self.get_repeat_nuc_at_posi(current_repeat,current_repeat_length):
                current_repeat_length += 1
            else:
                if current_repeat_length >= l_min and (l_max is None or current_repeat_length <= l_max):
                    self.count_simulated_tr(current_repeat, current_repeat_length, repeat_counters, repeat_length_distributions)
                current_repeat = current_last_nuc+current_nuc
                current_repeat_length = 2
        if current_repeat_length >= l_min and (l_max is None or current_repeat_length <= l_max):
            self.count_simulated_tr(current_repeat, current_repeat_length, repeat_counters, repeat_length_distributions)    
        return repeat_counters, repeat_length_distributions
    
    def get_expectation(self, tr, sequence_length, l_min=4, l_max=50, consider_inverse=True):
        if len(tr) == 1:
            tr = tr+tr
        n = 0.  # expected total count of TRs
        c = 0.  # expected total coverage of TRs
        en = 0. # error of expected total count
        ec = 0. # error of expected total coverage
        if consider_inverse and tr[0] != tr[1]:
            trs = [tr, self.invert(tr)]
        else:
            trs = [tr]
        for tr in trs:
            # initial probability:
            if consider_inverse and tr[0] != tr[1]:
                p_i = (1.-self.nuc_data[tr[1]])*self.nuc_data[tr[0]]
            elif tr[0] == tr[1]:
                p_i = (1.-self.nuc_data[tr[0]])*self.nuc_data[tr[0]]
            else:
                p_i = (1.-self.nuc_data[tr[0]]*self.nuc_data[tr[1]])*self.nuc_data[tr[0]]
            l = 1   # current length of TR
            while l <= l_max:
                p_next_nuc = self.nuc_data[self.get_repeat_nuc_at_posi(tr,posi=l)] # probability of next nucleotide
                if l >= l_min:
                    p_l = p_i*(1.-p_next_nuc) # Probability of TRs of current length
                    n_l = sequence_length*p_l # Expected count of TRs with length l
                    n += n_l    
                    c += l*n_l
                    en_l = n_l*(1.-p_l)
                    en += en_l
                    ec += (l**2)*en_l
                p_i *= p_next_nuc
                l += 1
        en = sqrt(en)
        ec = sqrt(ec)
        return (n,c,en,ec)
        
    def get_dinuc_expectations(self, tr, sequence_length, l_min=4, l_max=50, consider_inverse=True):
        if len(tr) == 1:
            tr = tr+tr
        n_dinucs = {dinuc:0.0 for dinuc in ['A','C','G','T']+DINUCS}
        e_dinucs = {dinuc:0.0 for dinuc in ['A','C','G','T']+DINUCS}
        n = 0.  # expected total count of TRs
        en = 0. # error of expected total count
        if consider_inverse and tr[0] != tr[1]:
            trs = [tr, self.invert(tr)]
        else:
            trs = [tr]
        for tr in trs:
            inv_tr = tr[1]+tr[0]
            # initial probability:
            if consider_inverse and tr[0] != tr[1]:
                p_i = (1.-self.nuc_data[tr[1]])*self.nuc_data[tr[0]]
            elif tr[0] == tr[1]:
                p_i = (1.-self.nuc_data[tr[0]])*self.nuc_data[tr[0]]
            else:
                p_i = (1.-self.nuc_data[tr[0]]*self.nuc_data[tr[1]])*self.nuc_data[tr[0]]
            l = 1   # current length of TR
            while l <= l_max:
                next_nuc = self.get_repeat_nuc_at_posi(tr,posi=l)
                p_next_nuc = self.nuc_data[next_nuc] # probability of next nucleotide
                if l >= l_min:
                    p_l = p_i*(1.-p_next_nuc) # Probability of TRs of current length
                    n_l = sequence_length*p_l # Expected count of TRs with length l
                    n += n_l
                    en_l = n_l*(1.-p_l)
                    en += en_l
                    x = int(l/2)
                    n_dinucs[tr] += n_l*x
                    e_dinucs[tr] += en_l*x**2
                    n_dinucs[tr[1]] += n_l*x
                    e_dinucs[tr[1]] += en_l*x**2
                    x = int((l-1)/2)
                    n_dinucs[inv_tr] += n_l*x
                    e_dinucs[inv_tr] += en_l*x**2
                    x = int((l+1)/2)
                    n_dinucs[tr[0]] += n_l*x
                    e_dinucs[tr[0]] += en_l*x**2
                p_i *= p_next_nuc
                l += 1
        for dinuc in ['A','C','G','T']+DINUCS:
            if e_dinucs[dinuc] != 0:
                e_dinucs[dinuc] = sqrt(e_dinucs[dinuc])
        return (n_dinucs,e_dinucs)
    
class TRDimerModel(TRModel):
    
    def __init__(self, dinuc_data, data_normalized=False, consider_inverse=True):
        self.dinuc_data = dinuc_data
        if not data_normalized:
            s = sum([self.dinuc_data[dinuc] for dinuc in DINUCS])
            if s != 0:
                self.dinuc_data = {dinuc:float(self.dinuc_data[dinuc])/s for dinuc in DINUCS}
            else:
                self.dinuc_data = {dinuc:0. for dinuc in DINUCS}
        self.consider_inverse = consider_inverse
        self.generate_norm_factors()
        self.generate_norm_probabilities()
        self.generate_nuc_probabilities()
        self.generate_initial_norm_probabilities()
    
    def generate_norm_factors(self):
        self.norm_factors = {}
        for nuc in ['A','C','G','T']:
            dinucs = self.get_dinucs_starting_with_nuc(nuc)
            self.norm_factors[nuc] = sum([self.dinuc_data[dinuc] for dinuc in dinucs])
    
    def generate_nuc_probabilities(self):
        self.nuc_data = {}
        for nuc in ['A','C','G','T']:
            s = 0.
            for dinuc in DINUCS:
                if dinuc[0] == nuc:
                    s += self.dinuc_data[dinuc]
            self.nuc_data[nuc] = s
    
    def get_dinucs_starting_with_nuc(self, nuc):
        return [nuc+next_nuc for next_nuc in ['A','C','G','T']]
    
    def get_dinucs_ending_with_nuc(self, nuc):
        return [pre_nuc+nuc for pre_nuc in ['A','C','G','T']]
    
    def generate_norm_probabilities(self):
        self.norm_p = {}
        self.norm_p_dict = {}
        for nuc in ['A','C','G','T']:
            norm_factor = self.norm_factors[nuc]
            p = []
            for nuc2 in ['A','C','G','T']:
                if norm_factor != 0:
                    pi = float(self.dinuc_data[nuc+nuc2])/norm_factor
                else:
                    pi = 0
                p.append(pi)
                self.norm_p_dict[nuc+nuc2] = pi
            self.norm_p[nuc] = p
            
    def generate_initial_norm_probabilities(self):
        norm_factors = {}
        for nuc in ['A','C','G','T']:
            dinucs = self.get_dinucs_ending_with_nuc(nuc)
            norm_factors[nuc] = sum([self.dinuc_data[dinuc] for dinuc in dinucs])
        self.init_norm_p_dict = {}
        self.inv_init_norm_p_dict = {}
        for nuc2 in ['A','C','G','T']:
            norm_factor = self.norm_factors[nuc2]
            for nuc1 in ['A','C','G','T']:
                if norm_factor == 0:
                    pi = 0.
                else:
                    pi = float(self.dinuc_data[nuc1+nuc2])/norm_factor
                self.inv_init_norm_p_dict[nuc1+nuc2] = 1.-pi
                self.init_norm_p_dict[nuc1+nuc2] = pi
            
    def get_random_nucleotide(self, current_nuc):
        return np.random.choice(['A','C','G','T'], p=self.norm_p[current_nuc])
    
    def get_start_nucleotide(self):
        return np.random.choice(['A','C','G','T'], p=[self.nuc_data['A'],self.nuc_data['C'],self.nuc_data['G'],self.nuc_data['T']])
    
    def get_norm_dinuc_probability(self, dinuc):
        # Probability given dinuc[0] that dinuc[1] occurs
        return self.norm_p_dict[dinuc]
    
    def get_init_norm_dinuc_probability(self, dinuc):
        # probability given dinuc[1] that dinuc[0] was in front
        return self.init_norm_p_dict[dinuc]
    
    def get_inv_init_norm_dinuc_probability(self, dinuc):
        # 1. - probability given dinuc[1] that dinuc[0] was in front
        return self.inv_init_norm_p_dict[dinuc]
    
    def simulated_results(self, sequence_length=100, l_min=4, l_max=None):
        current_last_nuc = self.get_start_nucleotide()
        current_nuc = self.get_random_nucleotide(current_last_nuc)
        
        current_repeat = current_last_nuc+current_nuc
        current_repeat_length = 2
        
        repeat_counters = {tr:0 for tr in TRS}
        repeat_length_distributions = {}
        for tr in TRS:
            repeat_length_distributions[tr] = {}
            
        for i in range(2,sequence_length):
            current_last_nuc = current_nuc
            current_nuc = self.get_random_nucleotide(current_last_nuc)
            if current_nuc == self.get_repeat_nuc_at_posi(current_repeat,current_repeat_length):
                current_repeat_length += 1
            else:
                if current_repeat_length >= l_min and (l_max is None or current_repeat_length <= l_max):
                    self.count_simulated_tr(current_repeat, current_repeat_length, repeat_counters, repeat_length_distributions)
                current_repeat = current_last_nuc+current_nuc
                current_repeat_length = 2
        if current_repeat_length >= l_min and (l_max is None or current_repeat_length <= l_max):
            self.count_simulated_tr(current_repeat, current_repeat_length, repeat_counters, repeat_length_distributions)    
        return repeat_counters, repeat_length_distributions
    
    def get_expectation(self, tr, sequence_length, l_min=4, l_max=50, consider_inverse=True):
        if len(tr) == 1:
            tr = tr+tr
        n = 0.  # expected total count of TRs
        c = 0.  # expected total coverage of TRs
        en = 0. # error of expected total count
        ec = 0. # error of expected total coverage
        if consider_inverse and tr[0] != tr[1]:
            trs = [tr, self.invert(tr)]
        else:
            trs = [tr]
        for tr in trs:
            inv_tr = tr[1]+tr[0]
            # initial probability:
            if consider_inverse and tr[0] != tr[1]:
                #p_i = (1.-self.dinuc_data[inv_tr])*self.dinuc_data[tr]
                p_i = self.get_inv_init_norm_dinuc_probability(inv_tr)*self.dinuc_data[tr]
            elif tr[0] == tr[1]:
                p_i = self.get_inv_init_norm_dinuc_probability(tr)*self.dinuc_data[tr]
            else:
                p_i = (1.-self.get_init_norm_dinuc_probability(inv_tr)*self.get_init_norm_dinuc_probability(tr))*self.nuc_data[tr]
            l = 2   # current length of TR
            while l <= l_max:
                if l%2 == 1:
                    p_next_nuc = self.get_norm_dinuc_probability(tr)
                else:
                    p_next_nuc = self.get_norm_dinuc_probability(inv_tr)
                if l >= l_min:
                    p_l = p_i*(1.-p_next_nuc) # Probability of TRs of current length
                    n_l = sequence_length*p_l # Expected count of TRs with length l
                    n += n_l    
                    c += l*n_l
                    en_l = n_l*(1.-p_l)
                    en += en_l
                    ec += (l**2)*en_l
                p_i *= p_next_nuc
                l += 1
        en = sqrt(en)
        ec = sqrt(ec)
        return (n,c,en,ec)
        
    def get_dinuc_expectations(self, tr, sequence_length, l_min=4, l_max=50, consider_inverse=True):
        if len(tr) == 1:
            tr = tr+tr
        n_dinucs = {dinuc:0.0 for dinuc in ['A','C','G','T']+DINUCS}
        e_dinucs = {dinuc:0.0 for dinuc in ['A','C','G','T']+DINUCS}
        n = 0.  # expected total count of TRs
        en = 0. # error of expected total count
        if consider_inverse and tr[0] != tr[1]:
            trs = [tr, self.invert(tr)]
        else:
            trs = [tr]
        for tr in trs:
            inv_tr = tr[1]+tr[0]
            # initial probability:
            if consider_inverse and tr[0] != tr[1]:
                #p_i = (1.-self.dinuc_data[inv_tr])*self.dinuc_data[tr]
                p_i = self.get_inv_init_norm_dinuc_probability(inv_tr)*self.dinuc_data[tr]
            elif tr[0] == tr[1]:
                p_i = self.get_inv_init_norm_dinuc_probability(tr)*self.dinuc_data[tr]
            else:
                p_i = (1.-self.get_init_norm_dinuc_probability(inv_tr)*self.get_init_norm_dinuc_probability(tr))*self.nuc_data[tr]
            l = 2   # current length of TR
            while l <= l_max:
                if l%2 == 1:
                    p_next_nuc = self.get_norm_dinuc_probability(tr)
                else:
                    p_next_nuc = self.get_norm_dinuc_probability(inv_tr)
                if l >= l_min:
                    p_l = p_i*(1.-p_next_nuc) # Probability of TRs of current length
                    n_l = sequence_length*p_l # Expected count of TRs with length l
                    n += n_l
                    en_l = n_l*(1.-p_l)
                    en += en_l
                    x = int(l/2)
                    n_dinucs[tr] += n_l*x
                    e_dinucs[tr] += en_l*x**2
                    n_dinucs[tr[1]] += n_l*x
                    e_dinucs[tr[1]] += en_l*x**2
                    x = int((l-1)/2)
                    n_dinucs[inv_tr] += n_l*x
                    e_dinucs[inv_tr] += en_l*x**2
                    x = int((l+1)/2)
                    n_dinucs[tr[0]] += n_l*x
                    e_dinucs[tr[0]] += en_l*x**2
                p_i *= p_next_nuc
                l += 1
        for dinuc in ['A','C','G','T']+DINUCS:
            if e_dinucs[dinuc] != 0:
                e_dinucs[dinuc] = sqrt(e_dinucs[dinuc])
        return (n_dinucs,e_dinucs)