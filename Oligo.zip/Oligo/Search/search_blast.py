import subprocess
import os
import Oligo

package_directory = os.path.dirname(os.path.abspath(__file__))

def fasta_to_db(input_fasta, out_file_id=None, blast_path=None):
    if out_file_id == None:
        out_file_id = input_fasta
    if blast_path is None:
        blast_path = Oligo.Data.blast_path
    Oligo.Prot.write(blast_path+'makeblastdb -in '+input_fasta+' -out "'+out_file_id+'" -dbtype nucl')
    subprocess.call(blast_path+'makeblastdb -in '+input_fasta+' -out "N:/Software/KIP/" -dbtype nucl')
    return out_file_id
	
def delete_database(db_id):
    os.remove(db_id+".nhr")
    os.remove(db_id+".nin")
    os.remove(db_id+".nsq")

def search_blast(data_seq=None, data_seq_name=None, query_seq=None, query_seq_name=None, output_id=None, data_seq_filename=None, query_seq_filename=None, delete_db=True, database_id=None, task='blastn', outfmt=7, word_size=4, evalue=0.0000001, blast_path=None, verbose=1):
    if blast_path is None:
        blast_path = Oligo.Data.blast_path
    delete_data_seq = False
    delete_query_seq = False
    if data_seq is not None:
        data_seq_filename = package_directory+'/../../'+Oligo.File.generate_temp_name('.fasta')
        Oligo.Seq.Sequences.save(data_seq, data_seq_filename, data_seq_name, verbose=0)
        delete_data_seq = True
    if query_seq is not None:
        query_seq_filename = package_directory+'/../../'+Oligo.File.generate_temp_name('.fasta')
        Oligo.Seq.Sequences.save(query_seq, query_seq_filename, query_seq_name, verbose=0)
        delete_query_seq = True
    if database_id is None:
        database_id = data_seq_filename
    db_filenames = [database_id+'.nhr', database_id+'.nin', database_id+'.nsq']
    if not Oligo.File.check_files_exist(db_filenames):
        database_id = fasta_to_db(data_seq_filename, database_id, blast_path)
        
    subprocess.call(blast_path+'blastn -db '+database_id+' -query '+query_seq_filename+' -out '+output_id+' -task '+task+' -outfmt '+str(outfmt)+' -word_size '+str(word_size)+' -evalue '+str(evalue))
    
    if delete_db:
        delete_database(database_id)
    if delete_data_seq:
        Oligo.File.delete_file(data_seq_filename, verbose=0)
    if delete_query_seq:
        Oligo.File.delete_file(query_seq_filename, verbose=0)
