'''
    ======================================================
        SEARCH CHAINS
    ------------------------------------------------------
        Module handling the searching of chains (direct
        tandem repeats) within Sequences. 
    ------------------------------------------------------
        Important Classes:
            ChainSearcher   :   SubProcessSearcher subclass
                                used for chain searching.
        Importans Functions:
            
    ======================================================
'''
from Oligo import Prot
from subprocess import Popen, PIPE, STDOUT
import random
import struct
import sys
import os
#import path
from .search import SubProcessSearcher

package_directory = os.path.dirname(os.path.abspath(__file__))

class ChainSearcher(SubProcessSearcher):
    
    SET_MIN_REPS = 11;
    SET_MIN_PURITY = 14;
    SET_ALLOW_SHIFTS = 15;
    SET_MIN_LENGTH = 16;
    SET_MAX_GAP_SIZE = 17;
    
    def __init__(self):
        super(ChainSearcher, self).__init__()
        
    def start_process(self):
        self.exe = Popen(package_directory+'/search_chains.exe', stdin=PIPE, encoding='utf8')
    
    def change_min_reps(self, min_reps):
        if min_reps <= 0:
            Prot.warn('!WARNING: Invalid number of Minimum Repetitions '+str(min_reps)+' (was set to 1 instead).','invalid parameter')
            min_reps = 1
        self.command(ChainSearcher.SET_MIN_REPS, min_reps)
        
    def change_min_length(self, min_length):
        if min_length <= 0:
            Prot.warn('!WARNING: Invalid number of Minimum Length '+str(min_length)+' (was set to 1 instead).','invalid parameter')
            min_length = 1
        self.command(ChainSearcher.SET_MIN_LENGTH, min_length)
        
    def change_min_purity(self, min_purity):
        self.command(ChainSearcher.SET_MIN_PURITY, float(min_purity))
    
    def change_max_gap_size(self, max_gap_size):
        self.command(ChainSearcher.SET_MAX_GAP_SIZE, int(max_gap_size))
    
    def change_allow_shifts(self, allow_shifts):
        self.command(ChainSearcher.SET_ALLOW_SHIFTS, int(allow_shifts))
    
    def search(self, data_seq=None, data_seq_name=None, query_seq=None, query_seq_name=None, data_seq_filename=None, query_seq_filename=None, output_filename=None, search_type=0, min_length=1, min_purity=1.0, allow_shifts=True, max_gap_size=0, chromosome=None):
        if output_filename is None:
            output_filename = 'Test.search_chains.loci'
        self.change_min_length(min_length)
        self.change_min_purity(min_purity)
        self.change_allow_shifts(allow_shifts)
        self.change_max_gap_size(max_gap_size)
        super(ChainSearcher, self).search(data_seq, data_seq_name, query_seq, query_seq_name, data_seq_filename, query_seq_filename, output_filename, search_type, chromosome)

    
def search_chains(data_seq=None, data_seq_name=None, chain_seed_seq=None, chain_seed_seq_name=None, output_filename=None, search_type=0, min_length=1, min_purity=1.0, allow_shifts=True, max_gap_size=0, data_seq_filename=None, chain_seed_seq_filename=None, genome=None, output_id=None, path='', verbose=1):
    if chain_seed_seq_name is None:
        chain_seed_seq_name = '('+str(chain_seed_seq)+')n'
    if genome is None:
        if data_seq_name is None:
            data_seq_name = data_seq_filename
        if verbose:
            Prot.write('Searching %s chains in %s (%s bp).' % (chain_seed_seq_name, data_seq_name, len(data_seq)))
        searcher = ChainSearcher()
        searcher.search(data_seq=data_seq, data_seq_name=data_seq_name, query_seq=chain_seed_seq, query_seq_name=chain_seed_seq_name, data_seq_filename=data_seq_filename, query_seq_filename=chain_seed_seq_filename, output_filename=output_filename, search_type=search_type, min_length=min_length, min_purity=min_purity, allow_shifts=allow_shifts, max_gap_size=max_gap_size)
    else:
        for chromo in genome:
            if verbose:
                Prot.write('Searching %s chains in %s.' % (chain_seed_seq_name, str(chromo)))
            searcher = ChainSearcher()
            data_seq_name = str(chromo)
            data_seq_filename = chromo.filename
            if output_filename is None:
                if output_id is None:
                    chromo_output_filename = path+data_seq_name+'_'+chain_seed_seq+'.chains.loci'
                else:
                    chromo_output_filename = path+data_seq_name+'_'+chain_seed_seq+'_'+output_id+'.chains.loci'
            searcher.search(data_seq_name=data_seq_name, query_seq=chain_seed_seq, query_seq_name=chain_seed_seq_name, data_seq_filename=data_seq_filename, query_seq_filename=chain_seed_seq_filename, output_filename=chromo_output_filename, search_type=search_type, min_length=min_length, min_purity=min_purity, allow_shifts=allow_shifts, chromosome=chromo, max_gap_size=max_gap_size)
    
    
