void inline fix_buffer(char* buffer);

void inline collect_sequence(char* seq, char* buffer){
	if(buffer[0] != '\n'){
		fix_buffer(buffer);
		strcat(seq, buffer);
	}
}
void inline fix_buffer(char* buffer){
	int ln = strlen(buffer);
	if (buffer[ln-1] == '\n')
		buffer[ln-1] = '\0';
}