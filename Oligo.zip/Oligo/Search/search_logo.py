import Oligo
from Oligo import Prot

def search_logo(data_seq, query_matrix, output_filename, t_min=1e6, verbose=1):
    if verbose:
        Prot.write('Searching Logo in Sequence (%sbp).' % len(data_seq))
    query_length = query_matrix.len_cols()
    max_posi = len(data_seq)-query_length+1
    results = []
    p_base = 0.25**query_length
    for posi in range(max_posi):
        logo_posi = 0
        p_ges = 1.
        while logo_posi < query_length:
            nuc = data_seq[posi+logo_posi]
            if nuc == 'N':
                break
            p = query_matrix.get_value(col_ix=logo_posi, row_name=nuc)
            p_ges *= p
            t_ges = p_ges/p_base
            if t_ges < t_min:
                break
            logo_posi += 1
        if t_ges >= t_min:
            #print t_ges,'!'
            results.append(Oligo.Locus(start=posi, length=query_length))
        #else:
        #    #print t_ges
        posi += 1

    if output_filename is not None:
        if verbose:
            Prot.write('Saving %s loci to %s.' % (len(results), output_filename))
        Oligo.Locus.save(loci=results, output_filename=output_filename)
    return results
