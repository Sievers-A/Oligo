import Oligo
from subprocess import Popen, PIPE, STDOUT
import os.path


def change_exe_para(exe, mode_id, value):
    exe.stdin.write(str(mode_id)+'\n') 
    exe.stdin.write(str(value)+'\n')

def clear_search_file(output_filename):
    open(output_filename, 'w').close()
    
def change_allowed_missmatches(exe, allowed_missmatches):
    change_exe_para(exe, 11, allowed_missmatches)
    
def change_search_type(exe, search_type):
    change_exe_para(exe, 10, search_type)  
    
def send_sequence(exe, seq, type, name=None):
    if name is None:
        try:
            seq.name
        except:
            try:
                seq.id
            except:
                name = seq[0:20]
            else:
                name = seq.id
        else:
            name = seq.name
    if type == 0:
        change_exe_para(exe, 3, name)        
        change_exe_para(exe, 2, len(seq))        
        change_exe_para(exe, 1, 500000)        
        change_exe_para(exe, 6, seq)        
    else:
        change_exe_para(exe, 5, name)
        change_exe_para(exe, 4, len(seq))
        change_exe_para(exe, 1, 500000)
        change_exe_para(exe, 7, seq)
    change_exe_para(exe, 1, 256)
    return name
        
def send_data_sequence(exe, seq, name):
    send_sequence(exe, seq, 0, name)
    
def send_query_sequence(exe, seq, name):
    send_sequence(exe, seq, 1, name)
 
def save_results(exe, output_filename):
    change_exe_para(exe, 12, output_filename)
    exe.stdin.write('13\n')
    exe.stdin.write('\n')
    
def cancel_exe(exe):
   exe.stdin.write('9\n')
   exe.stdin.close()
   exe.wait() 
 
def search_seq(data_seq=None, query_seq=None, output_filename='search_results.loci', data_seq_name=None, query_seq_name=None, data_seq_filename=None, query_seq_filename=None, allowed_missmatches=0, search_type=0, clear_file=True, search_both_strands=True, backend=1, verbose=1):
    '''
        Arguments:
            data_seq (str)  :           sequence to search other sequence (query) in.
            query_seq (str) :           sequence to search for
            data_seq_name (str) :       name of the data sequence
            query_seq_name (str) :      name of the query sequence
            allowed_missmatches (int) : number of allowed missmatches in the search hits.
            search_type (int) :         type of base identification algorithm (affects performance)
                                            0 : only exact matches between query and data bases are considered
                                            1 : R, D, W, H, V, M, Y, P, N, - allowed in query sequence.
                                            2 : Everything allowed in query and data sequence.
            clear_file (bool) :         if the output file is cleared before adding new results.
            backend :                   backend used for the search:
                                            0 : C++ backend (fast but sometimes hard to instal
                                            1 : Python slower but works alle the time
            verbose (int) :             if docstrings are printed. 
    
    '''
    if query_seq is None:
        query_seq_id, query_seq = Oligo.File.read_sequence_file(query_seq_filename)
        if query_seq_name is None:
            query_seq_name = query_seq_id
    if data_seq is None:
        data_seq_id, data_seq = Oligo.File.read_sequence_file(data_seq_filename)
        if data_seq_name is None:
            data_seq_name = data_seq_id
    if data_seq_name is None:
        data_seq_name = data_seq[0:20]
    if query_seq_name is None:
        query_seq_name = query_seq[0:20]
    if backend == 0: # C++ Backend    
        exe_path = os.path.abspath(os.path.dirname(__file__))
        exe_path = os.path.join(exe_path, './search.exe')
        exe = Popen(exe_path, stdin=PIPE, encoding='utf8')
        if clear_file:
            clear_search_file(output_filename)
        change_search_type(exe, search_type)
        change_allowed_missmatches(exe, allowed_missmatches)
        send_data_sequence(exe, data_seq, data_seq_name)
        send_query_sequence(exe, query_seq, query_seq_name)
        if verbose:
            Oligo.Prot.write('Searching %s (%s) for %s (%s)' % (data_seq_name, len(data_seq), query_seq_name, len(query_seq)))
        # Search
        exe.stdin.write('8\n')
        exe.stdin.write('\n')
        if verbose:
            Oligo.Prot.write('Saving Results to '+output_filename)
        save_results(exe, output_filename)
        # Close Search Process
        cancel_exe(exe)
    elif backend == 1: # Python
        if search_type == 0:
            if allowed_missmatches == 0:
                match_function = exact_sequence_match
            else:
                match_function = exact_sequence_match_mm
        else:
            if allowed_missmatches == 0:
                match_function = extended_nuc_match
            else:
                match_function = extended_nuc_match_mm
        loci = python_search(data_seq, query_seq, match_function, allowed_missmatches, strand='+')
        if search_both_strands:
            loci += python_search(data_seq, revert_sequence(query_seq), match_function, allowed_missmatches, strand='-')
        Oligo.Locus.save(loci, output_filename=output_filename, default_features={'data name':data_seq_name, 'name':query_seq_name, 'length':len(query_seq)}, saved_features=['start','strand','number of missmatches'])
    else:
        Oligo.Prot.error('Specified undefinded search backend %s in search_seq().' % backend)

def exact_sequence_match(seq1, seq2, max_mm):
    return seq1 == seq2, 0
    
def exact_sequence_match_mm(seq1, seq2, max_mm):
    mm = 0
    for nuc1,nuc2 in zip(seq1,seq2):
        if nuc1 != nuc2:
            mm += 1
            if mm > max_mm:
                return False, mm
    return True, mm
    
def extended_nuc_match(seq1, seq2, max_mm):
    for nuc1,nuc2 in zip(seq1,seq2):
        if not EXTENDED_MATCHES[seq1][seq2]:
            return False, 0
    return True, 0

def extended_nuc_match_mm(seq1, seq2, max_mm):
    mm = 0
    for nuc1,nuc2 in zip(seq1,seq2):
        if not EXTENDED_MATCHES[seq1][seq2]:
            mm += 1
            if mm > max_mm:
                return False, mm
    return True, mm

EXTENDED_MATCHES = {'A':{'A':True, 'C':False, 'G':False, 'T':False, 'U':False, 'R':True, 'Y':False, 'S':False, 'W':True, 'K':False, 'M':True, 'B':False, 'D':True, 'H':True, 'V':True},'T':{'A':False, 'C':False, 'G':False, 'T':True, 'U':False, 'R':False, 'Y':True, 'S':False, 'W':True, 'K':True, 'M':False, 'B':True, 'D':True, 'H':True, 'V':False},'C':{'A':False, 'C':True, 'G':False, 'T':False, 'U':False, 'R':False, 'Y':True, 'S':True, 'W':False, 'K':False, 'M':True, 'B':True, 'D':False, 'H':True, 'V':True},'G':{'A':False, 'C':False, 'G':True, 'T':False, 'U':False, 'R':True, 'Y':False, 'S':True, 'W':False, 'K':True, 'M':False, 'B':True, 'D':True, 'H':False, 'V':True},'U':{'A':False, 'C':False, 'G':False, 'T':False, 'U':True, 'R':False, 'Y':True, 'S':False, 'W':True, 'K':True, 'M':False, 'B':True, 'D':True, 'H':True, 'V':False},'R':{'A':True, 'C':False, 'G':True, 'T':False, 'U':False, 'R':True, 'Y':False, 'S':True, 'W':True, 'K':True, 'M':True, 'B':True, 'D':True, 'H':True, 'V':True},'Y':{'A':False, 'C':True, 'G':False, 'T':True, 'U':True, 'R':False, 'Y':True, 'S':True, 'W':True, 'K':True, 'M':True, 'B':True, 'D':True, 'H':True, 'V':True},'S':{'A':False, 'C':True, 'G':True, 'T':False, 'U':False, 'R':True, 'Y':True, 'S':True, 'W':False, 'K':True, 'M':True, 'B':True, 'D':True, 'H':True, 'V':True},'W':{'A':True, 'C':False, 'G':False, 'T':True, 'U':True, 'R':True, 'Y':True, 'S':False, 'W':True, 'K':True, 'M':True, 'B':True, 'D':True, 'H':True, 'V':True},'K':{'A':False, 'C':False, 'G':True, 'T':True, 'U':True, 'R':True, 'Y':True, 'S':True, 'W':True, 'K':True, 'M':False, 'B':True, 'D':True, 'H':True, 'V':True}, 'M':{'A':True, 'C':True, 'G':False, 'T':False, 'U':False, 'R':True, 'Y':True, 'S':True, 'W':True, 'K':False, 'M':True, 'B':True, 'D':True, 'H':True, 'V':True}, 'B':{'A':False, 'C':True, 'G':True, 'T':True, 'U':True, 'R':True, 'Y':True, 'S':True, 'W':True, 'K':True, 'M':True, 'B':True, 'D':True, 'H':True, 'V':True}, 'D':{'A':True, 'C':False, 'G':True, 'T':True, 'U':True, 'R':True, 'Y':True, 'S':True, 'W':True, 'K':True, 'M':True, 'B':True, 'D':True, 'H':True, 'V':True}, 'H':{'A':True, 'C':True, 'G':False, 'T':True, 'U':True, 'R':True, 'Y':True, 'S':True, 'W':True, 'K':True, 'M':True, 'B':True, 'D':True, 'H':True, 'V':True}, 'V':{'A':True, 'C':True, 'G':True, 'T':False, 'U':False, 'R':True, 'Y':True, 'S':True, 'W':True, 'K':True, 'M':True, 'B':True, 'D':True, 'H':True, 'V':True}, 'N':{'A':True, 'C':True, 'G':True, 'T':True, 'U':True, 'R':True, 'Y':True, 'S':True, 'W':True, 'K':True, 'M':True, 'B':True, 'D':True, 'H':True, 'V':True},'-':{'A':True, 'C':True, 'G':True, 'T':True, 'U':True, 'R':True, 'Y':True, 'S':True, 'W':True, 'K':True, 'M':True, 'B':True, 'D':True, 'H':True, 'V':True},'.':{'A':True, 'C':True, 'G':True, 'T':True, 'U':True, 'R':True, 'Y':True, 'S':True, 'W':True, 'K':True, 'M':True, 'B':True, 'D':True, 'H':True, 'V':True}}

def revert_sequence(seq):
    reverted_seq = ''
    for nuc in reversed(seq):
        if nuc == 'A':
            reverted_seq += 'T'
        elif nuc == 'T':
            reverted_seq += 'A'
        elif nuc == 'C':
            reverted_seq += 'G'
        elif nuc == 'G':
            reverted_seq += 'C'
        elif nuc == 'U':
            reverted_seq += 'A'
        elif nuc == 'R':
            reverted_seq += 'Y'
        elif nuc == 'Y':
            reverted_seq += 'R'
        elif nuc == 'S':
            reverted_seq += 'S'
        elif nuc == 'W':
            reverted_seq += 'W'
        elif nuc == 'K':
            reverted_seq += 'M'
        elif nuc == 'M':
            reverted_seq += 'K'
        elif nuc == 'B':
            reverted_seq += 'V'
        elif nuc == 'D':
            reverted_seq += 'H'
        elif nuc == 'H':
            reverted_seq += 'D'
        elif nuc == 'V':
            reverted_seq += 'B'
        elif nuc == 'N' or nuc == '-' or nuc == '.':
            reverted_seq += nuc
        else:
            Oligo.Prot.warn('Found undefined nucletide %s in revert_sequence() (will be considered as gap).' % nuc)
            reverted_seq += '-'
    return reverted_seq
        

def python_search(data_seq, query_seq, match_function, allowed_missmatches, strand):
    found_loci = []
    length_query = len(query_seq)
    for posi in range(len(data_seq)-length_query+1):
        test_seq = data_seq[posi:posi+length_query]
        match, mm = match_function(test_seq, query_seq, allowed_missmatches)
        if match:    
            locus = Oligo.Locus(posi, length_query, strand=strand)
            locus.mm = mm
            found_loci.append(locus)
    return found_loci
            
    