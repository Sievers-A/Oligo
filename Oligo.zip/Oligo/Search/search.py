import datetime
import Oligo.File

class Searcher(object):
    pass
    
class SubProcessSearcher(Searcher):
    
    DEFAULT_BUFFER_SIZE = 256
    SEQUENCE_BUFFER_SIZE = 500000
    
    SELECT_MODE = 0
    SET_BUFFER_SIZE = 1
    SET_DATA_SEQUENCE_LENGTH = 2
    SET_DATA_SEQUENCE_NAME = 3
    SET_QUERY_SEQUENCE_LENGTH = 4
    SET_QUERY_SEQUENCE_NAME = 5
    COLLECT_DATA_SEQUENCE = 6
    COLLECT_QUERY_SEQUENCE = 7
    SEARCH = 8
    CLOSE = 9
    SET_SEARCH_TYPE = 10;
    SET_OUTPUT_FILENAME = 12;
    SAVE_DATA = 13;
    
    
    def __init__(self):
        super(SubProcessSearcher, self).__init__()
        self.sequence_buffer_size = SubProcessSearcher.SEQUENCE_BUFFER_SIZE
        self.start_process()
        
    def command(self, command, value=None):
        self.exe.stdin.write(str(command)+"\n")
        if value is not None:
            self.exe.stdin.write(str(value)+"\n")
        else:
            self.exe.stdin.write("\n")
        
    def start_process(self):
        pass
        
    def stop_process(self):
        self.command(SubProcessSearcher.CLOSE)
        self.exe.stdin.close()
        self.exe.wait()
        
    def send_data_seq(self, seq, seq_name):
        self.change_data_seq_name(seq_name)
        self.command(SubProcessSearcher.SET_DATA_SEQUENCE_LENGTH, len(seq))
        if(len(seq) < self.sequence_buffer_size):
            self.command(SubProcessSearcher.SET_BUFFER_SIZE, len(seq)+1)
        else:
            self.send_buffer_size()
        self.command(SubProcessSearcher.COLLECT_DATA_SEQUENCE, str(seq))
        self.command(SubProcessSearcher.SET_BUFFER_SIZE, SubProcessSearcher.DEFAULT_BUFFER_SIZE)
        
    def send_query_seq(self, seq, seq_name):
        self.change_query_seq_name(seq_name)
        self.command(SubProcessSearcher.SET_QUERY_SEQUENCE_LENGTH, len(seq))
        self.send_buffer_size()
        self.command(SubProcessSearcher.COLLECT_QUERY_SEQUENCE, str(seq))
        self.command(SubProcessSearcher.SET_BUFFER_SIZE, SubProcessSearcher.DEFAULT_BUFFER_SIZE)

    def send_buffer_size(self, buffer_size=None):
        if buffer_size != None:
            self.buffer_size = buffer_size
        self.command(SubProcessSearcher.SET_BUFFER_SIZE, self.sequence_buffer_size)
        
    def save_results(self, filename):
        self.command(SubProcessSearcher.SET_OUTPUT_FILENAME, filename)
        self.command(SubProcessSearcher.SAVE_DATA)
        

    def get_seq_id(self, seq):
        try:
            seq.id
        except:
            return None
        else:
            return seq.id
            
    def search(self, data_seq=None, data_seq_name=None, query_seq=None, query_seq_name=None, data_seq_filename=None, query_seq_filename=None, output_filename=None, search_type=0, chromosome=None):
        if query_seq is None:
            query_seq_id, query_seq = Oligo.File.read_sequence_file(query_seq_filename)
        if data_seq is None:
            data_seq_id, data_seq = Oligo.File.read_sequence_file(data_seq_filename)
        if data_seq_name is None:
            data_seq_name = self.get_seq_id(data_seq)
        if query_seq_name is None:
            query_seq_name = self.get_seq_id(query_seq)
        self.send_data_seq(str(data_seq), data_seq_name)
        self.send_query_seq(str(query_seq), query_seq_name)
        self.change_search_type(search_type)
        self.clear_file(output_filename, chromosome)
        self.command(SubProcessSearcher.SEARCH) # <--- runtime problem "search_chains.exe" funktioniert nicht richtig wahrscheinlich ein Problem mit Compilierung oder g++ (cygwin g++ shafft es offenbar).
        self.save_results(output_filename)
        self.stop_process()
        
    def change_data_seq_name(self, seq_name):
        self.command(SubProcessSearcher.SET_DATA_SEQUENCE_NAME, seq_name)
    
    def change_query_seq_name(self, seq_name):
        self.command(SubProcessSearcher.SET_QUERY_SEQUENCE_NAME, seq_name)
    
    def change_search_type(self, new_type):
        self.command(SubProcessSearcher.SET_SEARCH_TYPE, new_type)
        
    def clear_file(self, filename, chromosome):
        f = open(filename, 'w')
        f.write('#date:\t'+str(datetime.datetime.now())+'\n')
        if chromosome is not None:
            f.write('#chromosome:\t'+str(chromosome)+'\n')
        f.close()