/* ============================================
	search_chains.cpp
 --------------------------------------------
	This is the fast C++ tool to search
	chains of a (chain-)seed sequence with
	arbitary length.
 --------------------------------------------
  Version: 12.12.2017 Mannheim ~Aaron
============================================*/

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <vector>

#include "collect_sequence.h"

using namespace std;

struct search_hit{
	long int position;
	int length;
    int mm;
	search_hit *next;
};

struct search_result{
    char *query_seq_name;
    char *data_seq_name;
	long int query_seq_length;
    int allow_shifts;
    int max_gap_size;
    float min_pur;
    int min_length;
	
	search_hit *hits = NULL;
};

void inline search_chains(char* data_seq, int data_seq_length, char* query_seq, int query_seq_length, int min_length, search_result* result, bool (*compare_bases)(char b1, char b2));
void inline search_chains2(char* data_seq, int data_seq_length, char* query_seq, int query_seq_length, int min_length, search_result* result, bool (*compare_bases)(char b1, char b2), int allow_shifts, float min_pur, int max_gap_size);
bool compare_bases_min(char b1, char b2);
bool compare_bases_full(char b1, char b2);
bool compare_bases_extended(char b1, char b2);
void save_results(char* filename, vector<search_result>& search_results);

int main(){
	// Mode Definitions
	const int SELECT_MODE = 0;
	const int SET_BUFFER_SIZE = 1;
	const int SET_DATA_SEQUENCE_LENGTH = 2;
	const int SET_DATA_SEQUENCE_NAME = 3;
	const int SET_QUERY_SEQUENCE_LENGTH = 4;
	const int SET_QUERY_SEQUENCE_NAME = 5;
	const int COLLECT_DATA_SEQUENCE = 6;
	const int COLLECT_QUERY_SEQUENCE = 7;
	const int SEARCH = 8;
	const int CLOSE = 9;
	const int SET_SEARCH_TYPE = 10;
	//const int SET_MIN_REPS = 11;
	const int SET_OUTPUT_FILENAME = 12;
	const int SAVE_DATA = 13;
    const int SET_MIN_PURITY = 14;
    const int SET_ALLOW_SHIFTS = 15;
    const int SET_MIN_LENGTH = 16;
    const int SET_MAX_GAP_SIZE = 17;
	
	int mode = SELECT_MODE;
	
	int buffer_size = 256;
	char *buffer = NULL;
	
	char *data_seq = NULL;
	char *data_seq_name = NULL;
	long int data_seq_length;
	char *query_seq = NULL;
	char *query_seq_name = NULL;
	long int query_seq_length;
	long int current_length;
	char *output_filename = NULL;
	
	int search_type = 0;
	int min_reps = 1;
    int min_length = 1;
    double min_pur = 1.0;
	int allow_shifts = 1;
    int max_gap_size = 0;
    
	vector<search_result> search_results;
	search_result *current_result;
	bool (*compare_bases)(char, char);
	
	buffer = new char[buffer_size];
	buffer[0] = '\0';
	
	while(fgets(buffer, buffer_size, stdin)){
		//printf("MOde: %d Value: %s\n", mode, buffer);
		switch(mode){
			case SELECT_MODE:
				//printf("MODE: %s\n", buffer);
				mode = atoi(buffer);
				break;
			case CLOSE:
				//printf("CLOSING");
				fflush(stdout);
				exit(0);
				break;
			case SET_BUFFER_SIZE:
				//printf("buffer size: %s\n", buffer);
				buffer_size = atoi(buffer);
				delete [] buffer;
				buffer = new char[buffer_size];
				buffer[0] = '\0';
				mode = SELECT_MODE;
				break;
			case SET_DATA_SEQUENCE_LENGTH:
				data_seq_length = atoi(buffer);
				current_length = 0;
				delete [] data_seq;
				data_seq = new char[data_seq_length+1];
				data_seq[0] = '\0';
				mode = SELECT_MODE;
				//printf("data sequence length: %s\n", buffer);
				break;
			case SET_DATA_SEQUENCE_NAME:
				delete [] data_seq_name;
				data_seq_name = new char[buffer_size];
				data_seq_name[0] = '\0';
				strcpy(data_seq_name, buffer);
				//printf("data seq name: %s %d\n", data_seq_name, buffer_size);
				mode = SELECT_MODE;
				break;
			case SET_QUERY_SEQUENCE_LENGTH:
				//printf("query sequence length: %s\n", buffer);
				query_seq_length = atoi(buffer);
				current_length = 0;
				delete [] query_seq;
				query_seq = new char[query_seq_length+1];
				query_seq[0] = '\0';
				mode = SELECT_MODE;
				break;
			case SET_QUERY_SEQUENCE_NAME:
				delete [] query_seq_name;
				query_seq_name = new char[buffer_size];
				query_seq_name[0] = '\0';
				strcpy(query_seq_name, buffer);
				//printf("query seq name: %s %d\n", query_seq_name, buffer_size);
				mode = SELECT_MODE;
				break;
			case COLLECT_DATA_SEQUENCE:
				collect_sequence(data_seq, buffer);
				current_length += (buffer_size-1);
				if(current_length >= data_seq_length){
					mode = SELECT_MODE;
					//printf("Cellected data seq of length: %d\n",current_length);
				}
				break;
			case COLLECT_QUERY_SEQUENCE:
				collect_sequence(query_seq, buffer);
				current_length += (buffer_size-1);
				if(current_length >= query_seq_length){
					mode = SELECT_MODE;
					//printf("Cellected query seq of length: %d\n",current_length);
				}
				break;
			case SET_SEARCH_TYPE:
				//printf("search type: %s\n", buffer);
				search_type = atoi(buffer);
				mode = SELECT_MODE;
				break;
			/*case SET_MIN_REPS:
				//printf("min. reps: %s\n", buffer);
				min_reps = atoi(buffer);
				mode = SELECT_MODE;
				break;*/
            case SET_MIN_LENGTH:
				//printf("min. length: %s\n", buffer);
				min_length = atoi(buffer);
				mode = SELECT_MODE;
				break;
			case SET_MAX_GAP_SIZE:
				max_gap_size = atoi(buffer);
				mode = SELECT_MODE;
				break;
            case SET_ALLOW_SHIFTS:
                allow_shifts = atoi(buffer);
				mode = SELECT_MODE;
                break;
            case SET_MIN_PURITY:
				//printf("min. purity: %f\n", buffer);
				//printf("min. purity: %f\n", atof(buffer));
                min_pur = atof(buffer);
				mode = SELECT_MODE;
				break;
			case SEARCH:
				//printf("Searching\n");
				fflush(stdout);
				
				current_result = new search_result;
				current_result->query_seq_name = new char[strlen(query_seq_name)];
				current_result->data_seq_name = new char[strlen(data_seq_name)];
				current_result->query_seq_length = query_seq_length;
				current_result->query_seq_name[0] = '\0';
				current_result->data_seq_name[0] = '\0';
				current_result->max_gap_size = max_gap_size;
				current_result->min_pur = min_pur;
				current_result->min_length = min_length;
				current_result->allow_shifts = allow_shifts;
                
                
				strcpy(current_result->query_seq_name, query_seq_name);
				strcpy(current_result->data_seq_name, data_seq_name);
				
				//printf("Query seq name: %s %d\n",current_result->query_seq_name, strlen(query_seq_name));
				//printf("Data seq name: %s %d\n",current_result->data_seq_name, strlen(data_seq_name));
				
				if(search_type == 0)
					compare_bases = &compare_bases_min;
				else if(search_type == 2)
					compare_bases = &compare_bases_full;
				else
					compare_bases = &compare_bases_extended;
				
				//if(allow_shifts or min_pur < 1.)
                search_chains2(data_seq, data_seq_length, query_seq, query_seq_length, min_length, current_result, compare_bases, allow_shifts, min_pur, max_gap_size);
                //else
                 //   search_chains(data_seq, data_seq_length, query_seq, query_seq_length, min_length, current_result, compare_bases);
				
				search_results.push_back(*current_result);
				
				mode = SELECT_MODE;
				break;
			case SET_OUTPUT_FILENAME:
				fix_buffer(buffer);
				delete [] output_filename;
				output_filename = new char[buffer_size];
				strcpy(output_filename, buffer);
				//printf("filename: %s\n", output_filename);
				mode = SELECT_MODE;
				break;
			case SAVE_DATA:
				//printf("saving search results\n");
				save_results(output_filename, search_results);
				search_results.clear();
				mode = SELECT_MODE;
				break;
		}
	}
}

void inline search_chains(char* data_seq, int data_seq_length, char* query_seq, int query_seq_length, int min_length, search_result* result, bool (*compare_bases)(char b1, char b2)){
	bool no_match = 0;
	int reps, length;
	long int posi;
	
	for(posi=(data_seq_length-query_seq_length); posi >= 0; --posi){
		
		no_match = 0;
		reps = 0;
		
		do{
			for(int i=0; i < query_seq_length; ++i){
				if(!(*compare_bases)(data_seq[posi+i], query_seq[i])){
					no_match = 1;
					break;
				}
			}
			if(!no_match){
				++reps;
				posi -= query_seq_length;
			}
		}while(!no_match && posi >= 0);
		
        length = reps*query_seq_length;
		if(length >= min_length){
			search_hit *hit = new search_hit;
			if(posi >= 0)
				hit->position = posi+query_seq_length;
			else
				hit->position = 0;
			hit->length = length;
            hit->mm = 0;
			hit->next = result->hits;
			result->hits = hit;
		}
	}
}

void inline search_chains2(char* data_seq, int data_seq_length, char* query_seq, int query_seq_length, int min_length, search_result* result, bool (*compare_bases)(char b1, char b2), int allow_shifts, float min_pur, int max_gap_size){
	long int posi;
	float pur;
    int mm;
    int gap_size;
    int offset;
    int dposi;
    int length;
    
	for(posi=(data_seq_length-query_seq_length+1); posi >= 0; --posi){
        //printf("posi=%d ", posi);
        offset = 0;
        while(offset < query_seq_length and (allow_shifts or offset == 0)){
            //printf("offset=%d ", offset);
            if((*compare_bases)(data_seq[posi], query_seq[query_seq_length-offset-1])){
                //printf("hit\n");
                dposi = 0;
                mm = 0;
                gap_size = 0;
                do{
                    ++dposi;
                    //printf("\tdposi=%d ", dposi);
                    if(posi-dposi < 0){
                        dposi -= 1;
                        break;
                    }
                    if((*compare_bases)(data_seq[posi-dposi], query_seq[query_seq_length-1-((offset+dposi)%query_seq_length)])){
                        gap_size = 0;
                        //printf("hit g=%d mm=%d\n", gap_size, mm);
                    }else{
                        ++mm;
                        ++gap_size;
                        //printf("no hit g=%d mm=%d\n", gap_size, mm);
                        if(gap_size > max_gap_size){
                            mm -= gap_size;
                            break;
                        }
                    }
                }while(posi-dposi >= 0);
                length = dposi-gap_size+1;
                //printf("\t\tlength=%d ", length);
                if(length >= min_length){
                    pur = (length-mm)/(float)length;
                    //printf("pur=%f\n", pur);
                    if(pur >= min_pur){
                        search_hit *hit = new search_hit;
                        if(posi >= 0)
                            hit->position = posi-length+1;
                        else
                            hit->position = 0;
                        hit->length = length;
                        hit->mm = mm;
                        hit->next = result->hits;
                        result->hits = hit;
                        //printf("accepted: %d %d %d \n", hit->position, hit->length, hit->mm);
                        posi -= (length-1);
                    }
                }
            }
            ++offset;
        }
	}
}

void save_results(char* filename, vector<search_result>& search_results){
	FILE *out_file;
	search_hit* old;
	search_result* current_result;
	
	out_file = fopen(filename, "a+");
	
	for(int i=0; i < search_results.size(); ++i){
		current_result = &search_results[i];
		
		
		fprintf(out_file, "#RESULTS: generated by search_chains.cpp\n");
		fprintf(out_file, "$data sequence name:\t%s", current_result->data_seq_name);
		fprintf(out_file, "$chain seed sequence name:\t%s", current_result->query_seq_name);
		fprintf(out_file, "$chain seed length:\t%ld\n", current_result->query_seq_length);
		fprintf(out_file, "$allow shifts:\t%d\n", current_result->allow_shifts);
		fprintf(out_file, "$minimum length:\t%d\n", current_result->min_length);
		fprintf(out_file, "$minimum purity:\t%f\n", current_result->min_pur);
		fprintf(out_file, "$maximum gap size:\t%d\n", current_result->max_gap_size);
		fprintf(out_file, "location\tlength\tmissmatches\n");
		
		while(current_result->hits != NULL){
			fprintf(out_file, "%ld\t%d\t%d\n", current_result->hits->position, current_result->hits->length, current_result->hits->mm);
			
			old = current_result->hits;
			current_result->hits = current_result->hits->next;
			delete old;
		}
	}
	fclose(out_file);
}

bool compare_bases_min(char b1, char b2){
	return (b1 == b2);
}

bool compare_bases_extended(char b1, char b2){
	switch(b1){
		case 'A':
			return (b2 == 'A' || b2 == 'R' || b2 == 'M' || b2 == 'W' || b2 == 'D' || b2 == 'H' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'C':
			return (b2 == 'C' || b2 == 'Y' || b2 == 'M' || b2 == 'S' || b2 == 'B' || b2 == 'H' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'G':
			return (b2 == 'G' || b2 == 'R' || b2 == 'K' || b2 == 'S' || b2 == 'B' || b2 == 'D' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'T':
			return (b2 == 'T' || b2 == 'Y' || b2 == 'K' || b2 == 'W' || b2 == 'B' || b2 == 'D' || b2 == 'H' || b2 == 'N' || b2 == '-');
			break;
	}
	return 0;
}

bool compare_bases_full(char b1, char b2){
	switch(b1){
		case 'A':
			return (b2 == 'A' || b2 == 'R' || b2 == 'M' || b2 == 'W' || b2 == 'D' || b2 == 'H' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'C':
			return (b2 == 'C' || b2 == 'Y' || b2 == 'M' || b2 == 'S' || b2 == 'B' || b2 == 'H' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'G':
			return (b2 == 'G' || b2 == 'R' || b2 == 'K' || b2 == 'S' || b2 == 'B' || b2 == 'D' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'T':
			return (b2 == 'T' || b2 == 'Y' || b2 == 'K' || b2 == 'W' || b2 == 'B' || b2 == 'D' || b2 == 'H' || b2 == 'N' || b2 == '-');
			break;
		case 'N':
			return 1;
			break;
		case 'U':
			return (b2 == 'U' || b2 == 'Y' || b2 == 'K' || b2 == 'W' || b2 == 'B' || b2 == 'D' || b2 == 'H' || b2 == 'N' || b2 == '-');
			break;
		case 'R':
			return (b2 == 'A' || b2 == 'G' || b2 == 'R' || b2 == 'K' || b2 == 'M' || b2 == 'S' || b2 == 'W' || b2 == 'B' || b2 == 'D' || b2 == 'H' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'Y':
			return (b2 == 'C' || b2 == 'T' || b2 == 'U' || b2 == 'Y' || b2 == 'K' || b2 == 'M' || b2 == 'S' || b2 == 'W' || b2 == 'B' || b2 == 'D' || b2 == 'H' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'K':
			return (b2 == 'G' || b2 == 'T' || b2 == 'U' || b2 == 'R' || b2 == 'Y' || b2 == 'K' || b2 == 'S' || b2 == 'W' || b2 == 'B' || b2 == 'D' || b2 == 'H' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'M':
			return (b2 == 'A' || b2 == 'C' || b2 == 'R' || b2 == 'M' || b2 == 'S' || b2 == 'W' || b2 == 'B' || b2 == 'D' || b2 == 'H' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'S':
			return (b2 == 'C' || b2 == 'G' || b2 == 'R' || b2 == 'Y' || b2 == 'K' || b2 == 'M' || b2 == 'S' || b2 == 'B' || b2 == 'D' || b2 == 'H' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'W':
			return (b2 == 'A' || b2 == 'T' || b2 == 'U' || b2 == 'R' || b2 == 'Y' || b2 == 'K' || b2 == 'M' || b2 == 'W' || b2 == 'B' || b2 == 'D' || b2 == 'H' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'B':
			return (b2 != 'A');
			break;
		case 'D':
			return (b2 != 'C');
			break;
		case 'H':
			return (b2 != 'G');
			break;
		case 'V':
			return (b2 != 'T' && b2 != 'U');
			break;
		case '-':
			return 1;
			break;
	}
	return 0;
}
