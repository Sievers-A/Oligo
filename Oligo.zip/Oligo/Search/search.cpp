/* ============================================
	search.cpp
 --------------------------------------------
	This is the fast C++ tool to search
	exact match sequences in larger sequences
 --------------------------------------------
  Version: 06.06.2016 ~Aaron
============================================*/

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <vector>

#include "collect_sequence.h"

using namespace std;

struct search_hit{
	long int position;
	bool strand;
	int mm;
	search_hit *next;
};

struct search_result{
    char *query_seq_name;
    char *data_seq_name;
	int query_seq_length;
	
	search_hit *hits = NULL;
};

void inline search(char* data_seq, int data_seq_length, char* query_seq, int query_seq_length, search_result* result, bool (*compare_bases)(char b1, char b2));
void inline search_with_missmatches(char* data_seq, int data_seq_length, char* query_seq, int query_seq_length, search_result* result, bool (*compare_bases)(char b1, char b2), int allowed_mm);
bool compare_bases_min(char b1, char b2);
bool compare_bases_full(char b1, char b2);
bool compare_bases_extended(char b1, char b2);
void inline comp_seq(char* original_seq, char* new_seq, int seq_length);
char inline comp_base(char b);
void save_results(char* filename, vector<search_result>& search_results);

int main(){
	// Mode Definitions
	const int SELECT_MODE = 0;
	const int SET_BUFFER_SIZE = 1;
	const int SET_DATA_SEQUENCE_LENGTH = 2;
	const int SET_DATA_SEQUENCE_NAME = 3;
	const int SET_QUERY_SEQUENCE_LENGTH = 4;
	const int SET_QUERY_SEQUENCE_NAME = 5;
	const int COLLECT_DATA_SEQUENCE = 6;
	const int COLLECT_QUERY_SEQUENCE = 7;
	const int SEARCH = 8;
	const int CLOSE = 9;
	const int SET_SEARCH_TYPE = 10;
	const int SET_ALLOWED_MISSMATCHES = 11;
	const int SET_OUTPUT_FILENAME = 12;
	const int SAVE_DATA = 13;
	
	int mode = SELECT_MODE;
	
	int buffer_size = 256;
	char *buffer = NULL;
	
	char *data_seq = NULL;
	char *data_seq_name = NULL;
	long int data_seq_length;
	char *query_seq = NULL;
	char *query_seq_name = NULL;
	long int query_seq_length;
	long int current_length;
	char *output_filename = NULL;
	
	int search_type = 0;
	int allowed_missmatches = 0;
	
	vector<search_result> search_results;
	search_result *current_result;
	bool (*compare_bases)(char, char);
	
	buffer = new char[buffer_size];
	
	while(fgets(buffer, buffer_size, stdin)){
		
		switch(mode){
			case SELECT_MODE:
				//printf("MODE: %s\n", buffer);
				mode = atoi(buffer);
				break;
			case CLOSE:
				//printf("CLOSING");
				fflush(stdout);
				exit(0);
				break;
			case SET_BUFFER_SIZE:
				//printf("buffer size: %s\n", buffer);
				buffer_size = atoi(buffer);
				delete [] buffer;
				buffer = new char[buffer_size];
				mode = SELECT_MODE;
				break;
			case SET_DATA_SEQUENCE_LENGTH:
				data_seq_length = atoi(buffer);
				current_length = 0;
				delete [] data_seq;
				data_seq = new char[data_seq_length+1];
				data_seq[0] = '\0';
				mode = SELECT_MODE;
				//printf("data sequence length: %s\n", buffer);
				break;
			case SET_DATA_SEQUENCE_NAME:
				delete [] data_seq_name;
				data_seq_name = new char[buffer_size];
				data_seq_name[0] = '\0';
				strcpy(data_seq_name, buffer);
				//printf("data seq name: %s %d\n", data_seq_name, buffer_size);
				mode = SELECT_MODE;
				break;
			case SET_QUERY_SEQUENCE_LENGTH:
				//printf("query sequence length: %s\n", buffer);
				query_seq_length = atoi(buffer);
				current_length = 0;
				delete [] query_seq;
				query_seq = new char[query_seq_length+1];
				query_seq[0] = '\0';
				mode = SELECT_MODE;
				break;
			case SET_QUERY_SEQUENCE_NAME:
				delete [] query_seq_name;
				query_seq_name = new char[buffer_size];
				query_seq_name[0] = '\0';
				strcpy(query_seq_name, buffer);
				//printf("query seq name: %s %d\n", query_seq_name, buffer_size);
				mode = SELECT_MODE;
				break;
			case COLLECT_DATA_SEQUENCE:
				collect_sequence(data_seq, buffer);
				current_length += (buffer_size-1);
				if(current_length >= data_seq_length){
					mode = SELECT_MODE;
					//printf("Cellected data seq of length: %d\n",current_length);
					//printf("data sequence: %s\n", data_seq);
				}
				break;
			case COLLECT_QUERY_SEQUENCE:
				collect_sequence(query_seq, buffer);
				current_length += (buffer_size-1);
				if(current_length >= query_seq_length){
					mode = SELECT_MODE;
					//printf("Cellected query seq of length: %d\n",current_length);
					//printf("query sequence: %s\n", query_seq);
				}
				break;
			case SET_SEARCH_TYPE:
				//printf("search type: %s\n", buffer);
				search_type = atoi(buffer);
				mode = SELECT_MODE;
				break;
			case SET_ALLOWED_MISSMATCHES:
				//printf("allowed missmatches: %s\n", buffer);
				allowed_missmatches = atoi(buffer);
				mode = SELECT_MODE;
				break;
			case SEARCH:
				//printf("Searching\n");
				fflush(stdout);
				
				current_result = new search_result;
				current_result->query_seq_name = new char[strlen(query_seq_name)];
				current_result->data_seq_name = new char[strlen(data_seq_name)];
				current_result->query_seq_length = query_seq_length;
				current_result->query_seq_name[0] = '\0';
				current_result->data_seq_name[0] = '\0';
				
				strcpy(current_result->query_seq_name, query_seq_name);
				strcpy(current_result->data_seq_name, data_seq_name);
				
				//printf("Query seq name: %s %d\n",current_result->query_seq_name, strlen(query_seq_name));
				//printf("Data seq name: %s %d\n",current_result->data_seq_name, strlen(data_seq_name));
				
				if(search_type == 0)
					compare_bases = &compare_bases_min;
				else if(search_type == 2)
					compare_bases = &compare_bases_full;
				else
					compare_bases = &compare_bases_extended;
				
				if(allowed_missmatches == 0)
					search(data_seq, data_seq_length, query_seq, query_seq_length, current_result, compare_bases);
				else
					search_with_missmatches(data_seq, data_seq_length, query_seq, query_seq_length, current_result, compare_bases, allowed_missmatches);
				
				search_results.push_back(*current_result);
				
				mode = SELECT_MODE;
				break;
			case SET_OUTPUT_FILENAME:
				fix_buffer(buffer);
				delete [] output_filename;
				output_filename = new char[buffer_size];
				strcpy(output_filename, buffer);
				//printf("filename: %s\n", output_filename);
				mode = SELECT_MODE;
				break;
			case SAVE_DATA:
				//printf("saving search results\n");
				save_results(output_filename, search_results);
				search_results.clear();
				mode = SELECT_MODE;
				break;
		}
	}
}

void inline search(char* data_seq, int data_seq_length, char* query_seq, int query_seq_length, search_result* result, bool (*compare_bases)(char b1, char b2)){
	bool no_match = 0;
	
	char* comp_query_seq = new char[query_seq_length];
	comp_seq(query_seq, comp_query_seq, query_seq_length);
	
	for(long int posi=(data_seq_length-query_seq_length); posi >= 0; --posi){
		no_match = 0;
		for(int i=0; i < query_seq_length; ++i){
			if(!(*compare_bases)(data_seq[posi+i], query_seq[i])){
				no_match = 1;
				break;
			}
		}
		if(!no_match){
			search_hit *hit = new search_hit;
			hit->position = posi;
			hit->strand = 0;
			hit->mm = 0;
			hit->next = result->hits;
			result->hits = hit;
		}
		
		no_match = 0;
		for(int i=0; i < query_seq_length; ++i){
			if(!(*compare_bases)(data_seq[posi+i], comp_query_seq[i])){
				no_match = 1;
				break;
			}
		}
		if(!no_match){
			search_hit *hit = new search_hit;
			hit->position = posi;
			hit->strand = 1;
			hit->mm = 0;
			hit->next = result->hits;
			result->hits = hit;
		}
	}
	
}

void inline search_with_missmatches(char* data_seq, int data_seq_length, char* query_seq, int query_seq_length, search_result* result, bool (*compare_bases)(char b1, char b2), int allowed_missmatches){
	
	int found_mm = 0;
	
	char* comp_query_seq = new char[query_seq_length];
	comp_seq(query_seq, comp_query_seq, query_seq_length);
	
	for(long int posi=(data_seq_length-query_seq_length); posi >= 0; --posi){
		found_mm = 0;
		for(int i=0; i < query_seq_length; ++i){
			if(!(*compare_bases)(data_seq[posi+i], query_seq[i])){
				++found_mm;
				if(found_mm > allowed_missmatches)
					break;
			}
		}
		if(found_mm <= allowed_missmatches){
			search_hit *hit = new search_hit;
			hit->position = posi;
			hit->strand = 0;
			hit->mm = found_mm;
			hit->next = result->hits;
			result->hits = hit;
		}
		
		found_mm = 0;
		for(int i=0; i < query_seq_length; ++i){
			if(!(*compare_bases)(data_seq[posi+i], comp_query_seq[i])){
				++found_mm;
				if(found_mm > allowed_missmatches)
					break;
			}
		}
		if(found_mm <= allowed_missmatches){
			search_hit *hit = new search_hit;
			hit->position = posi;
			hit->strand = 1;
			hit->mm = found_mm;
			hit->next = result->hits;
			result->hits = hit;
		}
	}
	
}

void save_results(char* filename, vector<search_result>& search_results){
	FILE *out_file;
	search_hit* old;
	search_result* current_result;
	
	out_file = fopen(filename, "a+");
	
	for(int i=0; i < search_results.size(); ++i){
		current_result = &search_results[i];
		
		fprintf(out_file, "$data name:\t%s", current_result->data_seq_name);
		fprintf(out_file, "$name:\t%s", current_result->query_seq_name);
		fprintf(out_file, "$length:\t%d\n", current_result->query_seq_length);
		fprintf(out_file, "position\tstrand\tmissmatches\n");
		
		while(current_result->hits != NULL){
			//printf("HIT: %d %d\n", current_result->hits->position, current_result->hits->strand);
			fprintf(out_file, "%ld\t%d\t%d\n", current_result->hits->position, current_result->hits->strand, current_result->hits->mm);
			
			old = current_result->hits;
			current_result->hits = current_result->hits->next;
			delete old;
		}
	}
	fclose(out_file);
}

bool compare_bases_min(char b1, char b2){
	return (b1 == b2);
}

bool compare_bases_extended(char b1, char b2){
	switch(b1){
		case 'A':
			return (b2 == 'A' || b2 == 'R' || b2 == 'M' || b2 == 'W' || b2 == 'D' || b2 == 'H' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'C':
			return (b2 == 'C' || b2 == 'Y' || b2 == 'M' || b2 == 'S' || b2 == 'B' || b2 == 'H' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'G':
			return (b2 == 'G' || b2 == 'R' || b2 == 'K' || b2 == 'S' || b2 == 'B' || b2 == 'D' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'T':
			return (b2 == 'T' || b2 == 'Y' || b2 == 'K' || b2 == 'W' || b2 == 'B' || b2 == 'D' || b2 == 'H' || b2 == 'N' || b2 == '-');
			break;
	}
	return 0;
}

bool compare_bases_full(char b1, char b2){
	switch(b1){
		case 'A':
			return (b2 == 'A' || b2 == 'R' || b2 == 'M' || b2 == 'W' || b2 == 'D' || b2 == 'H' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'C':
			return (b2 == 'C' || b2 == 'Y' || b2 == 'M' || b2 == 'S' || b2 == 'B' || b2 == 'H' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'G':
			return (b2 == 'G' || b2 == 'R' || b2 == 'K' || b2 == 'S' || b2 == 'B' || b2 == 'D' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'T':
			return (b2 == 'T' || b2 == 'Y' || b2 == 'K' || b2 == 'W' || b2 == 'B' || b2 == 'D' || b2 == 'H' || b2 == 'N' || b2 == '-');
			break;
		case 'N':
			return 1;
			break;
		case 'U':
			return (b2 == 'U' || b2 == 'Y' || b2 == 'K' || b2 == 'W' || b2 == 'B' || b2 == 'D' || b2 == 'H' || b2 == 'N' || b2 == '-');
			break;
		case 'R':
			return (b2 == 'A' || b2 == 'G' || b2 == 'R' || b2 == 'K' || b2 == 'M' || b2 == 'S' || b2 == 'W' || b2 == 'B' || b2 == 'D' || b2 == 'H' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'Y':
			return (b2 == 'C' || b2 == 'T' || b2 == 'U' || b2 == 'Y' || b2 == 'K' || b2 == 'M' || b2 == 'S' || b2 == 'W' || b2 == 'B' || b2 == 'D' || b2 == 'H' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'K':
			return (b2 == 'G' || b2 == 'T' || b2 == 'U' || b2 == 'R' || b2 == 'Y' || b2 == 'K' || b2 == 'S' || b2 == 'W' || b2 == 'B' || b2 == 'D' || b2 == 'H' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'M':
			return (b2 == 'A' || b2 == 'C' || b2 == 'R' || b2 == 'M' || b2 == 'S' || b2 == 'W' || b2 == 'B' || b2 == 'D' || b2 == 'H' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'S':
			return (b2 == 'C' || b2 == 'G' || b2 == 'R' || b2 == 'Y' || b2 == 'K' || b2 == 'M' || b2 == 'S' || b2 == 'B' || b2 == 'D' || b2 == 'H' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'W':
			return (b2 == 'A' || b2 == 'T' || b2 == 'U' || b2 == 'R' || b2 == 'Y' || b2 == 'K' || b2 == 'M' || b2 == 'W' || b2 == 'B' || b2 == 'D' || b2 == 'H' || b2 == 'V' || b2 == 'N' || b2 == '-');
			break;
		case 'B':
			return (b2 != 'A');
			break;
		case 'D':
			return (b2 != 'C');
			break;
		case 'H':
			return (b2 != 'G');
			break;
		case 'V':
			return (b2 != 'T' && b2 != 'U');
			break;
		case '-':
			return 1;
			break;
	}
	return 0;
}

void inline comp_seq(char* original_seq, char* new_seq, int seq_length){
	for(int i=0; i < seq_length; ++i){
		new_seq[i] = comp_base(original_seq[seq_length-1-i]);
	}
}

char inline comp_base(char b){
	switch(b){
		case 'A':
			return 'T';
			break;
		case 'C':
			return 'G';
			break;
		case 'G':
			return 'C';
			break;
		case 'T':
			return 'A';
			break;
		case 'N':
			return 'N';
			break;
		case 'U':
			return 'A';
			break;
		case 'R':
			return 'Y';
			break;
		case 'Y':
			return 'R';
			break;
		case 'K':
			return 'M';
			break;
		case 'M':
			return 'K';
			break;
		case 'S':
			return 'W';
			break;
		case 'W':
			return 'S';
			break;
		case 'B':
			return 'V';
			break;
		case 'D':
			return 'H';
			break;
		case 'H':
			return 'D';
			break;
		case 'V':
			return 'B';
			break;
		case '-':
			return '-';
			break;
	}
	return '-';
}
