/* ============================================
	kmer.cpp
 --------------------------------------------
	This is the fast C++ tool to extract kmer
	data delivered from C++ file.
 --------------------------------------------
  Version: 30.03.2016 ~Aaron
============================================*/

using namespace std;

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <tr1/unordered_map>
#include <vector>

#include "collect_sequence.h"

typedef tr1::unordered_map<string, int> ohash;
typedef tr1::unordered_map<string, vector<long int> > posis;

void search_kmers(int kmer_length, char* seq, int seq_length, ohash& kmers);
void search_kmers_with_positions(int kmer_length, char* seq, int seq_length, ohash& kmers, posis& positions);
void save_kmers(char* filename, ohash& kmers, char* seq_name, int min_hits);
void save_kmers_with_positions(char* filename, ohash& kmers, char* seq_name, posis& positions, long int* file_pointer);

int main(){
	// Mode Definitions
	const int SELECT_MODE = 0;
	const int SET_BUFFER_SIZE = 1;
	const int SET_SEQUENCE_LENGTH = 2;
	const int COLLECT_SEQUENCE = 3;
	const int SET_KMER_LENGTH = 4;
	const int SEARCH_KMER = 5;
	const int SET_OUTPUT_FILENAME = 6;
	const int SAVE_DATA = 7;
	const int CLOSE = 8;
	const int SET_SEQUENCE_NAME = 9;
	const int SET_SAVE_POSITIONS = 10;
	const int SET_MIN_HITS = 11;
	int mode = SELECT_MODE;
	
	int buffer_size = 256;
	char *buffer = NULL;
	
	char *seq = NULL;
	char *seq_name = NULL;
	long int seq_length;
	long int current_length;
	int kmer_length;
	
	ohash kmers;
	posis positions;
	char *output_filename = NULL;
	
	bool save_positions = true;
	int min_hits = 0;
	long int file_pointer = 0;
	
	buffer = new char[buffer_size];
	
	while(fgets(buffer, buffer_size, stdin)){
		
		switch(mode){
			case SELECT_MODE:
				//printf("MODE: %s\n", buffer);
				mode = atoi(buffer);
				break;
			case SET_BUFFER_SIZE:
				//printf("buffer size: %s\n", buffer);
				buffer_size = atoi(buffer);
				delete [] buffer;
				buffer = new char[buffer_size];
				mode = SELECT_MODE;
				break;
			case SET_SEQUENCE_LENGTH:
				//printf("sequence length: %s\n", buffer);
				seq_length = atoi(buffer);
				current_length = 0;
				delete [] seq;
				seq = new char[seq_length+1];
				seq[0] = '\0';
				mode = SELECT_MODE;
				break;
			case SET_SEQUENCE_NAME:
				delete [] seq_name;
				seq_name = new char[buffer_size];
				strcpy(seq_name, buffer);
				//printf("seq name: %s\n", seq_name);
				mode = SELECT_MODE;
				break;
			case COLLECT_SEQUENCE:
				//printf("buffer seq: %d %s\n", current_length, buffer);
				collect_sequence(seq, buffer);
				current_length += (buffer_size-1);
				if(current_length >= seq_length){
					mode = SELECT_MODE;
					//printf("Cellected seq of length: %d\n",current_length);
					//printf("Cellected seq: %s\n",seq);
				}
				break;
			case SET_KMER_LENGTH:
				//printf("kmer length: %s\n", buffer);
				kmer_length = atoi(buffer);
				mode = SELECT_MODE;
				break;
			case SET_MIN_HITS:
				//printf("min hits: %s\n", buffer);
				min_hits = atoi(buffer);
				mode = SELECT_MODE;
				break;
			case SET_SAVE_POSITIONS:
				save_positions = (buffer[0] == '1');
				//printf("Save Positions: %b\n", save_positions);
				mode = SELECT_MODE;
				break;
			case SEARCH_KMER:
				//printf("Search Kmers\n");
				seq[seq_length] = '\0';
				fflush(stdout);
				if(save_positions)
					search_kmers_with_positions(kmer_length, seq, seq_length, kmers, positions);
				else
					search_kmers(kmer_length, seq, seq_length, kmers);
				mode = SELECT_MODE;
				break;
			case SET_OUTPUT_FILENAME:
				fix_buffer(buffer);
				delete [] output_filename;
				output_filename = new char[buffer_size];
				strcpy(output_filename, buffer);
				//printf("filename: %s\n", output_filename);
				//file_pointer = 0;
				mode = SELECT_MODE;
				break;
			case SAVE_DATA:
				//printf("saving kmers\n");
				if(save_positions)
					save_kmers_with_positions(output_filename, kmers, seq_name, positions, &file_pointer);
				else
					save_kmers(output_filename, kmers, seq_name, min_hits);
				kmers.clear();
				positions.clear();
				mode = SELECT_MODE;
				break;
			case CLOSE:
				//printf("CLOSING");
				fflush(stdout);
				exit(0);
				break;
		}
		
		buffer[0] = '\0';
	}
	
	return 0;
}

void search_kmers(int kmer_length, char *seq, int seq_length, ohash& kmers){
	long int posi;
	char *kmer = new char[kmer_length+1];
	
	for(posi=0; posi < seq_length-kmer_length+1; ++posi){
		strncpy(kmer, seq+posi, kmer_length);
		kmer[kmer_length] = '\0';
		//printf("found: %s\n", kmer);
		++kmers[kmer];
	}
	
	delete [] kmer;
}

void search_kmers_with_positions(int kmer_length, char *seq, int seq_length, ohash& kmers, posis& positions){
	long int posi;
	char *kmer = new char[kmer_length+1];
	
	for(posi=0; posi < seq_length-kmer_length+1; ++posi){
		strncpy(kmer, seq+posi, kmer_length+1);
		kmer[kmer_length] = '\0';
		//printf("posi: %d\n", posi);
		positions[kmer].push_back(posi);
		++kmers[kmer];
	}
	
	delete [] kmer;
}

void save_kmers(char* filename, ohash& kmers, char* seq_name, int min_hits){
	FILE *out_file;
	out_file = fopen(filename, "a");
	fprintf(out_file, "$Sequence Name: %s", seq_name);
	fprintf(out_file, "Row Name\tFreuquency\n");
	for(ohash::iterator it = kmers.begin(); it != kmers.end(); ++it){
		const char *kmer = it->first.c_str();
		//printf("saving: %s %d\n", kmer, it->second);
		if(it->second >= min_hits){
			fprintf(out_file, "%s\t%d\n", kmer, it->second);
		}
	}
	fclose(out_file);
}

void save_kmers_with_positions(char* kmer_filename, ohash& kmers, char* seq_name, posis& positions, long int* file_pointer){
	FILE *kmer_out_file;
	FILE *posi_out_file;
	//kmer_out_file = fopen(kmer_filename, "a");
	// Generate posi filename
	char *posi_filename = NULL;
	posi_filename = new char[strlen(kmer_filename)+5];
	strcpy(posi_filename, kmer_filename);
	strcat(posi_filename , ".bin");
	
	int byte_size = sizeof(long int);
	long int x;
	
	kmer_out_file = fopen(kmer_filename, "a");
	posi_out_file = fopen(posi_filename, "ab");
	
	fprintf(kmer_out_file, "#SEQ: %s", seq_name);
	for(ohash::iterator it = kmers.begin(); it != kmers.end(); ++it){
		const char *kmer = it->first.c_str();
		fprintf(kmer_out_file, "%s %d -f %ld", kmer, it->second, *file_pointer);
		
		for(int i=0; i < positions[it->first].size(); ++i){
			x = positions[it->first][i];
			//printf("Sve Posi: %d %d\n", x, *file_pointer);
			fwrite(&x, byte_size, 1, posi_out_file);
			*file_pointer += byte_size;
		}
		
		fprintf(kmer_out_file," %ld\n", *file_pointer);
	}
	fclose(kmer_out_file);
	fclose(posi_out_file);
	delete [] posi_filename;
}

