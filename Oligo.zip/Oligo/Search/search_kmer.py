from subprocess import Popen, PIPE, STDOUT
import os.path
from Oligo import Prot
import Oligo
from time import sleep

def clear_kmer_file(output_filename):
    open(output_filename, 'w').close()

def change_exe_para(exe, mode_id, value):
    exe.stdin.write(str(mode_id)+'\n')
    exe.stdin.write(str(value)+'\n')

def send_sequence(exe, seq, name=None):
    if name is None:
        try:
            seq.name
        except:
            try:
                seq.id
            except:
                name = seq[0:20]
            else:
                name = seq.id
        else:
            name = seq.name
    change_exe_para(exe, 9, name)
    change_exe_para(exe, 2, len(seq))
    change_exe_para(exe, 1, 500000)
    change_exe_para(exe, 3, seq)
    change_exe_para(exe, 1, 256)
    return name

def change_k(exe, k):
    change_exe_para(exe, 4, k)

def save_results(exe, output_filename):
    # send filename
    change_exe_para(exe, 6, output_filename)
    # save to file
    exe.stdin.write("7\n")
    exe.stdin.write("\n")

def set_save_posi(exe, save):
    exe.stdin.write("10\n")
    exe.stdin.write(str(int(save))+"\n")

def cancel_exe(exe):
   exe.stdin.write('8\n')
   exe.stdin.close()
   exe.wait()

def search_kmer(data_seq, k, output_filename, data_seq_name=None, loci=None, clear_file=True, merge_loci=True, verbose=1):
    exe_path = os.path.abspath(os.path.dirname(__file__))
    exe_path = os.path.join(exe_path, './kmer.exe')
    exe = Popen(exe_path, stdin=PIPE, encoding='utf8')
    if clear_file:
        clear_kmer_file(output_filename)
    change_k(exe, k)
    set_save_posi(exe, False)
    if loci is None:
        data_seq_name = send_sequence(exe, data_seq, data_seq_name)
        if verbose:
            Prot.write('Searching '+data_seq_name+'('+str(len(data_seq))+') for kmers (k ='+str(k)+')')
        # Search kmers
        exe.stdin.write("5\n")
        exe.stdin.write("\n")
    else:
        if merge_loci:
            loci = Oligo.Loci.merge(loci)
        if data_seq_name is None:
            data_seq_name = data_seq[0:20]
        if verbose:
            Prot.write('Searching '+str(data_seq_name)+'('+str(len(data_seq))+') for kmers (k ='+str(k)+') in %s loci.' % len(loci))
        for locus in loci:
            seq = data_seq[locus.start:locus.get_end()]
            if not seq:
                Prot.warn('No sequence for locus %s found on %s (%sbp).' % (locus,data_seq_name,len(data_seq)),'Locus out of Bound')
            send_sequence(exe, seq, data_seq_name)
            # Search kmers
            exe.stdin.write("5\n")
            exe.stdin.write("\n")
    if verbose:
        Prot.write('Saving Results to '+output_filename)
    save_results(exe, output_filename)
    cancel_exe(exe)
    
def search_individual_loci_kmer(data_seq, k, output_filename, loci, data_seq_name=None, merge_loci=True, filter_loci=None, verbose=1):
    if verbose:
        Prot.write('Searching %s (%s) for kmers (k =%s) of %s individual loci.' % (data_seq_name,len(data_seq),k,len(loci)))
    spectra = []
    if not loci:
        Prot.warn('Provided Loci set for k-mer search is empty.', 'empty search set')
        Oligo.Kmer.save_kmer_spectra(output_filename, spectra)
        if verbose:
            Prot.write('Saved %s spectra to %s.' % (len(spectra), output_filename))
        return
    if merge_loci:
        loci = Oligo.Loci.merge(loci, verbose=0)
    filename = Oligo.File.generate_temp_name('.kmer')
    filename = Oligo.File.get_absolute_path(filename)
    if filter_loci is not None:
        buckets = Oligo.Loci.generate_touch_buckets(filter_loci)
    for locus in loci:
        if filter_loci is not None:
            search_loci = Oligo.Loci.get_overlap_regions([locus], buckets=buckets, verbose=0)
        else:    
            search_loci = [locus]
        if search_loci:
            search_kmer(data_seq, k, filename, data_seq_name, clear_file=True, merge_loci=False, loci=search_loci, verbose=0)
            # ensure that file exists
            i = 100
            while i > 0:
                try:
                   spectrum = Oligo.Kmer.KmerSpectrum.read(filename, k=k, verbose=0)
                   break
                except:
                    sleep(0.01)
                i -= 1
            #spectrum = Oligo.Kmer.KmerSpectrum.read(filename, k=k, verbose=0)
        else:
            spectrum = Oligo.Kmer.KmerSpectrum(kmers=[], values=[], k=k)
        spectrum.name = locus.get_id()    
        spectra.append(spectrum)    
    Oligo.File.delete_file(filename, ignore_exist=True, verbose=0)
    if output_filename is not None:
        Oligo.Kmer.save_kmer_spectra(output_filename, spectra)
    if verbose:
        if output_filename is not None:
            Prot.write('Saved %s spectra to %s.' % (len(spectra), output_filename))
        else:    
            Prot.write('Generated %s spectra.' % (len(spectra)))
    return spectra
        