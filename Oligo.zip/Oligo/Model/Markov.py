class MarkovChainTransition(object):

    def __init__(self, state1, state2, p=None, n=0):
        self.p = p
        self.n = n
        self.state1 = state1
        self.state2 = state2
        self.id = str(state1.id)+'->'+str(state2.id)
        
    def copy(self):
        return MarkovChainTransition(self.state1, self.state2, self.p, self.n)
        
    def get_p(self):
        return self.p
        
    def __str__(self):
        return '<Oligo.Model.MarkovChainTransition|%s|p=%s|n=%s>' % (self.id, self.get_p(), self.n)

class MarcovChainState(object):
    
    def __init__(self, id, name=None, transitions=None):
        self.id = id
        self.name = name
        if transitions is None:
            transitions = []
        self.transitions = transitions
        
    def __str__(self):
        return '<Oligo.Model.MarcovChainState|%s|%s|%s>' % (self.id, self.name, ','.join([str(trans) for trans in self.transitions]))

class MarcovChainModel(object):

    def __init__(self, states):
        self.states = states
    
    def create_transition_index(self, index_target_func=None, index_target_func_args=()):
        transition_index = {}
        for state in self.states:
            for transition in state.transitions:
                if index_target_func is None:
                    transition_index[transition.id] = 0
                else:
                    transition_index[transition.id] = index_target_func(*index_target_func_args)
        return transition_index
    
    def get_state(self, state_id):
        for state in self.states:
            if state.id == state_id:
                return state
        return None
        
    def get_transition(self, transition_id):
        for state in self.states:
            for transition in state.transitions:
                if transition.id == transition_id:
                    return transition
        return None
    
    def train(self, training_transitions):
        counts = self.create_transition_index()
        for transition in training_transitions:
            counts[transition.id] += transition.n
        n = sum([counts[id] for id in counts])
        for state in self.states:
            for transition in state.transitions:
                transition.p = float(counts[transition.id])/n
    
    def get_transition_ps(self):
        ps = self.create_transition_index()
        for state in self.states:
            for transition in state.transitions:
                ps[transition.id] = transition.get_p()
        return ps
    
    def get_chain_p(self, transitions):
        transition_ps = self.get_transition_ps()
        p = 1.
        for transition in transitions:
            p *= transition_ps[transition.id]
        return p
        
    def __str__(self):
        return '<Oligo.Model.MarcovChainModel|'+','.join([str(state) for state in self.states])+'>'
        