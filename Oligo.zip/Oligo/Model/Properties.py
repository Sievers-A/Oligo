import Oligo
from math import sqrt

class PropertyModel(object):

    def __init__(self, dinuc_matrix, name=None, id=None):
        self.dinuc_matrix = dinuc_matrix
        self.id = id
        self.name = name
        
    def __str__(self):
        return '%s (%s)' % (self.name, self.id)
        
    def __repr__(self):
        return '<Oligo.Model.PropertyModel|%s|%s>' % (self.id, self.name)
        
    def __eq__(self, other):
        if self.id is None or other.id is None:
            return None
        return self.id == other.id
        
    def __ne__(self, other):
        if self.id is None or other.id is None:
            return None
        return not self.id == other.id
        
    def predict(self, dinuc_values, dinuc_errors=None, relative=True, dinucs_normalized=False, sequence_length=None):
        if relative and not dinucs_normalized:
            s = sum([dinuc_values[dinuc] for dinuc in dinuc_values])
            dinuc_values = {dinuc:dinuc_values[dinuc]/s for dinuc in dinuc_values}
            if dinuc_errors:
                dinuc_errors = {dinuc:dinuc_errors[dinuc]/s for dinuc in dinuc_errors}
        elif not relative and dinucs_normalized:
            dinuc_values = {dinuc:dinuc_values[dinuc]*sequence_length for dinuc in dinuc_values}
            if dinuc_errors:
                dinuc_errors = {dinuc:dinuc_errors[dinuc]*sequence_length for dinuc in dinuc_errors}
        property_value = 0.
        err_sum = 0.
        for dinuc in dinuc_values:
            property_value += dinuc_values[dinuc]*self.dinuc_matrix[dinuc]
            if dinuc_errors:
                err_sum += (self.dinuc_matrix[dinuc]*dinuc_errors[dinuc])**2
        property_error = sqrt(err_sum)
        if dinuc_errors:
            return property_value, property_error
        return property_value
        
def read_model(id, properties_filaneme=None, verbose=1):
    if verbose:
        Oligo.Prot.write('Reading property model with ID=%s' % id)
    if properties_filaneme is None:
        properties_filaneme = Oligo.Data.get_default_properties_filename()
    data = Oligo.File.read_dat_lines(properties_filaneme, verbose=0)
    dinucs = None
    for d in data:
        line_id = int(d['ID'])
        if id == line_id:
            name = d['PropertyName']
            if dinucs is None:
                dinucs = [key for key in d.keys() if key not in ['ID','PropertyName', '']]
            dinuc_matrix = {}
            for dinuc in dinucs:
                dinuc_matrix[dinuc] = float(d[dinuc])
            model = PropertyModel(dinuc_matrix=dinuc_matrix, name=name, id=id)
            if verbose:
                Oligo.Prot.write('Found %s.' % model)
            return model
    Oligo.Prot.warn('Could not find model with ID=%s in %s.' % (id, ))
    return None
        
def read_all_models(properties_filaneme=None, verbose=1):
    if verbose:
        Oligo.Prot.write('Reading all property models.')
    if properties_filaneme is None:
        properties_filaneme = Oligo.Data.get_default_properties_filename()
    data = Oligo.File.read_dat_lines(properties_filaneme, verbose=0)
    models = []
    dinucs = None
    for d in data:
        id = int(d['ID'])
        name = d['PropertyName']
        if dinucs is None:
            dinucs = [key for key in d.keys() if key not in ['ID','PropertyName', '']]
        dinuc_matrix = {}
        for dinuc in dinucs:
            dinuc_matrix[dinuc] = float(d[dinuc])
        models.append(PropertyModel(dinuc_matrix=dinuc_matrix, name=name, id=id))
    if verbose:
        Oligo.Prot.write('Found %s models.' % (len(models)))
    return models