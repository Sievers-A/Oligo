from .locus import Locus

class Gene(Locus):

    def __init__(self, id, start, name=None, length=None, end=None, strand=None, target=None, exons=None, introns=None):
        super(Gene, self).__init__(start, length, end, strand, target)
        self.id = id
        self.name = name
        if exons is None:
            exons = []
        if introns is None:
            introns = []
        self.exons = exons
        self.introns = introns
        
    def __repr__(self):
        return '<Oligo.Gene:'+str(self.id)+'|name:'+str(self.name)+'>'    
        
    def get_id(self):
        return self.id
        
        
def save_genes_list(genes, output_filename):
    f = open(output_filename,'w')
    for gene in genes:   
        f.write(gene.get_names()[0]+'\n')
    f.close()
        
