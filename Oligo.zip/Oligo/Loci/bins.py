import Oligo
from Oligo import Prot
import datetime
import pandas
from numpy import sqrt

class Bin(object):

    def __init__(self, count, start, end, name=None, std=None):
        self.count = count
        self.start = start
        self.end = end
        if name is None:
            name = str(start)+'-'+str(end)
        self.name = name
        self.std = std
    
    def copy(self):
        return Bin(self.count, self.start, self.end, self.name, self.std)
    
    def get_bounds(self):
        return (self.start, self.end)
    
    #def __len__(self):
    #    return self.end-self.start
    
    def size(self):
        return self.end-self.start
    
    @classmethod
    def read(cls, input_filename, verbose=1):
        if verbose:
            Prot.write('Reading Bins from %s.' % input_filename)
        head_data, head_rows = Oligo.File.read_head(input_filename)
        data = pandas.read_csv(input_filename, sep='\t', skiprows=head_rows)
        bins = []
        for row in data.itertuples():
            try:
                std = row.Std
                if std == 'None' or std == '-':
                    std = None
                else:
                    std = float(std)
            except:
                std = None
            bins.append(Bin(row.Count, row.Start, row.End, std=std))
        if verbose:
            Prot.write('Found %s bins.' % len(bins))
        return bins
        
    def __repr__(self):
        if self.std is None:
            return '<Bin:'+str(self.start)+'-'+str(self.end)+'|'+str(self.count)+'>'
        else:
            return '<Bin:'+str(self.start)+'-'+str(self.end)+'|'+str(self.count)+'('+str(self.std)+')>'
         
def count_sum(bins):
    s = 0
    for bin in bins:
        s += bin.count
    return s
        
def create_dist_bins(dists, bin_bounds=None, bin_width=None, bin_start=0, bin_end=None, n_bins=None, verbose=1):
    if verbose:
        Prot.write('Creating bins for %s distances.' % len(dists))
    if bin_bounds is None:
        if bin_width is None:
            if bin_end is None:
                bin_width = float(max(dists))/n_bins
            else:
                bin_width = (bin_end-bin_start)/n_bins
        bin_bounds = []
        bin_x = bin_start
        if bin_end is None:
            bin_end = float(max(dists))
        while bin_x < bin_end:
            bin_bounds.append((bin_x, bin_x+bin_width))
            bin_x += bin_width
    bins = [Bin(0, bound[0], bound[1]) for bound in bin_bounds]
    for dist in dists:
        for bin in bins:
            if dist < bin.end:
                bin.count += 1
                break
    if verbose:
        Prot.write('Created %s bins.' % len(bins))
    return bins
    
def create_bins(values, bin_bounds=None, bin_width=None, bin_start=0, bin_end=None, n_bins=None, verbose=1):
    if verbose:
        Prot.write('Creating bins for %s values.' % len(values))
    if not values:
        Prot.warn('No values found to create bins for.', 'Empty input')
        return []
    if bin_bounds is None:
        if bin_width is None:
            if bin_end is None:
                bin_width = float(max(values))/n_bins
            else:
                bin_width = (bin_end-bin_start)/n_bins
        bin_bounds = []
        bin_x = bin_start
        if bin_end is None:
            bin_end = float(max(values))
        while bin_x <= bin_end:
            bin_bounds.append((bin_x, bin_x+bin_width))
            bin_x += bin_width
    bins = [Bin(0, bound[0], bound[1]) for bound in bin_bounds]
    for value in values:
        for bin in bins:
            if value < bin.end:
                bin.count += 1
                break
    if verbose:
        Prot.write('Created %s bins.' % len(bins))
    return bins    
    
def save_bins(bins, output_filename, head={}, verbose=1):
    if verbose:
        Prot.write('Saving %s bins to %s.' % (len(bins), output_filename))
    f = open(output_filename, 'w')
    head['date'] = datetime.datetime.now()
    Oligo.File.write_head(f, head)
    f.write('Start\tEnd\tCount\tStd\n')
    for bin in bins:
        f.write(str(bin.start)+'\t'+str(bin.end)+'\t'+str(bin.count)+'\t'+str(bin.std)+'\n')
    f.close()
    
def read_bins(input_filename, verbose=1):
    return Bin.read(input_filename, verbose)

def norm_bins(bins, verbose=1):
    if verbose:
        Prot.write('Norming %s bins.' % len(bins))
    s = float(sum([bin.count for bin in bins]))
    if s == 0:
        Prot.warn('bins.norm_bins: Sum of bin counts is zero.','empty')
    norm_bins = []
    for bin in bins:
        norm_bin = bin.copy()
        if s != 0:
            norm_bin.count /= s
            if norm_bin.std is not None:
                norm_bin.std /= s
        else:
            norm_bin.count = 0.
        norm_bins.append(norm_bin)
    if verbose:
        Prot.write('Normalized %s bins (%s --> 1.0).' % (len(bins), s))
    return norm_bins
    
def merge_bins_list(bins_list, norm=False, verbose=1):
    if verbose:
        Prot.write('Merging bins list (%s).' % len(bins_list))
    if norm:
        bins_list = [norm_bins(bins, verbose=0) for bins in bins_list]
    #print [b[0] for b in bins_list if b]
    rbins = []
    n_max = max([len(bins) for bins in bins_list])
    for i in range(n_max):
        c = 0
        start = None
        end = None
        for bins in bins_list:
            try:
                bins[i]
            except:
                pass
            else:
                if start is None:
                    start = bins[i].start
                    end = bins[i].end
                if bins[i].start != start or bins[i].end != end:
                    Prot.warn('Found Bins with unmatching boundaies while merging!','Wrong Bin Bounds')
                c += bins[i].count
        m = float(c)/len(bins_list)
        s = 0.
        for bins in bins_list:
            try:
                bins[i]
            except:
                s += m**2
            else:
                s += (m-bins[i].count)**2
        std = sqrt(s/(len(bins_list)-1.))/sqrt(len(bins_list))
        rbins.append(Bin(m, start, end, std=std))
    if verbose:
        Prot.write('Created %s bins.' % len(rbins))
    #for bin in rbins:
    #    print bin, bin.std
    return rbins
    
def residuals(bins, model_bins, verbose=1):
    rbins = []
    n_max = max(len(bins), len(model_bins))
    for i in range(n_max):
        start = None
        end = None
        c = 0
        std = None
        try:
            bins[i]
        except:
            pass
        else:
            if start is None:
                start = bins[i].start
                end = bins[i].end
            if bins[i].start != start or bins[i].end != end:
                Prot.warn('Found Bins with unmatching boundaies while calculating residuals!','Wrong Bin Bounds')
            c = bins[i].count
            std = bins[i].std
        mc = None
        mstd = None
        try:
            model_bins[i]
        except:
            pass
        else:
            if start is None:
                start = model_bins[i].start
                end = model_bins[i].end
            if model_bins[i].start != start or model_bins[i].end != end:
                Prot.warn('Found Model Bins with unmatching boundaies while calculating residuals!','Wrong Bin Bounds')
            mc = model_bins[i].count
            mstd = model_bins[i].std
        if mc is not None and mstd != 0:
            v = float(c-mc)/mstd
            if std is not None:
                std = std/mstd
            rbins.append(Bin(v, start, end, std=std))
    return rbins

def generate_coverage_bins_from_BED(input_filename, resolution, delim='\t', modifier_function=None, modifier_args=(), verbose=1):
    if verbose:
        Prot.write('Create bins (resolution = %s bp) from BED file %s.' % (resolution,input_filename))
    bins = {}
    bin_indices = {}
    f = open(input_filename, 'r')
    for line in f:
        if line[0] != '#':
            words = line.rstrip().split(delim)
            if len(words) >= 2 and words[0] != 'track':
                try:
                    chr = words[0]
                    start = int(words[1])
                    end = int(words[2])
                    name = str(words[3])
                    score = float(words[4])
                    strand = str(words[5])
                except:
                    Prot.warn('Strange Words (%s) in BED line %s.' % (words, line), 'strange value')
                    continue
                #print chr,start,end
                if modifier_function is not None:
                    #print '?'
                    chr,start,end = modifier_function(chr,start,end,name,score,strand,*modifier_args)
                
                #print chr,start,end
                posi = start
                while posi < end:
                    target_bin_start = int(posi/resolution)
                    try:
                        bin_indices[chr]
                    except:
                        bin_indices[chr] = {}
                        bins[chr] = []
                    try:
                        bin_indices[chr][target_bin_start]
                    except:
                        bin_indices[chr][target_bin_start] = len(bins[chr])
                        bin_ix = bin_indices[chr][target_bin_start]
                        bins[chr].append(Bin(1, start, start+resolution))
                    else:
                        bin_ix = bin_indices[chr][target_bin_start]
                        bins[chr][bin_ix].count += 1
                    posi += resolution
                end_bin = int(end/resolution)
                if end_bin != target_bin_start:
                    target_bin_start = end_bin
                    try:
                        bin_indices[chr]
                    except:
                        bin_indices[chr] = {}
                        bins[chr] = []
                    try:
                        bin_indices[chr][target_bin_start]
                    except:
                        bin_indices[chr][target_bin_start] = len(bins[chr])
                        bin_ix = bin_indices[chr][target_bin_start]
                        bins[chr].append(Bin(1, start, start+resolution))
                    else:
                        bin_ix = bin_indices[chr][target_bin_start]
                        bins[chr][bin_ix].count += 1                 
    f.close()
    if verbose:
        Prot.write('Created bins for %s chromosomes.' % (len(bins.keys())))
    return bins    
    
def generate_start_bins_from_BED(input_filename, resolution, delim='\t', verbose=1):
    if verbose:
        Prot.write('Create bins (resolution = %s bp) from BED file %s.' % (resolution,input_filename))
    bins = {}
    bin_indices = {}
    f = open(input_filename, 'r')
    for line in f:
        if line[0] != '#':
            words = line.rstrip().split(delim)
            if len(words) >= 2 and words[0] != 'track':
                try:
                    chr = words[0]
                    start = int(words[1])
                except:
                    Prot.warn('Strange Words (%s) in BED line %s.' % (words, line), 'strange value')
                    continue
                target_bin_start = int(start/resolution)
                try:
                    bin_indices[chr]
                except:
                    bin_indices[chr] = {}
                    bins[chr] = []
                try:
                    bin_indices[chr][target_bin_start]
                except:
                    bin_indices[chr][target_bin_start] = len(bins[chr])
                    bin_ix = bin_indices[chr][target_bin_start]
                    bins[chr].append(Bin(1, start, start+resolution))
                else:
                    bin_ix = bin_indices[chr][target_bin_start]
                    bins[chr][bin_ix].count += 1
    f.close()
    if verbose:
        Prot.write('Created bins for %s chromosomes.' % (len(bins.keys())))
    return bins    