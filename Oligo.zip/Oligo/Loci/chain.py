from locus import Locus


class Chain(Locus):

    def __init__(self, start, length=None, end=None, strand=None, target=None):
        if end is not None and end < start:
           start, end = end, start 
        self.start = start
        self.strand = strand
        if length is not None:
            self.length = length
        else:
            self.length = end-self.start
        self.target = target