import numpy as np
from .bins import Bin
from Oligo.Maps import Map
from Oligo import Prot

def coverage_mapping(loci, bins_start, bin_size):
    bins = {}
    for locus in loci:
        x = locus.start
        while x < locus.get_end():
            bin_ix = int((x-bins_start)/bin_size)
            try:
                bins[bin_ix]
            except:
                bins[bin_ix] = Bin(0.0, bin_ix*bin_size+bins_start, (bin_ix+1)*bin_size+bins_start)
            bin_end = bins[bin_ix].end
            bin_start = bins[bin_ix].start
            if x == locus.start and locus.get_end() > bin_end:
                bins[bin_ix].count += float(bin_end-locus.start)/bin_size
            elif locus.get_end() > bin_end:
                bins[bin_ix].count += 1.
            elif locus.start < bin_start:
                bins[bin_ix].count += float(locus.get_end()-bin_start)/bin_size
            else:
               bins[bin_ix].count += float(locus.length)/bin_size
            x += bin_size
        if x-bin_size < locus.get_end():
            bin_ix = int((locus.get_end()-1-bins_start)/bin_size)
            try:
                bins[bin_ix]
            except:
                bins[bin_ix] = Bin(0.0, bin_ix*bin_size+bins_start, (bin_ix+1)*bin_size+bins_start)
            bin_start = bins[bin_ix].start
            bins[bin_ix].count += float(locus.get_end()-x+bin_size)/bin_size
    #print bins
    return bins

def count_mapping(loci, bins_start, bin_size):
    bins = {}
    for locus in loci:
        x = locus.start
        while x < locus.get_end():
            bin_ix = int((x-bins_start)/bin_size)
            try:
                bins[bin_ix]
            except:
                bins[bin_ix] = Bin(0.0, bin_ix*bin_size+bins_start, (bin_ix+1)*bin_size+bin_start)
            bin_end = bins[bin_ix].end
            bin_start = bins[bin_ix].start
            if x == locus.start and locus.get_end() > bin_end:
                bins[bin_ix].count += float(bin_end-locus.start)/locus.length
            elif locus.get_end() > bin_end:
                bins[bin_ix].count += float(bin_size)/locus.length
            elif locus.start < bin_start:
                bins[bin_ix].count += float(locus.get_end()-bin_start)/locus.length
            else:
               bins[bin_ix].count += 1.
            x += bin_size
        if x-bin_size < locus.get_end():
            bin_ix = int((locus.get_end()-1-bins_start)/bin_size)
            try:
                bins[bin_ix]
            except:
                bins[bin_ix] = Bin(0.0, bin_ix*bin_size+bins_start, (bin_ix+1)*bin_size+bin_start)
            bin_start = bins[bin_ix].start
            bins[bin_ix].count += float(locus.get_end()-x+bin_size)/locus.length
    return bins

def map_loci(loci, bin_size, bin_start=0, name=None, target=None, map_func=coverage_mapping, map_func_args=()):
    if bin_size <= 0:
        Prot.error('Invalid Bin Size '+str(bin_size)+' for map_loci.')
        return None
    bins = map_func(loci, bin_start, bin_size, *map_func_args)
    map = Map(name, bin_size=bin_size, bin_start=bin_start, bins=bins)
    return map

def density_profile(loci, map, use_strain=False, range=None, sum_sides=False):
    if range is None:
        range = len(map.target)
    profile = [0.0]
    dx = 1
    while dx*map.bin_size < range:
        profile.append(0.0)
        if not sum_sides:
            profile.append(0.0)
        dx += 1
    profile = np.array(profile)
    for locus in loci:
        a = [map.get_locus_bin(locus).count]
        dx = 1
        while dx*map.bin_size < range:
            bins = map.get_neighbour_bins(locus.start, n_neighbour=dx)
            if use_strain and locus.strain == '-':
                bins[0], bins[1] = bins[1], bins[0]
            if not sum_sides:
                a = [bins[0].count]+profile+[bins[1].count]
            else:
                a = profile+[bins[1].count+bins[0].count]
            dx += 1
        profile += np.array(a)
    if not sum_sides:
        x0 = -(dx-1)*map.bin_size
    else:
        x0 = 0
    return [Bin(c, x0+i*map.bin_size, x0+(i+1)*map.bin_size) for i,c in enumerate(profile)]
