import Oligo
from Oligo import Prot
from sklearn.cluster import DBSCAN
from scipy.spatial import distance_matrix
import numpy as np

class Cluster(object):

    def __init__(self, members, id=None):
        self.members = members
        self.id = id
        
    def __len__(self):
        return len(self.members)
        
        
    def to_locus(self, target=None):
        start, end = min([locus.start for locus in self.members]), max([locus.get_end() for locus in self.members])
        locus = Oligo.Locus(start=start, end=end)
        locus.target = target
        locus.name = self.id
        return locus
    
    @classmethod
    def save(cls, clusters, output_filename, saved_features=['chromosome','start','length','strand'], verbose=1):
        if verbose:
            Prot.write('Saving %s clusters to %s.' % (len(clusters), output_filename))
        f = open(output_filename, 'w')
        f.write('\t'.join(saved_features+['cluster'])+'\n')
        for cluster in clusters:
            for locus in cluster.members:
                feature_values = [Oligo.Locus.get_save_feature(locus, feature) for feature in saved_features] + [str(cluster.id)]
                #print feature_values
                f.write('\t'.join(feature_values)+'\n')
        f.close()
    
    @classmethod
    def read(cls, input_filename, verbose=1):
        if verbose:
            Prot.write('Reading Clusters from %s.' % input_filename)
        loci = Oligo.Locus.read(input_filename)
        clusters = {}
        for locus in loci:
            for cluster_id in locus.clusters:
                try:
                    clusters[cluster_id]
                except:
                    clusters[cluster_id] = Cluster([locus], id=cluster_id)
                else:
                    clusters[cluster_id].members.append(locus)
            #print locus.clusters
        clusters = [clusters[key] for key in clusters]
        if verbose:
            Prot.write('Found %s loci in %s clusters.' % (len(loci),len(clusters)))
        return clusters
        
def db_scan(eps, min_points=2, positions=None, loci=None, distances=None, prefix='', verbose=1):
    if distances is not None:
        if verbose:
            Prot.write('Clustering %s points (eps=%s,min points=%s).' % (len(distances),eps,min_points))
        #distances = distance_matrix(distances)
        clustering = DBSCAN(eps=eps, min_samples=min_points, metric='precomputed').fit(distances)
    else:
        if positions is None:
            positions = [locus.start for locus in loci]
        if verbose:
            Prot.write('Clustering %s points (eps=%s,min points=%s).' % (len(positions),eps,min_points))
        v = np.array(positions)
        clustering = DBSCAN(eps=eps, min_samples=min_points).fit(v)
    cluster_members = {}
    for i,label in enumerate(clustering.labels_):
        if label != -1:
            #print label
            try:
                cluster_members[label]
            except:
                cluster_members[label] = []
            cluster_members[label].append(i)
    clusters = []
    for label in cluster_members:
        if loci is None:
            members = cluster_members[label]
        else:
            members = [loci[i] for i in cluster_members[label]]
        clusters.append(Cluster(id=prefix+str(label), members=members))
    return clusters
    
def save_pair_data(pairs, output_filename):
    data = []
    for pair in pairs:
        locus1 = pair[0]
        locus2 = pair[1]
        gap = Oligo.Loci.distances.interspace_distance(locus1, locus2)
        if gap.labels['overlapping']:
            overlapping = 1
        else:
            overlapping = 0
        data.append({'start1':locus1.start, 'length1':len(locus1), 'strand1':locus1.strand, 'start2':locus1.start, 'length2':len(locus2), 'strand2':locus2.strand, 'gap':str(int(gap)), 'overlapping':str(overlapping)})
    Oligo.File.save_dat_lines(output_filename=output_filename, data=data, keys=['start1','length1','strand1','start2','length2','strand2','gap','overlapping'])
