import Oligo
from .locus import Locus, length_sum, coverage_sum
import numpy as np
from Oligo import Prot

class RegulativeElement(Locus):

    def __init__(self, start, name=None, length=None, end=None, strand=None, target=None, genes=None, type=None):
        if genes is None:
            genes = []
        super(RegulativeElement, self).__init__(start, length, end, strand, target)
        self.name = name
        self.genes = genes
        self.type = type
        
    def __repr__(self):
        try:
            end = self.get_end()
        except:
            end = None
        return '<Oligo.RegulativeElement:'+str(self.start)+'..'+str(end)+'|strand:'+str(self.strand)+'-->'+','.join([gene.name for gene in self.genes])+'>'

    def get_gene_names(self):
        return [gene.name for gene in self.genes]
        
    @classmethod    
    def save(cls, res, output_filename, header=None, verbose=1):
        Locus.save(loci=res, output_filename=output_filename, header=header, saved_features=['name','target','start','length','strand','genes'], verbose=verbose)
    
    @classmethod
    def from_locus(cls, locus):
        try:
            name = locus.name
        except:
            name = None
        re = RegulativeElement(locus.start, name, len(locus), None, locus.strand, locus.target)
        try:
            re.gene_names = locus.gene_names
        except:
            re.gene_names = []
        return re
    
    @classmethod
    def read(cls, input_filename, target_genes=None, targets=None, verbose=1):
        loci = Locus.read(input_filename, verbose=verbose)
        res = [RegulativeElement.from_locus(locus) for locus in loci]
        if targets is None:
            targets = Oligo.File.read_human_genome()
        target_genes_index = {}
        for target in targets:
            try:
                target_genes_index[target.name]
            except:
                target_genes_index[target.name] = {}
                if target_genes is None:
                    target_genes_target = Oligo.File.read_genes(chromosome=target)
                else:
                    target_genes_target = target_genes[target.name]
                for gene in target_genes_target:
                    names = gene.get_names()
                    for name in names:
                        target_genes_index[target.name][name] = gene   
        if verbose:
            Prot.write('Adding Genes to Regulators.')
        #print target_genes_index
        for re in res:
            genes = []
            for gene_name in re.gene_names:
                for target_name in target_genes_index.keys(): # allowing also trans regulation
                    try:
                        target_genes_index[target_name][gene_name]
                    except:
                        pass
                    else:
                        genes.append(target_genes_index[target_name][gene_name])
                        break
            re.genes = genes
            del re.gene_names
        if verbose:
            Prot.write('Read %s Regulators from %s.' % (len(res), input_filename))
        return res
        
        
def basic_stats(res, verbose=1):
    loci = res
    n = len(loci)
    sum = length_sum(loci)
    c_sum = coverage_sum(loci)
    overlap = sum-c_sum
    lengths = [len(locus) for locus in loci]
    starts = [locus.start for locus in loci]
    ends = [locus.get_end() for locus in loci]
    n_genes = [len(locus.genes) for locus in loci]
    n_with_genes = len([1 for x in n_genes if x != 0])
    if loci:
        min_start, max_end = min(starts), max(ends)
        n_density = float(n)/(max_end-min_start)
        c_density = float(c_sum)/(max_end-min_start)
    else:
        min_start, max_end = None, None
        n_density = None
        c_density = None
    if verbose:
        Prot.write('Basic Stats for %s Regulators:' % n)
        Prot.write('n = %s' % n)
        Prot.write('sum = %sbp' % sum)
        Prot.write('coverage sum = %sbp' % c_sum)
        Prot.write('mean length = %sbp' % np.mean(lengths))
        Prot.write('std length = %sbp' % np.std(lengths))
        Prot.write('range = %s-%s' % (min_start,max_end))
        Prot.write('n density = %s' % n_density)
        Prot.write('cov. density = %s' % c_density)
        Prot.write('mean regulated genes = %s' % np.mean(n_genes))
        Prot.write('std regulated genes = %s' % np.std(n_genes))
        Prot.write('Regulators w genes = %s (%s%%)' % (n_with_genes,round(100*n_with_genes/float(n))))
        
def get_regulated_genes(res, verbose=1):
    if verbose:
        Prot.write('Collect Regulated Genes from %s Regulators.' % len(res))
    genes_dict = {}
    for re in res:
        for gene in re.genes:
            genes_dict[gene.name] = gene
    genes = [genes_dict[key] for key in genes_dict]
    if verbose:
        Prot.write('Extracted %s genes.' % len(genes))
    return genes
        
        
