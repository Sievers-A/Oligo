import datetime
import pandas
import Oligo
from Oligo import Prot
import random
import numpy as np
from scipy.stats import binom
import re

class Locus(object):

    def __init__(self, start, length=None, end=None, strand=None, target=None):
        if end is not None and end < start:
           start, end = end, start
        self.start = start
        self.strand = strand
        if length is not None:
            self.length = length
        else:
            self.length = end-self.start
        self.target = target

    def get_id(self):
        return str(self.start)+'..'+str(self.get_end())

    def get_name(self):
        try:
            self.name
        except:
            return None
        else:
            return self.name

    def get_values(self):
        try:
            self.values
        except:
            return {}
        else:
            return self.values

    def get_value(self, id):
        try:
            self.values[id]
        except:
            return None
        return self.values[id]

    def set_value(self, id, value):
        try:
            self.values
        except:
            self.values = {id:value}
        else:
            self.values[id] = value

    def __len__(self):
        return self.length

    def __eq__(self, other):
        if isinstance(other, Locus) and other.start == self.start and other.length == self.length and other.strand == self.strand:
            return True
        return False

    def __ne__(self, other):
        return not self == other

    def __repr__(self):
        try:
            end = self.get_end()
        except:
            end = None
        return '<Oligo.Locus:'+str(self.start)+'..'+str(end)+'|strand:'+str(self.strand)+'>'

    def get_end(self):
        return self.start+self.length

    def get_sequence(self):
        return self.target.get_seq()[self.start:self.start+self.length]

    def get_seq(self):
        return self.get_sequence()

    def get_overlap(self, locus):
        start = max(self.start, locus.start)
        end = min(self.get_end(), locus.get_end())
        if end > start:
            return start, end
        return None, None

    def check_overlap(self, locus):
        o_start, o_end = self.get_overlap(locus)
        return o_start is not None

    def get_labels(self):
        try:
            self.labels
        except:
            return []
        return self.labels

    @classmethod
    def get_save_feature(cls, locus, feature_name):
        if feature_name == 'start':
            return str(locus.start)
        if feature_name == 'end':
            return str(locus.start+locus.length)
        if feature_name == 'length':
            return str(locus.length)
        if feature_name == 'strand':
            if locus.strand is None:
                return '?'
            return str(locus.strand)
        if feature_name == 'name':
            try:
                return str(locus.name)
            except:
                return 'Loc'
        if feature_name == 'labels':
            return ','.join([str(label) for label in locus.get_labels()])
        if feature_name == 'id':
            try:
                return str(locus.id)
            except:
                return '?'
        if feature_name == 'sequence':
            return locus.get_sequence()
        if feature_name == 'chromosome' or feature_name == 'target':
            return str(locus.target)
        if feature_name == 'genes':
            return ','.join(locus.get_gene_names())

    @classmethod
    def save(cls, loci, output_filename, header=None, default_features=None, saved_features=['start','length','strand'], verbose=1):
        if verbose:
            Prot.write('Saving %s loci to %s.' % (len(loci), output_filename))
        f = open(output_filename,'w')
        f.write('#date:\t'+str(datetime.datetime.now())+'\n')
        if header:
            for key in header:
                f.write('#'+str(key)+':\t'+str(header[key])+'\n')
        if default_features:
            for key in features:
                f.write('$'+str(key)+':\t'+str(features[key])+'\n')
        f.write('\t'.join(saved_features)+'\n')
        for locus in loci:
            feature_values = [cls.get_save_feature(locus, feature) for feature in saved_features]
            f.write('\t'.join(feature_values)+'\n')
        f.close()

    @classmethod
    def save_to_bed(cls, loci, output_filename, translate_func=None, translate_func_args=(), verbose=1):
        if verbose:
            Prot.write('Saving %s loci to %s.' % (len(loci), output_filename))
        if translate_func is None:
            translate_func = cls.translate_locus_to_BED
        f = open(output_filename,'w')
        keys = None
        for locus in loci:
            bed_data = translate_func(locus, *translate_func_args)
            #print locus.get_values()
            line = bed_data['chrom']+'\t'+str(bed_data['chromStart'])+'\t'+str(bed_data['chromEnd'])
            if keys is None:
                keys = bed_data.keys()
            if 'name' in keys:
                line += '\t'+str(bed_data['name'])
                if 'score' in keys:
                    line += '\t'+str(bed_data['score'])
                    if 'strand' in keys:
                        line += '\t'+str(bed_data['strand'])
                        if 'thickStart' in keys:
                            line += '\t'+str(bed_data['thickStart'])
                            if 'thickEnd' in keys:
                                line += '\t'+str(bed_data['thickEnd'])
                                if 'itemRgb' in keys:
                                    line += '\t'+bed_data['itemRgb']
                                    if 'blockCount' in keys:
                                        line += '\t'+str(bed_data['blockCount'])
                                        line += '\t'+str(bed_data['blockSizes'])
                                        line += '\t'+str(bed_data['blockStarts'])
            f.write(line+'\n')
        f.close()
    
    @classmethod
    def save_to_bedgrapgh(cls, loci, output_filename, verbose=1):
        if verbose:
            Prot.write('Saving %s loci to %s.' % (len(loci), output_filename))
        translate_func = cls.translate_locus_to_BED
        f = open(output_filename,'w')
        for locus in loci:
            bed_data = translate_func(locus)
            line = bed_data['chrom']+'\t'+str(bed_data['chromStart'])+'\t'+str(bed_data['chromEnd'])
            line += '\t'+str(bed_data['score'])
            f.write(line+'\n')
        f.close()
          
    @classmethod
    def translate_locus_to_BED(cls, locus):
        #bed_data = {}
        bed_data = locus.get_values()
        try:
            bed_data['chrom']
        except:
            try:
                bed_data['chr']
            except:            
                if locus.target is not None:
                    bed_data['chrom'] = 'chr'+str(locus.target.name[1:])
            else:
                bed_data['chrom'] = bed_data['chr']
        bed_data['chromStart'] = locus.start
        bed_data['chromEnd'] = locus.get_end()
        if locus.strand is not None:
            bed_data['strand'] = str(locus.strand)
        else:
            bed_data['strand'] = '.'
        try:
            locus.name
        except:
            bed_data['name'] = locus.get_id()
        else:
            bed_data['name'] = locus.name
        return bed_data

    @classmethod
    def get_default(cls, key, default_values, data, trans_func=None, trans_func_para=()):
        try:
            data[key]
        except:
            try:
                default_values[key]
            except:
                return None
            if trans_func is not None:
                return trans_func(default_values[key], *trans_func_para)
            else:
                return default_values[key]
        if trans_func is not None:
            return trans_func(data[key], *trans_func_para)
        else:
            return data[key]
            
    @classmethod
    def get_default_old(cls, key, default_values, data, trans_func=None, trans_func_para=()):
        try:
            getattr(data, key)
            #data[key]
        except:
            try:
                default_values[key]
            except:
                return None
            if trans_func is not None:
                return trans_func(default_values[key], *trans_func_para)
            else:
                return default_values[key]
        if trans_func is not None:
            return trans_func(getattr(data, key), *trans_func_para)
        else:
            return getattr(data, key)

    @classmethod
    def translate_data(cls, data, default_values, chromos):
        start = cls.get_default('start', default_values, data, save_int)
        if start is None:
            start = cls.get_default('location', default_values, data, save_int)
            if start is None:
                start = cls.get_default('position', default_values, data, save_int)
        length = cls.get_default('length', default_values, data, save_int)
        end = cls.get_default('end', default_values, data, save_int)
        seq = cls.get_default('seq', default_values, data)
        mm = cls.get_default('missmatches', default_values, data)
        name = cls.get_default('name', default_values, data)
        labels = cls.get_default('labels', default_values, data)
        if mm is None:
            mm = cls.get_default('number of missmatches', default_values, data)
        clusters = cls.get_default('cluster', default_values, data, lambda c : c.split(','))
        try:
            gene_names = cls.get_default('genes', default_values, data, lambda c : c.split(','))
        except:
            gene_names = None
        strand = cls.get_default('strand', default_values, data)
        if strand in [1,'1','+']:
            strand = '+'
        elif strand in [-1,'-1','-']:
            strand = '-'
        target = cls.get_default('target', default_values, data)
        if target is None:
            target = cls.get_default('chromosome', default_values, data)
        #chromos = {}
        if target is not None:
            try:
                chromos[target]
            except:
                chromos[target] = Oligo.File.read_chromosome(target)
            target = chromos[target]
        if length is None and end is None:
            chain_seed_length = cls.get_default('chain seed length', default_values, data, int)
            repetitions = cls.get_default('repetitions', default_values, data, int)
            length = chain_seed_length*repetitions
            if strand is None:
                strand = '+'
        locus = Locus(start, length, end, strand, target)
        if mm is not None:
            locus.mm = mm
        if clusters is not None:
            locus.clusters = clusters
        if gene_names is not None:
            locus.gene_names = gene_names
        if name is not None:
            locus.name = name
        if labels is not None:
            locus.labels = labels.split(',')
        return locus

    @classmethod
    def read(cls, input_filename, target=None, verbose=1):
        if verbose:
            Oligo.Prot.write('Reading Loci Data from '+str(input_filename))
        head_data, head_rows = Oligo.File.read_head(input_filename)
        data = Oligo.File.read_dat_lines(input_filename, verbose=0)#pandas.read_csv(input_filename, sep='\t', skiprows=head_rows)
        loci = []
        if verbose:
            Oligo.Prot.write('Found '+str(len(data))+' entries.')
            Oligo.Prot.write('Translating Data to loci.')
        #for row in data.itertuples():
        targets = {}
        for row in data:
            locus = cls.translate_data(row, head_data, targets)
            loci.append(locus)
        if target is not None:
            for locus in loci:
                locus.target = target
        if verbose:
            Oligo.Prot.write('Read '+str(len(loci))+' Loci (sum=%sbp).' % length_sum(loci))
        return loci
    
    @classmethod
    def read_bedgraph(cls, input_filename, filter_func=None, filter_args=(), seqs_filename=None, delim='\t', split_by_chrom=True, verbose=1):
        loci = cls.read_bed2(input_filename, filter_func=filter_func, filter_args=(), seqs_filename=None, delim='\t', split_by_chrom=True, verbose=1)
        if split_by_chrom:
            for target in loci:
                for locus in loci[target]:
                    locus.set_value('score', float(locus.name))
                    del locus.name
        else:
            for locus in loci:
                locus.set_value('score', float(locus.name))
                del locus.name
        return loci
    
    @classmethod
    def read_bed2(cls, input_filename, filter_func=None, filter_args=(), seqs_filename=None, delim='\t', split_by_chrom=True, verbose=1):
        if seqs_filename is None:
            seqs_filename = Oligo.Data.get_default_seqs_filename()
        if verbose:
            Oligo.Prot.write('Reading Loci Data from '+str(input_filename))
        loci = []
        f = open(input_filename, 'r')
        for line in f:
            if line[0] == '#':
                continue
            if line[0:5] != 'track':
                words = line.rstrip().split(delim)
                if filter_func is not None and not filter_func(words, *filter_args):
                    continue
                #print words, line
                try:
                    chrom,chromStart,chromEnd = words[0], int(words[1]), int(words[2])
                except:
                    words = line.rstrip().split(' ')
                    chrom,chromStart,chromEnd = words[0], int(words[1]), int(words[2])
                    #Oligo.Prot.warn('Problem execuing row "%s" in %s.' % (line, input_filename), 'Strange Value')
                    #continue
                name, score, strand, thickStart, thickEnd, itemRGB, blockCount, blockSizes, blockStarts = None,None,None,None,None,None,None,None,None
                values = {}
                values['chrom'] = chrom
                if len(words) > 3:
                    name = words[3]
                    if len(words) > 4:
                        score = float(words[4])
                        values['score'] = score
                        if len(words) > 5:
                            if words[5] != '.':
                                strand = words[5]
                            if len(words) > 6:
                                thickStart = int(words[6])
                                thickEnd = int(words[7])                             
                                values['thickStart'] = thickStart
                                values['thickEnd'] = thickEnd
                                if len(words) > 8:
                                    itemRGB = words[8]
                                    values['itemRGB'] = itemRGB
                                    if len(words) > 9:
                                        blockCount = int(words[9])
                                        blockSizes = [int(x) for x in ','.split(words[10])]
                                        blockStarts = [int(x) for x in ','.split(words[11])]
                                        values['blockCount'] = blockCount
                                        values['blockSizes'] = blockSizes
                                        values['blockStarts'] = blockStarts
                target = None
                locus = Locus(start=chromStart, end=chromEnd, target=target, strand=strand)
                locus.values = values
                if name:
                    locus.name = name
                loci.append(locus)
        f.close()
        if split_by_chrom:
            chrom_loci = {}
            for locus in loci:
                chrom = locus.get_value('chrom')
                try:
                    chrom_loci[chrom]
                except:
                    chrom_loci[chrom] = []
                chrom_loci[chrom].append(locus)
            if verbose:
                Oligo.Prot.write('Read '+str(len(loci))+' Loci, split to %s Chroms.' % (len(chrom_loci.keys())))
            return chrom_loci
        else:
            if verbose:
                Oligo.Prot.write('Read '+str(len(loci))+' Loci.')
            return loci
    
    @classmethod
    def read_bed(cls, input_filename, filter_func=None, filter_args=(), seqs_filename=None, verbose=1):
        if seqs_filename is None:
            seqs_filename = Oligo.Data.get_default_seqs_filename()
        if verbose:
            Oligo.Prot.write('Reading Loci Data from '+str(input_filename))
        data = pandas.read_csv(input_filename, sep='\t', names=['chrom', 'ChromStart', 'ChromEnd', 'name', 'score', 'strand', 'thickStart', 'thickEnd', 'itemRgb', 'blockCount', 'blockSizes', 'blockStarts'], index_col=False, dtype=str)
        loci = []
        if verbose:
            Oligo.Prot.write('Found '+str(len(data))+' entries.')
            Oligo.Prot.write('Translating Data to loci.')
        for row in data.itertuples():
            #target = Oligo.File.read_chromosome('Homo sapiens c'+row.chromosome[3:], seqs_filename=seqs_filename)
            target = None
            try:
                start = int(row.ChromStart)
            except:
                continue
            end = int(row.ChromEnd)
            if row.strand == '+' or row.strand == '1':
                strand = '+'
            elif row.strand == '-' or row.strand == '-1':
                strand = '-'
            else:
                strand = None
            locus = Locus(start=start, end=end, target=target, strand=strand)
            if row.name:
                locus.name = row.name
            values = {'chrom':row.chrom}

            if not pandas.isnull(row.score):
                values['score'] = float(row.score)
            if not pandas.isnull(row.thickStart):
                values['thickStart'] = int(row.thickStart)
            if not pandas.isnull(row.thickEnd):
                values['thickEnd'] = int(row.thickEnd)
            if not pandas.isnull(row.itemRgb):
                values['itemRgb'] = str(row.itemRgb)
            if not pandas.isnull(row.blockCount):
                values['blockCount'] = int(row.blockCount)
                values['blockSizes'] = [int(x) for x in ','.split(row.blockSizes)]
                values['blockStarts'] = [int(x) for x in ','.split(row.blockSizes)]
            if values:
                locus.values = values
            if filter_func is None or filter_func(locus, row, *filter_args):
                loci.append(locus)
        if verbose:
            Oligo.Prot.write('Read '+str(len(loci))+' Loci (sum=%sbp).' % length_sum(loci))
        return loci

    @classmethod
    def read_repeatmasker(cls, input_filename, filter_func=None, filter_args=(), target=None, verbose=1):
        if verbose:
            Prot.write('Reading loci from %s.' % input_filename)
        loci = []
        file = open(input_filename,'r')
        line_n = 0
        for line in file:
            if line_n > 2:
                line = re.sub("[ ]{1,}", "\t", line)
                if line[0:1] == '\t':
                    words = line.rstrip("\n").split("\t")[1:]
                else:
                    words = line.rstrip("\n").split("\t")
                if filter_func == None or filter_func(words, *filter_args):
                    name = words[9]
                    start = int(words[5])-1
                    end = int(words[6])
                    strand = words[8]
                    locus = Locus(start=start, end=end, target=target, strand=strand)
                    locus.name = name
                    locus.set_value('chr', words[4])
                    locus.set_value('class/family', words[10])
                    locus.set_value('score', int(words[0]))
                    locus.set_value('div.', float(words[1]))
                    locus.set_value('del.', float(words[2]))
                    locus.set_value('ins.', float(words[3]))
                    loci.append(locus)
            line_n += 1
        file.close()
        if verbose:
            Prot.write('Found %s loci.' % len(loci))
        return loci

    @classmethod
    def read_pwm_resuls(cls, input_filename, verbose=1):
        if verbose:
            Oligo.Prot.write('Reading Loci Data from '+str(input_filename))
        loci = []
        data = Oligo.File.read_dat_lines(input_filename, col_names=['target','start','end','sequence','score','strand','name','info'])
        for line in data:
            start = int(line['start'])
            end = int(line['end'])
            target = line['target']
            strand = line['strand']
            name = line['name']
            p_value = float(line['info'].split('=')[-1])
            locus = Locus(start=start, end=end, target=target, strand=strand, name=name)
            locus.p_value = p_value
            loci.append(locus)
        if verbose:
            Oligo.Prot.write('Read '+str(len(loci))+' Loci (sum=%sbp).' % length_sum(loci))
        return loci

    @classmethod
    def read_old_genes(cls, input_filename, target=None, verbose=1):
        if verbose:
            Oligo.Prot.write('Reading Loci Data from '+str(input_filename))
        loci = []
        f = open(input_filename,'r')
        for line in f:
            words = line.rstrip("\n").split("\t")
            gene = words
            fail = False
            try:
                gene[1] = int(gene[1])
            except:
                fail = True
            try:
                gene[2] = int(gene[2])
            except:
                fail = True
            if len(gene) > 3:
                try:
                    gene[3] = int(gene[3])
                except:
                    fail = True
            else:
                gene.append(None)
            if not fail:
                loci.append(Locus(start=gene[1], end=gene[2], target=target, strand=gene[3], name=gene[0]))
        f.close()
        if verbose:
            Oligo.Prot.write('Read '+str(len(loci))+' Loci (sum=%sbp).' % length_sum(loci))
        return loci

    @classmethod
    def from_data(cls, data, translate_func, translate_func_args=(), verbose=1):
        loci = []
        if verbose:
            Prot.write('Translate data (%s lines) to Loci.' % (len(data)))
        not_found = 0
        for line in data:
            locus = translate_func(line, *translate_func_args)
            if locus is not None:
                loci.append(locus)
            else:
                not_found += 1
        if verbose:
            Prot.write('Translated to %s loci (not translated %s).' % (len(loci), not_found))
        return loci
        
    def get_names(self):
        try:
            self.alt_names
        except:
            return [self.name]
        return [self.name]+self.alt_names

class Buckets(object):

    def __init__(self, bucket_size, offset=0):
        self.buckets = {}
        self.bucket_size = bucket_size
        if offset is None:
            offset = 0
        self.offset = offset

    def __len__(self):
        return len(self.buckets.keys())

    def calculate_bucket_key(self, value):
        return int((value+self.offset)/self.bucket_size)

    def get_bucket_limits(self, key):
        start = key*self.bucket_size-self.offset
        end = start+self.bucket_size
        return start, end

    def get_keys(self):
        return sorted(self.buckets.keys())

    def get_last_key(self):
        return self.get_keys()[-1]

    def get_first_key(self):
        return self.get_keys()[0]

    def add_to_bucket(self, object, value=None, key=None):
        if key is None:
            bucket_key = self.calculate_bucket_key(value)
        else:
            bucket_key = key
        try:
            self.buckets[bucket_key]
        except:
            self.buckets[bucket_key] = [object]
        else:
            self.buckets[bucket_key].append(object)

    def get_bucket(self, bucket_key=None, value=None):
        if bucket_key is None:
            bucket_key = self.calculate_bucket_key(value)
        try:
            self.buckets[bucket_key]
        except:
            return []
        else:
            return self.buckets[bucket_key]

    def get_distance_buckets(self, x, dx):
        if dx > 0:
            return self.get_bucket(x-dx)+self.get_bucket(x+dx)
        else:
            return self.get_bucket(x)

    def check_overlap(self, object, value=None, key=None):
        if key is None:
            key = self.calculate_bucket_key(value)
        objects = self.get_distance_buckets(key, 0)
        for o in objects:
            if o.check_overlap(object):
                return True
        self.get_distance_buckets(key, 1)
        for o in objects:
            if o.check_overlap(object):
                return True
        return False
        
    def get_touched_buckets(self, start_value, end_value):
        last_key = self.get_last_key()
        touched_buckets = []
        key = self.calculate_bucket_key(start_value)
        while key <= last_key: 
            bucket_start_value, bucket_end_value = self.get_bucket_limits(key)
            if bucket_start_value > end_value:
                return touched_buckets
            touched_buckets.append(self.get_bucket(key))
            key += 1
        return touched_buckets

def generate_start_buckets(loci, bucket_size=100000, verbose=0):
    if verbose:
        Oligo.Prot.write('Generating Loci Start-Position-Buckets (bucket_size:%sbp)' % bucket_size)
    buckets = Buckets(bucket_size)
    for locus in loci:
        buckets.add_to_bucket(locus, locus.start)
    if verbose:
        Oligo.Prot.write('Added %s Loci to %s buckets.' % (len(loci), len(buckets)))
    return buckets

def generate_end_buckets(loci, bucket_size=100000, verbose=0):
    if verbose:
        Oligo.Prot.write('Generating Loci End-Position-Buckets (bucket_size:%sbp)' % bucket_size)
    buckets = Buckets(bucket_size)
    for locus in loci:
        buckets.add_to_bucket(locus, locus.get_end())
    if verbose:
        Oligo.Prot.write('Added %s Loci to %s buckets.' % (len(loci), len(buckets)))
    return buckets

def generate_touch_buckets(loci, bucket_size=10000, verbose=1):
    if verbose:
        Oligo.Prot.write('Generating Touch-Buckets (bucket_size%sbp) for %s loci.' % (bucket_size, len(loci)))
    buckets = Buckets(bucket_size)
    for locus in loci:
        posi = locus.start
        locus_end = locus.get_end()
        key = None
        while posi < locus_end:
            key = buckets.calculate_bucket_key(posi)
            buckets.add_to_bucket(locus, key=key)
            posi += bucket_size
        end_key = buckets.calculate_bucket_key(locus_end)
        if key != end_key:
            buckets.add_to_bucket(locus, key=end_key)
    if verbose:
        Oligo.Prot.write('Added %s Loci to %s buckets.' % (len(loci), len(buckets)))
    return buckets

def generate_main_buckets(loci, bucket_size=10000, verbose=1):
    if verbose:
        Oligo.Prot.write('Generating Main-Buckets (bucket_size%sbp) for %s loci.' % (bucket_size, len(loci)))
    buckets = Buckets(bucket_size)
    for locus in loci:
        if len(locus) == 0:
            locus.length = 1
        posi = locus.start
        locus_end = locus.get_end()
        max_overlap_key = None
        max_overlap = 0
        while posi < locus_end:
            key = buckets.calculate_bucket_key(posi)
            start, end = buckets.get_bucket_limits(key)
            overlap_start, overlap_end = locus.get_overlap(Locus(start=start,end=end))
            overlap = overlap_end-overlap_start
            if overlap > max_overlap or max_overlap_key is None:
                max_overlap = overlap
                max_overlap_key = key
            posi += bucket_size
        #if max_overlap_key is None and len(locus) == 0:
        #    Oligo.Prot.warn('Cannot add locus of size zero %s to main buckets','Zero Size Locus')
        #else:
        buckets.add_to_bucket(locus, key=max_overlap_key)
    if verbose:
        Oligo.Prot.write('Added %s Loci to %s buckets.' % (len(loci), len(buckets)))
    return buckets

def generate_random_loci(n=100, start_range=(0,10000), length_range=(1,10), allow_overlap=True, prevent_loci=None, bucket_size=100000, verbose=1):
    if verbose:
        Oligo.Prot.write('Generating %s random loci.' % n)
    loci = [Locus(start=0, length=random.randint(length_range[0], length_range[1]), strand=np.random.choice(['+','-'])) for i in range(n)]
    shuffle(loci, boundaries=start_range, allow_overlap=allow_overlap, prevent_loci=prevent_loci, bucket_size=bucket_size, verbose=0)
    return loci

def shuffle(loci, boundaries=(0, None), allow_overlap=True, prevent_loci=None, bucket_size=100000, verbose=0):
    if prevent_loci is None:
        prevent_loci = []
    prevent_buckets = generate_start_buckets(prevent_loci, bucket_size, verbose)
    for locus in loci:
        accepted = False
        while not accepted:
            if boundaries[1] is None:
                locus.start = random.randint(boundaries[0], len(loci[0].target)-len(locus))
            else:
                locus.start = random.randint(boundaries[0], boundaries[1]-len(locus))
            accepted = not prevent_buckets.check_overlap(locus, locus.start)
        if not allow_overlap:
            prevent_buckets.add_to_bucket(locus, locus.start)

def shift(loci, shift_value, upper_bound=None, circle=False, verbose=0):
    for locus in loci:
        if upper_bound is None:
            upper_bound = len(locus.target)
        locus.start += shift_value
        if circle and locus.start >= upper_bound:
            locus.start -= upper_bound

def length_sum(loci):
    return sum([locus.length for locus in loci])

def remove_overlap(loci, verbose=1):
    if verbose:
        Oligo.Prot.write('Removing overlap from %s loci (sum=%s).' % (len(loci), length_sum(loci)))
    n = 0
    if not loci:
        return []
    loci = sorted(loci, key=lambda l: l.start)
    new_loci = [loci[0]]
    for locus in loci:
        if locus.check_overlap(new_loci[-1]):
            if locus.strand == new_loci[-1].strand:
                new_strand = locus.strand
            else:
                new_strand = None
            new_start = min(locus.start, new_loci[-1].start)
            new_end = max(locus.get_end(), new_loci[-1].get_end())
            new_loci[-1] = Locus(start=new_start, end=new_end, strand=new_strand, target=new_loci[-1].target)
            n += 1
        else:
            new_loci.append(Locus(start=locus.start, length=locus.length, strand=locus.strand, target=locus.target))
    if verbose:
        Oligo.Prot.write('Removed %s overlaps. %s loci (sum=%s) remaining.' % (n,len(new_loci),length_sum(new_loci)))
    return new_loci

def coverage_sum(loci):
    return length_sum(remove_overlap(loci))

def get_borders_as_loci(loci):
    border_loci = []
    for locus in loci:
        if locus.strand is None:
            s1 = 1
            s2 = 0
        else:
            s1 = locus.strand
            s2 = -locus.strand
        border_locus1 = Locus(start=locus.start ,length=1, target=locus.target, strand=s1)
        border_locus2 = Locus(start=locus.get_end()-1 ,length=1, target=locus.target, strand=s2)
        border_loci.append(border_locus1)
        border_loci.append(border_locus2)
    return border_loci

def get_centers_as_loci(loci):
    center_loci = []
    for locus in loci:
        if locus.strand is None:
            s = 1
        else:
            s = locus.strand
        center_locus = Locus(start=locus.start+len(locus)/2 ,length=1, target=locus.target, strand=s)
        center_loci.append(center_locus)
    return center_loci

def merge(loci, verbose=1):
    if verbose:
        Prot.write('Merging %s loci.' % len(loci))
    loci = sorted(loci, key=lambda locus: locus.start)
    if len(loci) == 0:
        Prot.warn('Merged Empty set of loci in locus.merge().','Empty Data')
        return []
    merged_loci = [loci[0]]
    for i in range(1,len(loci)):
        locus1 = merged_loci[-1]
        locus2 = loci[i]
        locus1_end = locus1.get_end()
        locus2_end = locus2.get_end()
        if locus1.check_overlap(locus2) or max(locus1.start,locus2.start) == min(locus1_end, locus2_end):
            start = min(locus1.start,locus2.start)
            end = max(locus1_end,locus2_end)
            if locus1.strand == locus2.strand:
                strand = locus1.strand
            else:
                strand = None
            if locus1.target == locus2.target:
                target = locus1.target
            else:
                target = None
            merged_loci[-1] = Locus(start=start, end=end, strand=strand, target=target)
        else:
            merged_loci.append(locus2)
    if verbose:
        Prot.write('Merged to %s loci.' % len(merged_loci))
    return merged_loci

def invert(loci, boundaries=None, verbose=1):
    if verbose:
        Prot.write('Inverting %s loci.' % len(loci))
    if boundaries is None:
        boundaries = [0, max([locus.get_end() for locus in loci])]
    loci = merge(loci, verbose=verbose)
    inv_loci = []
    posi = boundaries[0]
    for locus in loci:
        if posi < boundaries[1]:
            if posi < locus.start:
                inv_loci.append(Locus(start=posi, end=locus.start))
            posi = locus.get_end()
        else:
            break
    if posi < boundaries[1]:
        inv_loci.append(Locus(start=posi, end=boundaries[1]))
    if verbose:
        Prot.write('Created %s inverted Loci.' % len(inv_loci))
    return inv_loci

def substract(loci1, loci2, verbose=1):
    if verbose:
        Prot.write('Substracting %s loci from %s loci.' % (len(loci2),len(loci1)))
    loci2 = merge(loci2)
    dif_loci = []
    for locus1 in loci1:
        posi = locus1.start
        locus1_end = locus1.get_end()
        for locus2 in loci2:
            if locus2.start >= locus1_end:
                break
            locus2_end = locus2.get_end()
            if locus2_end >= posi:
                if posi <= locus2.start:
                    if posi < locus2.start:
                        dif_loci.append(Locus(start=posi, end=locus2.start, strand=locus1.strand, traget=locus1.target))
                    posi = locus2_end
                if posi <= locus2_end:
                    posi = locus2_end
                if posi >= locus1_end:
                    break
        if posi < locus1_end:
            dif_loci.append(Locus(start=posi, end=locus1_end, strand=locus1.strand, traget=locus1.target))
    if verbose:
        Prot.write('Created %s difference loci' % len(dif_loci))
    return dif_loci

def check_overlaps(loci1, loci2):
    for locus1 in loci1:
        for locus2 in loci2:
            if locus1.check_overlap(locus2):
                return True
    return False

def create_length_model(loci=None, lengths=None, min_length=1, verbose=1):
    if verbose:
        if loci is not None:
            Prot.write('Creating Length Model for %s loci' % (len(loci)))
        else:
            Prot.write('Creating Length Model for %s lengths' % (len(lengths)))
    state1 = Oligo.Model.Markov.MarcovChainState('occupied')
    state2 = Oligo.Model.Markov.MarcovChainState('free')
    state1.transitions.append(Oligo.Model.Markov.MarkovChainTransition(state1, state1))
    state1.transitions.append(Oligo.Model.Markov.MarkovChainTransition(state1, state2))
    model = Oligo.Model.Markov.MarcovChainModel([state1, state2])
    # Train Model
    if lengths is None:
        lengths = [len(locus) for locus in loci]
    t1, t2 = Oligo.Model.Markov.MarkovChainTransition(state1, state1), Oligo.Model.Markov.MarkovChainTransition(state1, state2)
    t2.n = len(lengths)
    for length in lengths:
        t1.n += length-min_length
    model.train([t1,t2])
    return model

def basic_stats(loci, verbose=1):
    n = len(loci)
    sum = length_sum(loci)
    c_sum = coverage_sum(loci)
    overlap = sum-c_sum
    lengths = [len(locus) for locus in loci]
    starts = [locus.start for locus in loci]
    ends = [locus.get_end() for locus in loci]
    if loci:
        min_start, max_end = min(starts), max(ends)
        n_density = float(n)/(max_end-min_start)
        c_density = float(c_sum)/(max_end-min_start)
    else:
        min_start, max_end = None, None
        n_density = None
        c_density = None
    if verbose:
        Prot.write('Basic Stats for %s loci:' % len(loci))
        Prot.write('n = %s' % len(loci))
        Prot.write('sum = %sbp' % sum)
        Prot.write('coverage sum = %sbp' % c_sum)
        Prot.write('mean length = %sbp' % np.mean(lengths))
        Prot.write('std length = %sbp' % np.std(lengths))
        Prot.write('range = %s-%s' % (min_start,max_end))
        Prot.write('n density = %s' % n_density)
        Prot.write('cov. density = %s' % c_density)

def extend(loci, before=0, after=0, consider_strand=False):
    for locus in loci:
        if consider_strand and locus.strand == '-':
            dx1 = after
            dx2 = before
        else:
            dx1 = before
            dx2 = after
        locus.start = locus.start-dx1
        locus.length += dx2
        if locus.start < 0:
            locus.start = 0
        if locus.target is not None and locus.get_end() > len(locus.target):
            locus.length = locus.get_end()-len(locus.target)
    return loci

def get_surroundings(loci, before=0, after=0, consider_strand=False):
    surroundings = []
    for locus in loci:
        if consider_strand and locus.strand == '-':
            dx1 = after
            dx2 = before
        else:
            dx1 = before
            dx2 = after
        start = locus.start-dx1
        end = locus.start
        if start < 0:
            start = 0
        if locus.target is not None and end > len(locus.target):
            end = len(locus.target)
        surroundings.append(Locus(start=start, end=end, target=locus.target))
        start = locus.get_end()
        end = start+dx2
        if start < 0:
            start = 0
        if locus.target is not None and end > len(locus.target):
            end = len(locus.target)
        if start != end:
            surroundings.append(Locus(start=start, end=end, target=locus.target))
    return surroundings
    
def get_regions_at_distance(loci, dist_before=0, size_before=0, dist_after=0, size_after=0, consider_strand=False, verbose=1):
    if verbose:
        Prot.write('Generating regions around %s loci.' % len(loci))
    surroundings = []
    for locus in loci:
        if consider_strand and locus.strand == '-':
            dx1 = dist_after
            sx1 = size_after
            dx2 = dist_before
            sx2 = dist_after
        else:
            dx1 = dist_before
            sx1 = size_before
            dx2 = dist_after
            sx2 = size_after
        if sx1 > 0:
            start = locus.start-dx1-sx1
            end = locus.start-dx1
            if start < 0:
                start = 0
            if locus.target is not None and end > len(locus.target):
                end = len(locus.target)
            surroundings.append(Locus(start=start, end=end, target=locus.target))
        if sx2 > 0:
            start = locus.get_end()+dx2
            end = start+dx2+sx2
            if start < 0:
                start = 0
            if locus.target is not None and end > len(locus.target):
                end = len(locus.target)
            if start != end:
                surroundings.append(Locus(start=start, end=end, target=locus.target))
    if verbose:
        Prot.write('Generated %s regions.' % len(surroundings))
    return surroundings

def loci_in_loci(loci1, loci2, gaps=None, target=None, target_length=None, verbose=1):
    if verbose:
        Prot.write('Calculating overlap of %s loci and %s loci.' % (len(loci1),len(loci2)))
    if gaps is None:
        gaps = []
    if target is not None:
        target_length = len(target)
    overlap_count = 0
    buckets = generate_touch_buckets(loci2)
    bucket_size = buckets.bucket_size
    for locus in loci1:
        test_keys = []
        posi = locus.start
        locus_end = locus.get_end()
        while posi < locus_end:
            key = buckets.calculate_bucket_key(posi)
            test_keys.append(key)
            posi += bucket_size
        end_key = buckets.calculate_bucket_key(locus_end)
        if key != end_key:
            test_keys.append(end_key)
        for key in test_keys:
            overlap = buckets.check_overlap(locus, key=key)
            if overlap:
                overlap_count += 1
                break
    results = {'overlap_count':overlap_count, 'n':len(loci1)}
    if target_length:
        if verbose:
            Prot.write('Calculated Statistics.')
        # Calculate p-value
        mean_length = np.mean([len(locus) for locus in loci1])
        extend(loci2, mean_length-1, 0, consider_strand=False)
        c_sum = coverage_sum(loci2)
        gap_sum = coverage_sum(gaps)
        results['c_sum'] = c_sum
        p = float(c_sum)/(target_length-gap_sum)
        results['p'] = p
        p_smaller = binom.cdf(k=overlap_count, n=len(loci1), p=p)
        p_larger = 1.-p_smaller
        results['p_smaller'] = p_smaller
        results['gap_sum'] = gap_sum
        results['p_larger'] = p_larger
        results['model_mean'] = binom.mean(n=len(loci1), p=p)
        results['model_std'] = binom.std(n=len(loci1), p=p)
        results['target_length'] = target_length
        results['k'] = overlap_count
    if verbose:
        Prot.write('Loci n = %s' % results['n'])
        if results['n'] != 0:
            Prot.write('Loci with overlap k = %s (%s%%)' % (overlap_count, int(round(100*float(overlap_count)/results['n']))))
        else:
            Prot.write('Loci with overlap k = 0 (?%)')
        if target_length:
            Prot.write('Target Length L = %s' % target_length)
            Prot.write('Size of Loci2 S = %s (%s%%)' % (results['c_sum'], int(round(100*float(results['c_sum'])/target_length))))
            Prot.write('p [S/L] = %s' % results['p'])
            Prot.write('p-value (x<k) = %s' % results['p_smaller'])
            Prot.write('p-value (x>k) = %s' % results['p_larger'])
            Prot.write('model mean = %s' % results['model_mean'])
            Prot.write('model std = %s' % results['model_std'])
    return results

def filter_loci_by_overlap(loci1, loci2=None, filter_overlapping=False, buckets=None, verbose=1):
    if verbose:
        if loci2 is not None:
            Prot.write('Filter loci (%s) overlapping with loci (%s).' % (len(loci1),len(loci2)))
        else:
            Prot.write('Filter loci (%s) overlapping with %s buckets.' % (len(loci1),len(buckets)))
    if buckets is None:
        buckets = generate_touch_buckets(loci2, verbose=verbose)
    bucket_size = buckets.bucket_size
    passed_loci = []
    for locus in loci1:
        ov = False
        test_keys = []
        posi = locus.start
        locus_end = locus.get_end()
        while posi < locus_end:
            key = buckets.calculate_bucket_key(posi)
            test_keys.append(key)
            posi += bucket_size
        end_key = buckets.calculate_bucket_key(locus_end)
        if key != end_key:
            test_keys.append(end_key)
        for key in test_keys:
            overlap = buckets.check_overlap(locus, key=key)
            if overlap:
                if not filter_overlapping:
                    passed_loci.append(locus)
                ov = True
                break
        if not ov and filter_overlapping:
            passed_loci.append(locus)
    if verbose:
        Prot.write('%s loci passed filter.' % len(passed_loci))
    return passed_loci
    
def filter_loci_by_overlap2(loci1, loci2, buckets=None, verbose=1):
    if verbose:
        if loci1 is not None:
            Prot.write('Filter loci (%s) overlapping with loci (%s).' % (len(loci1),len(loci2)))
        else:
            Prot.write('Filter buckets (%s) overlapping with loci (%s).' % (len(buckets),len(loci2)))
    if buckets is None:
        buckets = generate_touch_buckets(loci1, verbose=verbose)
    bucket_size = buckets.bucket_size
    loci_ids_with_overlap = {}
    for locus2 in loci2:
        touched_buckets = buckets.get_touched_buckets(locus2.start, locus2.get_end())
        for touched_bucket in touched_buckets:
            for locus1 in touched_bucket:
                if locus2.check_overlap(locus1):
                    loci_ids_with_overlap[locus1.get_id()] = locus1
    passed_loci = [loci_ids_with_overlap[key] for key in loci_ids_with_overlap]
    if verbose:
        Prot.write('%s loci passed filter.' % len(passed_loci))
    return passed_loci
    
def get_overlap_regions(loci1, loci2=None, buckets=None, save_parents=False, verbose=1):
    if verbose:
        if loci2 is not None:
            Prot.write('Generate overlap Regions of %s loci with %s loci.' % (len(loci1),len(loci2)))
        else:
            Prot.write('Generate overlap Regions of %s loci with %s buckets.' % (len(loci1),len(buckets)))
    if buckets is None:
        buckets = generate_touch_buckets(loci2)
    bucket_size = buckets.bucket_size    
    overlap_loci = []
    for locus1 in loci1:
        test_keys = []
        posi = locus1.start
        locus_end = locus1.get_end()
        while posi < locus_end:
            key = buckets.calculate_bucket_key(posi)
            test_keys.append(key)
            posi += bucket_size
        end_key = buckets.calculate_bucket_key(locus_end)
        if key != end_key:
            test_keys.append(end_key)
        for key in test_keys:
            loci = buckets.get_bucket(key)
            for locus2 in loci:
                ov_start, ov_end = locus2.get_overlap(locus1)
                if ov_start is not None:
                    overlap_loci.append(Locus(start=ov_start, end=ov_end, target=locus2.target))
    if overlap_loci:
        overlap_loci = merge(overlap_loci, verbose=verbose) 
    if verbose:
        Prot.write('Generated %s overlap regions.' % len(overlap_loci))
    return overlap_loci

def add_target(loci, target):
    for locus in loci:
        locus.target = target

def filter_length(loci, min_length=0, max_length=None, verbose=1):
    if verbose:
        Prot.write('Filtering %s loci for length %s<=L<=%s' % (len(loci), min_length, max_length))
    filtered_loci = [locus for locus in loci if len(locus) >= min_length and (max_length is None or len(locus) <= max_length)]
    if verbose:
        Prot.write('%s Loci passed the filter %s were filtered.' % (len(filtered_loci), len(loci)-len(filtered_loci)))
    return filtered_loci
    
def split_by_target(loci):
    target_loci = {}
    for locus in loci:
        s = str(locus.target)
        try:
            target_loci[s]
        except:
            target_loci[s] = [locus]
        else:
            target_loci[s].append(locus)
    return target_loci
    
def count_hits(locus, loci=None, loci_buckets=None):
    if loci is not None:
        n = 0
        for locus2 in loci:
            if locus.check_overlap(locus2):
                n += 1
    else:
        loci = []
        touched_buckets = loci_buckets.get_touched_buckets(locus.start, locus.get_end())
        for bucket in touched_buckets:
            loci += bucket
        n = count_hits(locus, loci)
    return n
    
def create_pairs(loci, min_gap=0, max_gap=20, allow_overlap=False):
    pairs = []
    loci = sorted(loci, key=lambda l: l.start)
    for i in range(1, len(loci)):
        locus1 = loci[i-1]
        locus2 = loci[i]
        gap = Oligo.Loci.distances.interspace_distance(locus1, locus2)
        if gap.labels['overlapping']:
            overlapping = True
        else:
            overlapping = False
        gap = int(gap)
        if gap >= min_gap and gap <= max_gap and (not overlapping or allow_overlap):
            pairs.append([locus1, locus2])
    return pairs
    
    
def save_int(x):
    return int(float(x))
