from Oligo import Prot
from .locus import generate_start_buckets
import datetime
import Oligo
import pandas
from random import randint
from numpy import sqrt
import scipy

class Distance(object):

    def __init__(self, value, labels={}):
        self.value = value
        self.labels = labels
        
    def __str__(self):
        return str(self.value)
        
    def __repr__(self):
        return '<Oligo.Distance:'+str(self.value)+'>'
        
    def __int__(self):
        return int(self.value)
        
    def __float__(self):
        return float(self.value)
        
    def __eq__(self, other):
        if isinstance(other, Distance):
            return self.value == other.value
        else:
            return other == self.value
            
    def __ne__(self, other):
        return not self.__eq__(other)
        
    def __lt__(self, other):
        if isinstance(other, Distance):
            return self.value < other.value
        else:
            return self.value < other
        
    @classmethod
    def read(cls, input_filename, verbose=1):
        if verbose:
            Prot.write('Reading distances from %s.' % input_filename)
        head_data, head_rows = Oligo.File.read_head(input_filename)
        data = pandas.read_csv(input_filename, sep='\t', skiprows=head_rows)
        distances = []
        for row in data.itertuples():
            labels = {}
            label_pairs = row.Labels.split(';')
            for label_pair in label_pairs:
                (label_key, label_value) = label_pair.split(':')
                labels[label_key] = label_value
            dist = row.Distance
            distances.append(Distance(dist, labels))
        if verbose:
            Prot.write('Found %s distances.' % len(distances))
        return distances
        
def save(distances, output_filename='Distances.distances', head={}, verbose=1):
    if verbose:
        Oligo.Prot.write('Saving %s distances to %s' % (len(distances), output_filename))
    f = open(output_filename, 'w')
    head['date'] = datetime.datetime.now()
    Oligo.File.write_head(f, head)
    f.write('Distance\tLabels\n')
    for distance in distances:
        f.write(str(distance.value)+'\t'+';'.join([str(key)+':'+str(value) for key, value in distance.labels.items()])+'\n')
    f.close()
            
def start_start_distance(locus1, locus2):
    return Distance(abs(locus1.start-locus2.start), {'Loc1': locus1.get_id(), 'Loc2': locus2.get_id()})
      
def interspace_distance(locus1, locus2):
    overlap_start, overlap_end = locus1.get_overlap(locus2)
    labels = {'Loc1': locus1.get_id(), 'Loc2': locus2.get_id()}
    if overlap_start is not None:
        labels['overlap_start'], labels['overlap_end'] = overlap_start, overlap_end
        labels['overlapping'] = 1
        dist = 0
    else:
        labels['overlapping'] = 0
        locus2_end = locus2.get_end()
        if locus1.start >= locus2_end:
            dist = locus1.start-locus2_end
        else:
            dist = locus2.start-locus1.get_end()
    return Distance(dist, labels)
    
def boundary_distance(locus1, locus2):
    overlap_start, overlap_end = locus1.get_overlap(locus2)
    labels = {'Loc1': locus1.get_id(), 'Loc2': locus2.get_id()}
    s1,s2 = locus1.start, locus2.start
    e1,e2 = locus1.get_end(), locus2.get_end()
    if overlap_start is not None:
        labels['overlap_start'], labels['overlap_end'] = overlap_start, overlap_end
        labels['overlapping'] = 1
        if overlap_start == s1 or overlap_end == e1:
            dist = 0
        else:
            dist = min(abs(s1-s2), abs(e1-e2))
    else:
        labels['overlapping'] = 0
        locus2_end = locus2.get_end()
        if locus1.start >= locus2_end:
            dist = locus1.start-locus2_end
        else:
            dist = locus2.start-locus1.get_end()
    return Distance(dist, labels)
      
def same_boundaries_pair_filter(locus1, locus2):
    return not (locus1.start == locus2.start and locus1.length == locus2.length)
    
def add_lengths_probe(locus, test_locus, dist):
    dist.labels['length1'] = locus.length
    dist.labels['length2'] = test_locus.length
    
def nearest_neighbor_distance(locus, buckets, dist_func, dist_func_args, bucket_key, valid_pair_filter_func=None, valid_pair_filter_args=(), probe_func=None, probe_func_args=()):
    dx = 0
    min_dist = None
    test_loci = []
    while not test_loci:
        test_loci += buckets.get_distance_buckets(bucket_key, dx)
        if valid_pair_filter_func is not None:
            test_loci = [test_locus for test_locus in test_loci if valid_pair_filter_func(locus, test_locus, *valid_pair_filter_args)]
        if test_loci:
            test_loci += buckets.get_distance_buckets(bucket_key, dx+1)
            break
        dx += 1
    if valid_pair_filter_func is not None:
        test_loci = [test_locus for test_locus in test_loci  if valid_pair_filter_func(locus, test_locus, *valid_pair_filter_args)]
    min_dist = None
    for test_locus in test_loci:
        dist = dist_func(locus, test_locus, *dist_func_args)
        if min_dist is None or dist < min_dist:            
            min_dist = dist
            if probe_func is not None:
                probe_func(locus, test_locus, dist, *probe_func_args)
    return min_dist
        
def nearest_neighbor_distances(loci1, loci2=None, dist_func=None, dist_func_args=(), bucket_size=100000, valid_pair_filter_func=None, valid_pair_filter_args=(), verbose=1, output_filename=None, probe_func=None, probe_func_args=()):
    if loci2 is None:
        loci2 = loci1
        if valid_pair_filter_func is None:
            valid_pair_filter_func = same_boundaries_pair_filter
    if dist_func is None:
        dist_func = start_start_distance
    if verbose:
        Prot.write('Caclulating Nearest Neighbor Distances for Loci %s to %s' % (len(loci1), len(loci2)))
    distances = []
    buckets = generate_start_buckets(loci2, bucket_size, verbose=verbose)
    for locus in loci1:
        if locus.start is not None:
            bucket_key = buckets.calculate_bucket_key(locus.start)
            distance = nearest_neighbor_distance(locus, buckets, dist_func, dist_func_args, bucket_key, valid_pair_filter_func, valid_pair_filter_args, probe_func, probe_func_args)
            if distance is not None:
                distances.append(distance)
        else:
            Prot.warn('Cannot calculate distances for %s (start is None)' % locus,'Inalid Value')
    if verbose:
        Prot.write('Calculated %s distances.' % len(distances))
    if output_filename:
        save(distances, output_filename, {'RESULTS':'created by Oligo.distances.nearest_neighbor_distances', 'valid pair filter':str(valid_pair_filter_func)+str(valid_pair_filter_args), 'distance function':str(dist_func)+str(dist_func_args)}, verbose)
    return distances
    
def reference_shuffle_distances(loci, ref_loci, n, prefix='Reference', allow_overlap_AA=True, allow_overlap_AB=True, bucket_size=100000, dist_func=None, dist_func_args=(), valid_pair_filter_func=None, valid_pair_filter_args=(), probe_func=None, probe_func_args=(), bin_width=10000, filter_overlaps=True, verbose=1):
    if verbose:
        Prot.write('Create Shuffle Reference Distances (n1=%s, n2=%s)' % (len(loci), len(ref_loci)))
    if not allow_overlap_AB:
        prevent_loci = loci
    else:
        prevent_loci = None
    for i in range(n):
        if verbose:
            Prot.write('Iteration %s/%s' %(i+1, n))
        Oligo.Loci.shuffle(ref_loci, allow_overlap=allow_overlap_AA, prevent_loci=prevent_loci, bucket_size=bucket_size)
        dists = nearest_neighbor_distances(loci, ref_loci, dist_func=dist_func, dist_func_args=dist_func_args, bucket_size=bucket_size, valid_pair_filter_func=valid_pair_filter_func, valid_pair_filter_args=valid_pair_filter_args, verbose=0, output_filename=None, probe_func=probe_func, probe_func_args=probe_func_args)
        if filter_overlaps:
            dists = [d for d in dists if not int(d.labels['overlapping'])]
        dist_bins = Oligo.Loci.bins.create_dist_bins(dists, bin_width=bin_width)
        Oligo.Loci.bins.save_bins(dist_bins, prefix+'_'+str(i+1)+'.shuffle_reference.bins.dat', head={'RESULTS': 'distances.py:reference_shuffle_distances','n':n, 'allow overlap AA':allow_overlap_AA, 'allow overlap AB':allow_overlap_AB})
        
def reference_shift_distances(loci, ref_loci, n, prefix='Reference', bucket_size=100000, dist_func=None, dist_func_args=(), valid_pair_filter_func=None, valid_pair_filter_args=(), probe_func=None, probe_func_args=(), bin_width=10000, filter_overlaps=True, verbose=1):
    if verbose:
        Prot.write('Create Shift Reference Distances (n1=%s, n2=%s)' % (len(loci), len(ref_loci)))
    for i in range(n):
        if verbose:
            Prot.write('Iteration %s/%s' %(i+1, n))
        shift_value = randint(0, len(ref_loci[0].target)-1)
        Oligo.Loci.shift(ref_loci, shift_value, circle=True)
        dists = nearest_neighbor_distances(loci, ref_loci, dist_func=dist_func, dist_func_args=dist_func_args, bucket_size=bucket_size, valid_pair_filter_func=valid_pair_filter_func, valid_pair_filter_args=valid_pair_filter_args, verbose=0, output_filename=None, probe_func=probe_func, probe_func_args=probe_func_args)
        if filter_overlaps:
            dists = [d for d in dists if not int(d.labels['overlapping'])]
        dist_bins = Oligo.Loci.bins.create_dist_bins(dists, bin_width=bin_width)
        Oligo.Loci.bins.save_bins(dist_bins, prefix+'_'+str(i+1)+'.shift_reference.bins.dat', head={'RESULTS': 'distances.py:reference_shift_distances','n':n})
        
        
class DistanceModel(object):

    def __init__(self, p_free):
        #self.p_init = p_init
        #self.p0 = 1.-p_init
        self.p_free = p_free
        self.p_block = 1.-p_free
       
    @classmethod
    def from_distances(cls, dists, verbose=1):
        if verbose:
            Prot.write('Calculating DistanceModel for %s distances.' % len(dists))
        if not dists:
            Prot.warn('No distances found to create a model for.','Empty Input')
            return DistanceModel(p_free=0.0)
        n_block = 0
        n_free = 0
        #n0 = 0
        #n_init = 0
        for dist in dists:
            try:
                dist.labels['overlapping']
            except:
                n_free += abs(int(dist))
                n_block += 1
            else:
                if not int(dist.labels['overlapping']):
                    n_free += abs(int(dist))
                    n_block += 1
                    #if int(dist) == 0:
                    #    n0 += 1
                    #else:
                    #    n_init += 1
        if n_free == 0 and n_block == 0:
            p_free = 1.
        else:
            if n_free == 0 and n_block == 0:
                p_free = 0.0
            else:
                p_free = float(n_free)/(n_free+n_block)
        #p_init = float(n_init)/(n_init+n0)
        if verbose:
            Prot.write('Created DistanceModel with p_free=%s' % p_free)
        return DistanceModel(p_free)
        
    def get_p(self, n, n_stop=None):
        if n_stop is None:
            #if n == 0
            #   return self.p0
            return self.p_block*self.p_free**n
        s = 0
        while n < n_stop: 
            s += self.get_p(n)
            n += 1
        return s
        

    def get_p_value(self, x, n, n_start, n_stop=None):
        if n_stop is None:
            n_stop = n_start+1
        return float(scipy.stats.binom.pmf(k=x, n=n, p=self.get_p(n_start, n_stop)))
        
    def to_bins(self, n, bin_bounds=None, bin_width=None, bin_start=0, bin_end=None, n_bins=None, verbose=1):
        if verbose:
            Prot.write('Converting DistanceModel to bins.')
        if bin_bounds is None:
            if bin_width is None:
                if bin_end is None:
                    bin_width = float(max(dists))/n_bins
                else:
                    bin_width = (bin_end-bin_start)/n_bins
            bin_bounds = []
            bin_x = bin_start
            if bin_end is None:
                bin_end = float(max(dists))
            while bin_x < bin_end:
                bin_bounds.append((bin_x, bin_x+bin_width))
                bin_x += bin_width
        bins = []
        for bound in bin_bounds:
            p_bin = self.get_p(bound[0], bound[1])
            mean_count = p_bin*n
            err = sqrt(n*p_bin*(1.-p_bin))
            bin = Oligo.Loci.bins.Bin(mean_count, bound[0], bound[1], std=err)
            bins.append(bin)
        if verbose:
            Prot.write('Created %s bin from DistanceModel.' % len(bins))
        return bins
        
        
