import Oligo
import sys

NONE_INPUTS = ['None']

class Argument(object):

    def __init__(self, name=None, default_value=None, translator=str, translator_args=()):
        self.name = name
        self.default_value = default_value
        self.translator = translator
        self.translator_args = translator_args
        self.value = None
        
    def get_value(self):
        if self.value is None:
            return self.default_value
        if self.translator is None:
            return self.value
        return self.translator(self.value, *self.translator_args)
         
        
def search_arg_by_name(name, args):
    for arg in args:
        if arg.name is not None and name == arg.name:
            return arg
    return None    
        

def command_line_intput(args, argv=None, prot=True, ignore_unknown_args=False):
    if prot:
        Oligo.Prot.write('>'+' '.join(sys.argv))
    if argv is None:
        argv = sys.argv[1:]
    i = 0
    while i < len(argv):
        x = argv[i]
        if x[0] == '-' and len(x) > 1:
            name = x[1:]
            arg = search_arg_by_name(name, args)
            if arg is None:
                if not ignore_unknown_args:
                    Oligo.Prot.error('Invalid Command Line Argument -%s.' % (name),'Input Error')
                    raise
            else:
                try:
                    argv[i+1]
                except:
                    Oligo.Prot.error('No value specified for Command Line Argument -%s.' % (name),'Input Error')
                    raise
                else:
                    if argv[i+1] in NONE_INPUTS:
                        arg.value = None
                    else:
                        arg.value = argv[i+1]
            i += 1
        else:
            if i >= len(args):
                if not ignore_unknown_args:
                    Oligo.Prot.error('Too Many Command Line Arguments. %s possible for %s, %s specified.' % (len(args),sys.argv[0],len(argv)),'Input Error')
                    raise
            else:
                arg = args[i]
                if x in NONE_INPUTS:
                    arg.value = None
                else:
                    arg.value = x
        i += 1
    return {arg.name:arg.get_value() for arg in args}
    
def encode_input(input_string, parameters={}):
    s = input_string
    for key in parameters:
        s = s.replace('$('+str(key)+')', str(parameters[key]))
    return s
    
def translate_output_filelist(arg_string):
    return [Oligo.File.translate_output_filename(filename) for filename in arg_string.split(',')]
    
def translate_input_filelist(arg_string):
    return [Oligo.File.translate_input_filename(filename) for filename in arg_string.split(',')]
    
def translate_list(arg_string):
    return arg_string.split(',')
    
def translate_int_list(arg_string):
    return [int(x) for x in arg_string.split(',')]