import Oligo

class Group:
        
    def __init__(self, name, type=None, children=[], orgas=[], desc=None):
        self.name = name
        self.type = type
        self.children = children
        self.orgas = orgas
        self.desc = desc
        
    def get_orgas(self, include_children=True):
        orgas = self.orgas
        if include_children and self.children:
            for child in self.children:
                orgas += child.get_orgas(include_children=True)
        return [unique.append(orga) for orga in orgas if orga not in unique]
        
    def __str__(self):
        return '<Group:'+str(self.name)+'['+str(len(self.orgas))+'|'+str(len(self.children))+']>'
        
    def to_line(self, head=None, delim='\t'):
        d = []
        if head is None:
            head = ['Name','Type','Children','Orgas','Description']
        for key in head:
            if key == 'Name':
                d.append(str(self.name))
            elif key == 'Type':
                d.append(str(self.type))
            elif key == 'Children':
                d.append(','.join([str(p.name) for p in self.children]))
            elif key == 'Orgas':
                d.append(','.join([str(p.name) for p in self.orgas]))
            elif key == 'Description':
                d.append(str(self.desc))    
        return delim.join(d)    
    
    @classmethod
    def read_line(cls, words, state, data):
        values = {'name': state['name'],'type': state['type'], 'children': state['children'][:], 'orgas': state['orgas'][:], 'desc': state['desc']}
        
        group = Group(values['name'], values['type'], [], [], values['desc'])
        state['children_names'][values['name']] = values['children']
        state['orga_names'][values['name']] = values['orgas']
        return group
        
    @classmethod
    def from_file(cls, input_filename, orgas=None, pgroups=None, head=None, delim='\t', verbose=1):
        if verbose:
            Oligo.Prot.write('Reading Groups from '+str(input_filename))
        state = {'head':head, 'name':None, 'type':None, 'children':None, 'orgas':None, 'desc':None, 'children_names':{}, 'orga_names':{}}
        read_word_funcs, read_word_func_args = {}, {}
        for key in ['name', 'type', 'children', 'orgas', 'desc']:
            if key == 'children' or key == 'orgas':
                read_word_funcs[key] = lambda x: x.split(',')
            else:
                read_word_funcs[key] = None
            read_word_func_args[key] = ()
        groups = Oligo.File.read(input_filename, Group.read_line, (), read_word_funcs, read_word_func_args, state)
        #f = open(input_filename,'r')
        #groups = []
        #children_names = {}
        #orga_names = {}
        #para = {}
        #para['name'] = None
        #para['type'] = None
        #para['children'] = []
        #para['orgas'] = []
        #para['desc'] = None
        #for line in f:
        #    words = Oligo.File.words(line, delim)
        #    if words[0][0] == '$':
        #        key_name, key_type = Oligo.File.translate_line_key(words[0])
        #        para[key_name] = Oligo.File.translate_line_value(words[1:], key_type)
        #        if head is None and words[0] == '$head:':
        #            head = words[1:]
        #    else:   
        #        values = {'name': para['name'],'type': para['type'], 'children': para['children'][:], 'orgas': para['orgas'][:], 'desc': para['desc']}
        #        for (key, value) in zip(head, words):
        #            if key in ['orgas','children']:
        #                if value:
        #                    values[key] = value.split(',')
        #                else:
        #                    values[key] = []
        #            else:
        #                values[key] = value
        #        group = Group(values['name'], values['type'], [], [], values['desc'])
        #        children_names[values['name']] = values['children']
        #        orga_names[values['name']] = values['orgas']
        #        groups.append(group)
        #f.close()
        if verbose:
            Oligo.Prot.write('Found '+str(len(groups))+' groups.')
        if not groups:
            Oligo.Prot.warn('Could not find groups in '+str(input_filename)+'.', 'No Data')
        else:
            if orgas:
                if verbose:
                    Oligo.Prot.write('Linking orgas.')
                orga_index = {}
                for orga in orgas:
                    orga_index[orga.name] = orga
                for group in groups:
                    #for orga_name in orga_names[group.name]:
                    for orga_name in state['orga_names'][group.name]:
                        group.orgas.append(orga_index[orga_name])
            if verbose:
                Oligo.Prot.write('Linking Children Groups.')
                group_index = {}
                if pgroups is None:
                    pgroups = []
                for group in groups+pgroups:
                    group_index[group.name] = group
                for group in groups:
                    #for group_name in children_names[group.name]:
                    for group_name in state['children_names'][group.name]:
                        try:
                            group_index[group_name]
                        except:
                            Oligo.Prot.warn('Desired children group "'+str(group_name)+'" of '+str(group.name)+' ('+str(input_filename)+') not found for linking.',None)
                        else:
                            group.children.append(group_index[group_name])
        return groups
        
    @classmethod
    def to_file(cls, groups, output_filename, default_paras=None, head=None, delim='\t', verbose=1):
        if verbose:
            Oligo.Prot.write('Saving '+str(len(groups))+' Groups to '+str(output_filename))
        if head is None:
            head = ['name','type','children','orgas','desc']
        f = open(output_filename,'w')
        f.write('$head:'+delim+delim.join(head)+'\n')
        if default_paras:
            Oligo.File.add_para_lines(default_paras, f, delim)
        for group in groups:
            words = []
            for key in head:
                if key == 'name':
                    words.append(str(group.name))
                elif key == 'type':
                    words.append(str(group.type))
                elif key == 'desc':
                    words.append(str(group.desc))
                elif key == 'orgas':
                    if group.orgas:
                        words.append(','.join([str(x.name) for x in group.orgas]))
                    else:
                        words.append('-')
                elif key == 'children':
                    if group.children:
                        words.append(','.join([str(x.name) for x in group.children]))
                    else:
                        words.append('-')
                else:
                    Oligo.Prot.warn('Unknown desired head key value "'+str(key)+'" found, while saving groups to '+str(output_filename)+'.', None)
            f.write(delim.join(words)+'\n')
        f.close()
    
    @classmethod
    def from_line(cls, data, head=None, delim='\t'):
        if head is None:
            head = ['Name','Type','Orgas','Description']
        for (d, key) in zip(data,head):
            if key == 'Name':
                name = d
            elif key == 'Type':
                type = d
            elif key == 'Orgas':
                p = d.split(',')
                orgas = list(filter(None, [Oligo.Orga.Organism.get(x) for x in p]))
            elif key == 'Description':
                desc = d   
        return Group(name, type, parents, children, orgas, desc)  