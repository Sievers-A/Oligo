import Oligo

class Chromosome(object):

    def __init__(self, name, organism, topology='linear', length=None, filename=None, seq=None, labels=None, id=None):
        self.name = name
        self.orga = organism
        self.topology = topology
        self.length = length
        self.filename = filename
        self.seq = seq
        self.id = id
        if labels is None:
            labels = []
        self.labels = labels
        
    def __str__(self):
        return self.orga.name+' '+self.name
       
    def __repr__(self):
        return self.name
        
    def __len__(self):
        return self.length
      
    def get_seq(self):
        if self.seq is None:
            self.load_seq(verbose=0)
        return self.seq
      
    def load_seq(self, verbose=1):
        if verbose:
            Oligo.Prot.write('Loading sequence for %s from %s.' % (str(self), self.filename))
        self.seq = str(Oligo.File.read_sequence_file(self.filename)[1])
        if verbose:
            Oligo.Prot.write('Sequence %sbp loaded.' % len(self.seq))
        
    def unload_seq(self, verbose=1):
        if verbose:
            Oligo.Prot.write('Unloading sequence for %s.' % str(self))
        del self.seq
        self.seq = None