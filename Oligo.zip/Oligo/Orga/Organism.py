class Organism(object):
    
    
    def __init__(self, name):
        self.name = name
    
    def __str__(self):
        return str(self.name)
        
    def __repr__(self):
        return '<Organism:'+str(self.name)+'>'
        
    def __eq__(self, other):
        return str(self) == str(other)
        
    def __ne__(self, other):
        return not self == other