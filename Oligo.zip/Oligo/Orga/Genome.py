class Genome(list):
    
    def __init__(self, organism, chromosomes=[]):
        self.organism = organism
        super(Genome, self).__init__(chromosomes)
        
        
    def __repr__(self):
        return '<Oligo.Genome:'+str(self.organism)+':['+','.join([c.__repr__() for c in self])+']>'