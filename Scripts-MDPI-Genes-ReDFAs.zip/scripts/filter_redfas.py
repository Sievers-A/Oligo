import sys
sys.path.insert(1, 'N:/Software/KIP/')
import Oligo
import numpy as np

k = 5
resolution = 40
genome = Oligo.File.read_human_genome()
chromos = [genome[8],genome[4]]
#chromos = [genome[i] for i in range(len(genome)) if i not in [8,4]]

# Derive Deviations from Average Spectrum distribution
for chromo in chromos:
    #data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_deviations_from_average_spectrum.dat' % (chromo, resolution, k))
    #data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_relative_deviations_from_average_spectrum.dat' % (chromo, resolution, k))
    #x = []
    #for d in data:
    #    xi = []
    #    for kmer in list(d.keys())[1:]:
    #        xi.append(float(d[kmer]))
    #    x.append(np.mean(xi))
    #    
    #out_data = []
    #for d,ad in zip(data,x):
    #    d = {'position [kbp]':d['position'], 'Average Deviation from Average Spectrum':ad}
    #    out_data.append(d)
    ##Oligo.File.save_dat_lines(output_filename='../results/%s_%skbp_k=%s_average_deviations_from_average_spectrum.dat' % (chromo, resolution, k), data=out_data)
    #Oligo.File.save_dat_lines(output_filename='../results/%s_%skbp_k=%s_relative_average_deviations_from_average_spectrum.dat' % (chromo, resolution, k), data=out_data)
    #
    ##data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_average_deviations_from_average_spectrum.dat' % (chromo, resolution, k))
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_relative_average_deviations_from_average_spectrum.dat' % (chromo, resolution, k))
    x = [abs(float(d['Average Deviation from Average Spectrum'])) for d in data]
    
    bins = Oligo.Loci.bins.create_bins(x, bin_width=0.05)
    drawer = Oligo.Plot.HistoDrawer(bins=bins, relative=True)
    #drawer.plot(output_filename='../results/Deviation_from_Average_Spectrum_distribution_%s_k=%s_%skb.png' % (chromo,k,resolution), xlabel='Deviation from Average Spectrum', ylabel='occurence', show_legend=False, ylog=True)
    drawer.plot(output_filename='../results/Relative_Deviation_from_Average_Spectrum_distribution_%s_k=%s_%skb_linear.png' % (chromo,k,resolution), xlabel='Deviation from Average Spectrum', ylabel='occurence', show_legend=False, ylog=False)
    
    print('q=50 -',np.percentile(x,50))
    print('q=60 -',np.percentile(x,60))
    print('q=70 -',np.percentile(x,70))
    print('q=80 -',np.percentile(x,80))
    print('q=90 -',np.percentile(x,90))
    print('q=95 -',np.percentile(x,95))
    
    th = np.percentile(x,95)
    
    out_data = []
    for d in data:
        ad = abs(float(d['Average Deviation from Average Spectrum']))
        if ad > th:
            out_data.append(d)
    Oligo.File.save_dat_lines(output_filename='../results/%s_%skbp_k=%s_ReDFAS.dat' % (chromo, resolution, k), data=out_data)