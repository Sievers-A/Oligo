import sys
sys.path.insert(1, 'N:/Software/KIP/')
import Oligo
import itertools

resolution = 40
k = 5
words = [''.join(w) for w in itertools.product('ACGT',repeat=k)]

genome = Oligo.File.read_human_genome()
#chromos = [genome[8],genome[4]]
chromos = [genome[i] for i in range(len(genome)) if i not in [8,4]]
n_components = 3

def create_redfas_index(chromo, resolution, k):
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_ReDFAS.dat' % (chromo, resolution, k))
    index = Oligo.Index(data, lambda d : int(d['position [kbp]']))
    return index

for chromo in chromos:
    matrix_data = []
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_relative_deviations_from_average_spectrum_and_GC_and_hicfreq.dat' % (chromo, resolution, k))
    for d in data:
        matrix_data.append([float(d[kmer]) for kmer in words])
    pca_results = Oligo.Matrix.pca(matrix_data, n_components=n_components)
    out_data = []
    for i,d in enumerate(data):
        d_out = {}       
        d_out['position'] = d['position']
        for n_component in range(n_components):
            d_out['pca %s' % n_component] = pca_results[n_component][i]
        out_data.append(d_out)
    Oligo.File.save_dat_lines('../results/%s_%skbp_k=%s_PCA.dat' % (chromo,resolution,k), out_data)
    

for chromo in chromos:
    redfas_index = create_redfas_index(chromo, resolution, k)
    matrix_data = []
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_relative_deviations_from_average_spectrum_and_GC_and_hicfreq.dat' % (chromo, resolution, k))
    data = [d for d in data if redfas_index.get_value(int(d['position'])) is not None]
    for d in data:
        matrix_data.append([float(d[kmer]) for kmer in words])
    pca_results = Oligo.Matrix.pca(matrix_data, n_components=n_components)
    out_data = []
    for i,d in enumerate(data):
        d_out = {}       
        d_out['position'] = d['position']
        for n_component in range(n_components):
            d_out['pca %s' % n_component] = pca_results[n_component][i]
        out_data.append(d_out)
    Oligo.File.save_dat_lines('../results/%s_%skbp_k=%s_PCA_ReDFAs_only.dat' % (chromo,resolution,k), out_data)