import sys
sys.path.insert(1, 'N:/Software/KIP/')
import Oligo
import itertools

k = 5
resolution = 40

genome = Oligo.File.read_human_genome()
#chromos = [genome[8],genome[4]]
chromos = [genome[i] for i in range(len(genome)) if i not in [8,4]]

for chromo in chromos:
    cancer_data = Oligo.File.read_dat_lines('../data/%s_Cancerous_GSM1909121.hicfreq' % chromo.name, col_names=['hicfreq'])
    cancer_index = {i*40000:d for i,d in enumerate(cancer_data)}
    healthy_data = Oligo.File.read_dat_lines('../data/%s_Healthy_GSM1551599.hicfreq' % chromo.name, col_names=['hicfreq'])
    healthy_index = {i*40000:d for i,d in enumerate(healthy_data)}
    
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_relative_deviations_from_average_spectrum_and_GC.dat' % (chromo, resolution, k))
    for i,d in enumerate(data):
        try:
            cancer_d = cancer_index[int(d['position'])]['hicfreq']
        except:
            cancer_d = 0.0
        try:
            healthy_d = healthy_index[int(d['position'])]['hicfreq']
        except:
            healthy_d = 0.0
        data[i]['healthy hicfreq'] = healthy_d
        data[i]['cancer hicfreq'] = cancer_d
    Oligo.File.save_dat_lines(data=data, output_filename='../results/%s_%skbp_k=%s_relative_deviations_from_average_spectrum_and_GC_and_hicfreq.dat' % (chromo, resolution, k))
    
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_relative_deviations_from_average_spectrum_in_groups_and_GC.dat' % (chromo, resolution, k))
    for i,d in enumerate(data):
        try:
            cancer_d = cancer_index[int(d['position [kbp]'])]['hicfreq']
        except:
            cancer_d = 0.0
        try:
            healthy_d = healthy_index[int(d['position [kbp]'])]['hicfreq']
        except:
            healthy_d = 0.0
        data[i]['healthy hicfreq'] = healthy_d
        data[i]['cancer hicfreq'] = cancer_d
    Oligo.File.save_dat_lines(data=data, output_filename='../results/%s_%skbp_k=%s_relative_deviations_from_average_spectrum_in_groups_and_GC_and_hicfreq.dat' % (chromo, resolution, k))
    
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_relative_average_deviations_from_average_spectrum_and_GC.dat' % (chromo, resolution, k))
    for i,d in enumerate(data):
        try:
            cancer_d = cancer_index[int(d['position [kbp]'])]['hicfreq']
        except:
            cancer_d = 0.0
        try:
            healthy_d = healthy_index[int(d['position [kbp]'])]['hicfreq']
        except:
            healthy_d = 0.0
        data[i]['healthy hicfreq'] = healthy_d
        data[i]['cancer hicfreq'] = cancer_d
    Oligo.File.save_dat_lines(data=data, output_filename='../results/%s_%skbp_k=%s_relative_average_deviations_from_average_spectrum_and_GC_and_hicfreq.dat' % (chromo, resolution, k))
    