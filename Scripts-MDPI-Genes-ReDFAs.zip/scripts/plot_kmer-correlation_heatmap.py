import sys
sys.path.insert(1, 'N:/Software/KIP/')
import Oligo

resolution = 40
k = 5
genome = Oligo.File.read_human_genome()
chromos = genome#[genome[8],genome[4]]
#chromos = [genome[4]]

def create_position_index(data):
    index = Oligo.Index(data, lambda d : int(d['position 1']), allow_multiple=True)
    return index

def create_redfas_index(chromo, resolution, k):
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_ReDFAS.dat' % (chromo, resolution, k))
    index = Oligo.Index(data, lambda d : int(d['position [kbp]']))
    return index

def find_correlation(position1, position2, index):
    values = index.get_value(position1)
    if values is not None:
        for d in values:
            if int(d['position 2']) == position2:
                return float(d['r'])
    values = index.get_value(position2)
    if values is not None:
        for d in values:
            if int(d['position 2']) == position1:
                return float(d['r'])
    #Oligo.Prot.warn('Could not find correlation for positions %s - %s' % (position1, position2))
    return 0.0

for chromo in chromos:
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_correlations.dat' % (chromo, resolution, k))
    position_index = create_position_index(data)
    posi1 = 0
    hm_data = []
    positions = []
    step_size = 10
    i = 0
    while posi1 < len(chromo):
        if i % 10 == 0:
            positions.append(int(posi1/1000))
        else:
            positions.append('')
        i += 1
        hm_data.append([])
        posi2 = 0
        while posi2 < len(chromo):
            if posi1 == posi2:
                r = 1.
            else:
                r = find_correlation(posi1, posi2, position_index)
            #r = 0.0
            hm_data[-1].append(r)
            posi2 += resolution*1000*step_size
        posi1 += resolution*1000*step_size
    drawer = Oligo.Plot.HeatmapDrawer(data=hm_data, cmap='bwr', xticklabels=positions, yticklabels=positions, vmin=-1, vmax=1)
    drawer.plot(output_filename='../results/%s_kmer_correlations_%skbp_k=%s_test.hm.png' % (chromo, resolution, k), show_legend=False, adjust_left=0.16,adjust_bottom=0.12, adjust_right=1.05, figsize=(15,15), dpi=150)
    del hm_data
    del data