import sys
sys.path.insert(1, 'N:/Software/KIP/')
import Oligo

resolution = 40

genome = Oligo.File.read_human_genome()
#chromos = [genome[8],genome[4]]
chromos = [genome[i] for i in range(len(genome)) if i not in [8,4]]

def derive_gc(v):
    nuc_content = sum([vi.count for vi in v])
    if nuc_content == 0:
        return 0.0
    else:
        return float(v[2].count+v[3].count)/nuc_content
    
map_A = Oligo.Maps.DensityMap.read('../results/Homo sapiens_A_%skb.map' % (resolution))
map_T = Oligo.Maps.DensityMap.read('../results/Homo sapiens_T_%skb.map' % (resolution))
map_G = Oligo.Maps.DensityMap.read('../results/Homo sapiens_G_%skb.map' % (resolution))
map_C = Oligo.Maps.DensityMap.read('../results/Homo sapiens_C_%skb.map' % (resolution))
map_gc = Oligo.Maps.combine_maps2([map_A,map_T,map_G, map_C], 'G+C content', combine_func=derive_gc, resolution=resolution*1000)
map_gc.save('../results/Homo sapiens_G+C_%skb.map' % resolution)


map = Oligo.Maps.DensityMap.read('../results/Homo sapiens_G+C_%skb.map' % resolution)
for chromo in chromos:
    out_data = []
    for bin in map[str(chromo)]:
        d = {'position':bin.start, 'G+C':bin.count}
        out_data.append(d)
    Oligo.File.save_dat_lines(data=out_data, output_filename='../results/%s_%skbp_GC_content.dat' % (chromo, resolution))