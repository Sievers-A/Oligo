import sys
sys.path.insert(1, 'N:/Software/KIP/')
import Oligo
from scipy.stats import pearsonr

k = 5
resolution = 40
genome = Oligo.File.read_human_genome()
chromos = [genome[8],genome[4]]

for chromo in chromos:
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_relative_average_deviations_from_average_spectrum_and_GC_and_hicfreq.dat' % (chromo, resolution, k))
    x, yh, yc = [], [], []
    for d in data:
        x.append(abs(float(d['Average Deviation from Average Spectrum'])))
        yh.append(abs(float(d['healthy hicfreq'])))
        yc.append(abs(float(d['cancer hicfreq'])))
        
    healthy_drawer = Oligo.Plot.CurveDrawer(x=x, y=yh, color='green', linestyle='o', marker='o', label='GSM1551599', alpha=0.5)
    cancer_drawer = Oligo.Plot.CurveDrawer(x=x, y=yc, color='red', linestyle='o', marker='o', label='GSM1909121', alpha=0.5)
    
    rh = round(pearsonr(x,yh)[0],2)
    rc = round(pearsonr(x,yc)[0],2)
    
    drawer = Oligo.Plot.MultiDrawer([healthy_drawer, cancer_drawer])
    drawer.plot(output_filename='../results/%s_%skbp_Hi-C_freq_VS_Average_Deviation.png' % (chromo, resolution), xlabel='Average Deviation from Average Spectrum', ylabel='Average Hi-C Contact Frequency', show_legend=True, grid_para=('major','both'), figsize=(15,7), dpi=200, title='Correlations: GSM1551599: %s | GSM1909121: %s' % (rh,rc))
    