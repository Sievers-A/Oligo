import sys
sys.path.insert(1, 'N:/Software/KIP/')
import Oligo
import itertools
from scipy.stats import pearsonr

resolution = 40
k = 5
words = [''.join(w) for w in itertools.product('ACGT',repeat=k)]

genome = Oligo.File.read_human_genome()
#chromos = [genome[8],genome[4]]
chromos = [genome[i] for i in range(len(genome)) if i not in [8,4]]

for chromo in chromos:
    out_data = []
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_relative_deviations_from_average_spectrum_and_GC_and_hicfreq.dat' % (chromo, resolution, k))
    spectra = [[float(d[kmer]) for kmer in words] for d in data]
    for i,d1 in enumerate(data):
        spectrum1 = spectra[i]
        print('%s/%s' % (i,len(data)))
        for j in range(i):
            d2 = data[j]
            spectrum2 = spectra[j]
            r = pearsonr(spectrum1,spectrum2)[0]
            out_data.append({'position 1':d1['position'], 'position 2':d2['position'], 'r':r})
    Oligo.File.save_dat_lines('../results/%s_%skbp_k=%s_correlations.dat' % (chromo, resolution, k), out_data)
   