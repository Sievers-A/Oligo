import sys
sys.path.insert(1, 'N:/Software/KIP/')
import Oligo
import itertools
from scipy.stats import pearsonr

resolution = 40
k = 5
words = [''.join(w) for w in itertools.product('ACGT',repeat=k)]

genome = Oligo.File.read_human_genome()

def color_func(key, value, line):
    if key not in ['kmer']:
        if value == '-':
            return None
        v = float(value)
        if v == 0:
            return None
        if v < 0:
            return (255,max(128,255-abs(v)*255),max(128,255-abs(v)*255))
        else:
            return (max(128,255-v*255),255, max(128,255-v*255))
    else:
        return None

for chromo in genome:
    pca_data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_PCA.dat' % (chromo,resolution,k))
    kmer_data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_relative_deviations_from_average_spectrum_and_GC_and_hicfreq.dat' % (chromo, resolution, k))
    
    pca0_vector = [float(d['pca 0']) for d in pca_data]
    pca1_vector = [float(d['pca 1']) for d in pca_data]
    pca2_vector = [float(d['pca 2']) for d in pca_data]
    
    kmer_vectors = {kmer:[float(d[kmer]) for d in kmer_data] for kmer in words}
    
    del pca_data
    del kmer_data
    
    out_data = []
    for kmer in words:
        r0 = pearsonr(kmer_vectors[kmer],pca0_vector)[0]
        r1 = pearsonr(kmer_vectors[kmer],pca1_vector)[0]
        r2 = pearsonr(kmer_vectors[kmer],pca2_vector)[0]
        
        out_data.append({'kmer': kmer, 'pca 0 correlation':r0, 'pca 1 correlation':r1, 'pca 2 correlation':r2})
        
    Oligo.File.save_dat_lines(data=out_data, output_filename='../results/%s_kmer_pca_correlations.dat' % chromo)
    
    for d in out_data:
        d['pca 0 correlation'] = format(d['pca 0 correlation'],'.2f')
        d['pca 1 correlation'] = format(d['pca 1 correlation'],'.2f')
        d['pca 2 correlation'] = format(d['pca 2 correlation'],'.2f')
    Oligo.File.save_dat_lines_as_html_table(output_filename='../results/%s_kmer_pca_correlations.html' % chromo, data=out_data, color_func=color_func)