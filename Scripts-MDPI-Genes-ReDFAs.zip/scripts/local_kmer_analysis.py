import sys
sys.path.insert(1, 'N:/Software/KIP/')
import Oligo
import itertools

resolution = 40
k = 5
words = [''.join(w) for w in itertools.product('ACGT',repeat=k)]
#k = 1
#words = ['A','C','G','T']

genome = Oligo.File.read_human_genome()
#chromos = [genome[8],genome[4]]
#chromos = [genome[i] for i in range(len(genome)) if i not in [8,4]]
chromos = genome

Oligo.Maps.generate_kmer_maps(chromos, resolution=resolution*1000, k=k, output_filenames={word:'../results/Homo sapiens_%s_%skb.map' % (word, resolution) for word in words}, words=words, allow_delete_maps=True)