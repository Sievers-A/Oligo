import sys
sys.path.insert(1, 'N:/Software/KIP/')
import Oligo
from scipy.stats import pearsonr

k = 5
resolution = 40
genome = Oligo.File.read_human_genome()
chromos = [genome[8],genome[4]]

for chromo in chromos:
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_relative_average_deviations_from_average_spectrum_and_GC_and_hicfreq.dat' % (chromo, resolution, k))
    x, y = [], []
    for d in data:
        x.append(float(d['Average Deviation from Average Spectrum']))
        y.append(float(d['Average Deviation from Average Spectrum'])/float(d['G+C']))
        
    drawer = Oligo.Plot.CurveDrawer(x=x, y=y, color='green', linestyle='o', marker='o')
    
    r = round(pearsonr(x,y)[0],2)
    
    drawer.plot(output_filename='../results/%s_%skbp_Deviation_per_G+C_freq_VS_Average_Deviation.png' % (chromo, resolution), xlabel='Average Deviation from Average Spectrum', ylabel='Average Deviation / G+C', show_legend=False, grid_para=('major','both'), figsize=(15,7), dpi=200, title='Correlation:: %s' % (r))
    