import sys
sys.path.insert(1, 'N:/Software/KIP/')
import Oligo

genome = Oligo.File.read_human_genome()

def color_func(key, value, line):
    if key not in ['kmer']:
        if value == '-':
            return None
        v = float(value)
        if v == 0:
            return None
        if v < 0:
            return (255,max(128,255-abs(v)*255),max(128,255-abs(v)*255))
        else:
            return (max(128,255-v*255),255, max(128,255-v*255))
    else:
        return None
        

for chromo in genome:
    data = Oligo.File.read_dat_lines('../results/%s_kmer_pca_correlations.dat' % chromo)
    for d in data:
        d['pca 0 correlation'] = float(d['pca 0 correlation'])
        d['pca 1 correlation'] = float(d['pca 1 correlation'])
        d['pca 2 correlation'] = float(d['pca 2 correlation'])
    
    out_data = sorted(data, key=lambda d: -abs(d['pca 0 correlation']))
    for d in out_data:
        d['pca 0 correlation'] = format(d['pca 0 correlation'],'.2f')
    Oligo.File.save_dat_lines_as_html_table(output_filename='../results/%s_kmer_pca_correlations_sorted0.html' % chromo, data=out_data, color_func=color_func)
    
    
    out_data = sorted(data, key=lambda d: -abs(d['pca 1 correlation']))
    for d in out_data:
        d['pca 1 correlation'] = format(d['pca 1 correlation'],'.2f')
    Oligo.File.save_dat_lines_as_html_table(output_filename='../results/%s_kmer_pca_correlations_sorted1.html' % chromo, data=out_data, color_func=color_func)