import sys
sys.path.insert(1, 'N:/Software/KIP/')
import Oligo

resolution = 40
k = 5
genome = Oligo.File.read_human_genome()
chromos = genome#[genome[8],genome[4]]

def derive_centro_limits(chromos):
    chromo_centro_limits = []
    for chromo in chromos:
        loci = Oligo.Locus.read('../data/%s_centromeres.loci' % chromo)
        chromo_centro_limits.append((loci[0].start-40000, loci[0].get_end()+40000))
    return chromo_centro_limits

chromo_centro_limits = derive_centro_limits(chromos)#[(43200000,45520000),(46480000,50040000)]

def create_position_index(data):
    index = Oligo.Index(data, lambda d : int(d['position 1']), allow_multiple=True)
    return index

def create_redfas_index(chromo, resolution, k):
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_ReDFAS.dat' % (chromo, resolution, k))
    index = Oligo.Index(data, lambda d : int(d['position [kbp]']))
    return index

def find_correlation(position1, position2, index):
    values = index.get_value(position1)
    if values is not None:
        for d in values:
            if int(d['position 2']) == position2:
                return float(d['r'])
    values = index.get_value(position2)
    if values is not None:
        for d in values:
            if int(d['position 2']) == position1:
                return float(d['r'])
    return 0.0

def get_ordered_posi(chromo, step_size, resolution, k, centro_limits):
    redfas_index = create_redfas_index(chromo, resolution, k)
    posi = 0
    non_redfas_posi = []
    redfas_posi = []
    telo_posi = []
    centro_posi = []
    while posi < len(chromo):
        if redfas_index.get_value(posi) is not None:
            if float(posi)/len(chromo) <= 0.1 or  float(posi)/len(chromo) >= 0.90:
                telo_posi.append(posi)
            elif posi >= centro_limits[0] and posi <= centro_limits[1]:
                centro_posi.append(posi)
            else:
                redfas_posi.append(posi)
        else:
            non_redfas_posi.append(posi)
        posi += resolution*1000
    ret_posi = []
    labels = []
    i = 0
    for posi in non_redfas_posi:
        if i%100 == 0:
            ret_posi.append(posi)
            labels.append('non-ReDFAs %s' % posi)
        i += 1
    for posi in redfas_posi:
        ret_posi.append(posi)
        labels.append('intermediate ReDFAs %s' % posi)
    for posi in telo_posi:
        ret_posi.append(posi)
        labels.append('telomere ReDFAs %s' % posi)
    for posi in centro_posi:
        ret_posi.append(posi)
        labels.append('centromere ReDFAs %s' % posi)
    return ret_posi, labels

for chromo, centro_limits in zip(chromos, chromo_centro_limits):
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_correlations.dat' % (chromo, resolution, k))
    position_index = create_position_index(data)
    posi1 = 0
    hm_data = []
    step_size = 10
    positions, labels = get_ordered_posi(chromo, step_size, resolution, k, centro_limits)
    i = 0
    for posi1 in positions:
        hm_data.append([])
        for posi2 in positions:
            if posi1 == posi2:
                r = 1.
            else:
                r = find_correlation(posi1, posi2, position_index)
            #r = 0.0
            hm_data[-1].append(r)
    drawer = Oligo.Plot.HeatmapDrawer(data=hm_data, cmap='bwr', xticklabels=labels, yticklabels=labels, vmin=-1, vmax=1)
    drawer.plot(output_filename='../results/%s_kmer_correlations_%skbp_k=%s_ReDFAs_sorted.hm.png' % (chromo, resolution, k), show_legend=False, adjust_left=0.16,adjust_bottom=0.12, adjust_right=1.05, figsize=(30,30), dpi=150)
    del hm_data
    del data