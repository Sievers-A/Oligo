import sys
sys.path.insert(1, 'N:/Software/KIP/')
import Oligo
import itertools
import numpy as np

k = 5
resolution = 40
genome = Oligo.File.read_human_genome()
#chromos = [genome[8],genome[4]]
chromos = [genome[i] for i in range(len(genome)) if i not in [8,4]]

group_names = ['A-rich','C-rich','G-rich','T-rich','AT-rich','GC-rich']

def check_word_set(kmer, word_set):
    if word_set == 'A-rich':
        a_count = len([nuc for nuc in kmer if nuc == 'A'])
        return a_count >= 4
    elif word_set == 'C-rich':
        c_count = len([nuc for nuc in kmer if nuc == 'C'])
        return c_count >= 4
    elif word_set == 'G-rich':
        g_count = len([nuc for nuc in kmer if nuc == 'G'])
        return g_count >= 4
    elif word_set == 'T-rich':
        t_count = len([nuc for nuc in kmer if nuc == 'T'])
        return t_count >= 4
    elif word_set == 'AT-rich':
        at_count = len([nuc for nuc in kmer if nuc == 'A' or nuc == 'T'])
        return at_count >= 5
    elif word_set == 'GC-rich':
        gc_count = len([nuc for nuc in kmer if nuc == 'C' or nuc == 'G'])
        return gc_count >= 5
    return None
    
words = [''.join(w) for w in itertools.product('ACGT',repeat=k)]

for chromo in chromos:
    out_data = []
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_relative_deviations_from_average_spectrum.dat' % (chromo, resolution, k))
    for d in data:
        out_d = {'position [kbp]':d['position']}
        for group_name in group_names:
            group_values = []
            for kmer in words:
                if check_word_set(kmer, group_name):
                    group_values.append(float(d[kmer]))
            group_value = np.mean(group_values)
            out_d[group_name] = group_value
        out_data.append(out_d)
    Oligo.File.save_dat_lines('../results/%s_%skbp_k=%s_relative_deviations_from_average_spectrum_in_groups.dat' % (chromo, resolution, k), data=out_data)
