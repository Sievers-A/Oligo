import sys
sys.path.insert(1, 'N:/Software/KIP/')
import Oligo
import itertools

k = 5
resolution = 40

genome = Oligo.File.read_human_genome()
#chromos = [genome[8],genome[4]]
chromos = [genome[i] for i in range(len(genome)) if i not in [8,4]]

for chromo in chromos:
    gc_data = Oligo.File.read_dat_lines('../results/%s_%skbp_GC_content.dat' % (chromo, resolution))
    gc_index = Oligo.Index(gc_data, lambda d:int(d['position']), allow_multiple=False)
    
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_relative_deviations_from_average_spectrum.dat' % (chromo, resolution, k))
    for i,d in enumerate(data):
        gc_d = gc_index.get_value(int(d['position']))
        if gc_d is not None:
            data[i]['G+C'] = gc_d['G+C']
        else:
            data[i]['G+C'] = 0.0
    Oligo.File.save_dat_lines(data=data, output_filename='../results/%s_%skbp_k=%s_relative_deviations_from_average_spectrum_and_GC.dat' % (chromo, resolution, k))
    
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_relative_deviations_from_average_spectrum_in_groups.dat' % (chromo, resolution, k))
    for i,d in enumerate(data):
        gc_d = gc_index.get_value(int(d['position [kbp]']))
        if gc_d is not None:
            data[i]['G+C'] = gc_d['G+C']
        else:
            data[i]['G+C'] = 0.0
    Oligo.File.save_dat_lines(data=data, output_filename='../results/%s_%skbp_k=%s_relative_deviations_from_average_spectrum_in_groups_and_GC.dat' % (chromo, resolution, k))
    
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_relative_average_deviations_from_average_spectrum.dat' % (chromo, resolution, k))
    for i,d in enumerate(data):
        gc_d = gc_index.get_value(int(d['position [kbp]']))
        if gc_d is not None:
            data[i]['G+C'] = gc_d['G+C']
        else:
            data[i]['G+C'] = 0.0
    Oligo.File.save_dat_lines(data=data, output_filename='../results/%s_%skbp_k=%s_relative_average_deviations_from_average_spectrum_and_GC.dat' % (chromo, resolution, k))
    
   
    
    
    