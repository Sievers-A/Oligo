import sys
sys.path.insert(1, 'N:/Software/KIP/')
import Oligo

k = 5
resolution = 40
genome = Oligo.File.read_human_genome()
chromos = genome#[genome[8],genome[4]]

for chromo in chromos:
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_relative_average_deviations_from_average_spectrum.dat' % (chromo, resolution, k))
    x, y = [], []
    for d in data:
        x.append(int(d['position [kbp]'])/1000/1000)
        y.append(abs(float(d['Average Deviation from Average Spectrum'])))
        
    drawer = Oligo.Plot.CurveDrawer(x=x, y=y, color='blue', linestyle='o', marker='o', markersize=4., alpha=0.5)
    drawer.plot(output_filename='../results/%s_%skbp_k=%s_Average_Deviation_from_Average_Spectrum.png' % (chromo, resolution, k), xlabel='Position [Mbp]', ylabel='Average Deviation from Average Spectrum', show_legend=False, grid_para=('major','both'), figsize=(15,7), dpi=300)
    