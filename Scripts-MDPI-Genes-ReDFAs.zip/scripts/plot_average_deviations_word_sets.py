import sys
sys.path.insert(1, 'N:/Software/KIP/')
import Oligo

k = 5
resolution = 40
genome = Oligo.File.read_human_genome()
#chromos = [genome[8],genome[4]]
#chromos = [genome[8],genome[4]]
chromos = genome#[genome[8],genome[4]]

group_names = ['A-rich','C-rich','G-rich','T-rich','AT-rich','GC-rich']
group_colors = ['blue','orange','green','red','purple','brown']

#group_names = ['A-rich','C-rich','GC-rich']
#group_colors = ['red', 'blue', 'green']

for chromo in chromos:
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_relative_deviations_from_average_spectrum_in_groups.dat' % (chromo, resolution, k))
    drawers = []
    for group_name, color in zip(group_names, group_colors):
        x, y = [], []
        for d in data:
            x.append(int(d['position [kbp]'])/1000/1000)
            y.append(float(d[group_name]))
        #drawer = Oligo.Plot.CurveDrawer(x=x, y=y, color=color, linestyle='o', marker='o', label=group_name, markersize=3, alpha=0.5)
        drawer = Oligo.Plot.CurveDrawer(x=x, y=y, color=color, linestyle='o', marker='o', label=group_name, markersize=1.5, alpha=0.5)
        drawers.append(drawer)
    drawer = Oligo.Plot.MultiDrawer(drawers)
    #drawer.plot(output_filename='../results/%s_%skbp_k=%s_Average_Deviation_from_Average_Spectrum_groups_A_C_GC.png' % (chromo, resolution, k), xlabel='Position [Mbp]', ylabel='Average Deviation from Average Spectrum', show_legend=True, grid_para=('major','both'), figsize=(15,10), dpi=300)
    drawer.plot(output_filename='../results/%s_%skbp_k=%s_Average_Deviation_from_Average_Spectrum_groups_full.png' % (chromo, resolution, k), xlabel='Position [Mbp]', ylabel='Average Deviation from Average Spectrum', show_legend=True, grid_para=('major','both'), figsize=(15,7), dpi=300)
    