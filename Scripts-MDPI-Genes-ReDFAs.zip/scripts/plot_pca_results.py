import sys
sys.path.insert(1, 'N:/Software/KIP/')
import Oligo

resolution = 40
k = 5

genome = Oligo.File.read_human_genome()
chromos = genome#[genome[8],genome[4]]

n_components = 2

def derive_centro_limits(chromos):
    chromo_centro_limits = []
    for chromo in chromos:
        loci = Oligo.Locus.read('../data/%s_centromeres.loci' % chromo)
        chromo_centro_limits.append((loci[0].start-40000, loci[0].get_end()+40000))
    return chromo_centro_limits

chromo_centro_limits = derive_centro_limits(chromos)#[(43200000,45520000),(46480000,50040000)]

print(chromo_centro_limits)

def create_redfas_index(chromo, resolution, k):
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_ReDFAS.dat' % (chromo, resolution, k))
    index = Oligo.Index(data, lambda d : int(d['position [kbp]']))
    return index

for chromo, centro_limits in zip(chromos, chromo_centro_limits):
    redfas_index = create_redfas_index(chromo, resolution, k)
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_PCA.dat' % (chromo,resolution,k))
    #data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_PCA_ReDFAs_only.dat' % (chromo,resolution,k))
    
    
    drawers = []

    x, y, z = [], [], []
    x_telo, y_telo, z_telo = [], [], []
    x_centro, y_centro, z_centro = [], [], []
    x_non_redfas, y_non_redfas, z_non_redfas = [], [], []
    for d in data:
        if redfas_index.get_value(int(d['position'])) is not None:
            if float(d['position'])/len(chromo) <= 0.1 or  float(d['position'])/len(chromo) >= 0.90:
                x_telo.append(float(d['pca 0']))
                y_telo.append(float(d['pca 1']))
                z_telo.append(float(d['pca 2']))
            elif float(d['position']) >= centro_limits[0] and float(d['position']) <= centro_limits[1]:
                x_centro.append(float(d['pca 0']))
                y_centro.append(float(d['pca 1']))
                z_centro.append(float(d['pca 2']))
            else:
                x.append(float(d['pca 0']))
                y.append(float(d['pca 1']))
                z.append(float(d['pca 2']))
        else:
            x_non_redfas.append(float(d['pca 0']))
            y_non_redfas.append(float(d['pca 1']))
            z_non_redfas.append(float(d['pca 2']))
    print('Non-ReDFAs: %s | ReDFAs: %s | Telo: %s | Centro: %s' % (len(x_non_redfas), len(x),len(x_telo),len(x_centro)))
    
    drawers.append(Oligo.Plot.CurveDrawer(x=x_non_redfas ,y=y_non_redfas, label=None, linestyle='.', markersize=1, marker='o', color='blue', alpha=1))
    drawers.append(Oligo.Plot.CurveDrawer(x=x_non_redfas ,y=y_non_redfas, label='non ReDFAs', linestyle='.', markersize=5, marker='o', color='blue', alpha=0.1))
    
    drawers.append(Oligo.Plot.CurveDrawer(x=x ,y=y, label=None, linestyle='.', markersize=1, marker='o', color='red', alpha=1))
    drawers.append(Oligo.Plot.CurveDrawer(x=x ,y=y, label='ReDFAs', linestyle='.', markersize=5, marker='o', color='red', alpha=0.1))
    
    drawers.append(Oligo.Plot.CurveDrawer(x=x_telo ,y=y_telo, label=None, linestyle='.', markersize=1, marker='o', color='orange', alpha=1))
    drawers.append(Oligo.Plot.CurveDrawer(x=x_telo ,y=y_telo, label='Telomer ReDFAs', linestyle='.', markersize=5, marker='o', color='orange', alpha=0.1))
    
    drawers.append(Oligo.Plot.CurveDrawer(x=x_centro ,y=y_centro, label=None, linestyle='.', markersize=1, marker='o', color='purple', alpha=1))
    drawers.append(Oligo.Plot.CurveDrawer(x=x_centro ,y=y_centro, label='Centromer ReDFAs', linestyle='.', markersize=5, marker='o', color='purple', alpha=0.1))
    
    #x, y, z = [], [], []
    #for d in data:
    #    if redfas_index.get_value(int(d['position'])) is None:
    #        x.append(float(d['pca 0']))
    #        y.append(float(d['pca 1']))
    #        z.append(float(d['pca 2']))
    #drawers.append(Oligo.Plot.CurveDrawer(x=x ,y=y, label='non ReDFAs', linestyle='.', markersize=1, marker='o', color='blue', alpha=1))
    #drawers.append(Oligo.Plot.CurveDrawer(x=x ,y=y, label=None, linestyle='.', markersize=5, marker='o', color='blue', alpha=0.1))

    #x = [float(d['pca 0']) for d in data]
    #y = [float(d['pca 1']) for d in data]
    #drawers.append(Oligo.Plot.CurveDrawer(x=x ,y=y, label='local k-mer spectra', linestyle='.', markersize=5, marker='o', color='grey', alpha=0.5))
    
    drawer = Oligo.Plot.MultiDrawer(drawers)
    drawer.plot(output_filename='../results/%s_%skbp_k=%s_pca.png' % (chromo, resolution, k),xlabel='PCA 0',ylabel='PCA 1', figsize=(8,8), dpi=300, grid_para=('major','both'))
    #drawer.plot(output_filename='../results/%s_%skbp_k=%s_pca_ReDFAs_only.png' % (chromo, resolution, k),xlabel='PCA 0',ylabel='PCA 1', figsize=(8,8), dpi=300, grid_para=('major','both'))