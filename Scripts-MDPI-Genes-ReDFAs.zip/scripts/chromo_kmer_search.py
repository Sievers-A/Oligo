import sys
sys.path.insert(1, 'N:/Software/KIP/')
import Oligo

k = 5

genome = Oligo.File.read_human_genome()
#chromos = [genome[8],genome[4]]
chromos = genome

for chromo in chromos:
    chromo.load_seq()
    Oligo.Search.search_kmer(data_seq=chromo.get_seq(), k=k, data_seq_name=str(chromo), output_filename='../results/%s_k=%s.kmer' % (str(chromo),k))
    chromo.unload_seq()
