import sys
sys.path.insert(1, 'N:/Software/KIP/')
import Oligo

k = 5
resolution = 40
genome = Oligo.File.read_human_genome()
chromos = genome#[genome[8],genome[4]]

for chromo in chromos:
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_relative_deviations_from_average_spectrum_and_GC_and_hicfreq.dat' % (chromo, resolution, k))
    x, yh, yc = [], [], []
    for d in data:
        x.append(int(d['position'])/1000/1000)
        yh.append(abs(float(d['healthy hicfreq'])))
        yc.append(abs(float(d['cancer hicfreq'])))
        
    healthy_drawer = Oligo.Plot.CurveDrawer(x=x, y=yh, color='green', linestyle='o', marker='o', label='IMR90', markersize=2., alpha=0.5)
    cancer_drawer = Oligo.Plot.CurveDrawer(x=x, y=yc, color='red', linestyle='o', marker='o', label='Hap1', markersize=2., alpha=0.5)
    
    drawer = Oligo.Plot.MultiDrawer([healthy_drawer, cancer_drawer])
    drawer.plot(output_filename='../results/%s_%skbp_Hi-C_freq.png' % (chromo, resolution), xlabel='Position [Mbp]', ylabel='Average Hi-C Contact Frequency', show_legend=True, grid_para=('major','both'), figsize=(7,5), dpi=600)
    