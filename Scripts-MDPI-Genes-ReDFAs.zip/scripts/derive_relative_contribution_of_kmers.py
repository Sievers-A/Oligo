import sys
sys.path.insert(1, 'N:/Software/KIP/')
import Oligo
from scipy.stats import pearsonr
import itertools

k = 5
resolution = 40
genome = Oligo.File.read_human_genome()
chromos = [genome[8],genome[4]]

words = [''.join(w) for w in itertools.product('ACGT',repeat=k)]

for chromo in chromos:
    data = Oligo.File.read_dat_lines('../results/%s_%skbp_k=%s_relative_deviations_from_average_spectrum_and_GC_and_hicfreq.dat' % (chromo, resolution, k))
    for d in data:
        average_deviation = sum([float(d[kmer]) for kmer in words])
        for kmer in words:
            x = float(d[kmer])
            if x != 0:
                d['%s rel.'] = x/average_deviation
            else:
                d['%s rel.'] = 0.0
    Oligo.File.save_dat_lines(data=data, output_filename='../results/%s_%skbp_k=%s_relative_deviations_from_average_spectrum_and_GC_and_hicfreq_and_kmer-contributions.dat' % (chromo, resolution, k))