import sys
sys.path.insert(1, 'N:/Software/KIP/')
import Oligo
import itertools

k = 5
resolution = 40

genome = Oligo.File.read_human_genome()
#chromos = [genome[8],genome[4]]
chromos = [genome[i] for i in range(len(genome)) if i not in [8,4]]

words = [''.join(w) for w in itertools.product('ACGT',repeat=k)]

# Read Chromosomal Spectra
spectra = [Oligo.Kmer.KmerSpectrum.read('../results/%s_k=%s.kmer' % (chromo,k)) for chromo in chromos]
#print(spectra[0].get_count('ACGCT'))
#print(spectra[0].get_freq('ACGCT'))

# Derive Deviations for every word and position
for chromo, spectrum in zip(chromos, spectra):
    data = {}
    for word in words:
        map = Oligo.Maps.DensityMap.read('../results/Homo sapiens_%s_%skb.map' % (word, resolution))
        for bin in map[str(chromo)]:
            try:
                data[bin.start]
            except:
                data[bin.start] = {}
            data[bin.start][word] = (bin.count/float(resolution*1000)-spectrum.get_freq(word))/spectrum.get_freq(word)
    out_data = []
    for posi in data.keys():
        d = {'position':posi}
        for word in words:
            try:
                data[posi][word]
            except:
                d[word] = 0
            else:
                d[word] = data[posi][word]
        out_data.append(d)
    Oligo.File.save_dat_lines(data=out_data, output_filename='../results/%s_%skbp_k=%s_relative_deviations_from_average_spectrum.dat' % (chromo, resolution, k))